/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { UpcomingBirthdays } from './components/UpcomingBirthdays';
import { BirthdayModal } from './components/BirthdayModal';
import { MemberCarousel } from './components/MemberCarousel';
import { BatchmateDirectory } from './components/BatchmateDirectory';
import { BatchmateDetailModal } from './components/BatchmateDetailModal';
import { HallOfFame } from './components/HallOfFame';
import { MemoriesGallery } from './components/MemoriesGallery';
import { BatchStories } from './components/BatchStories';
import { BloodDonorDirectory } from './components/BloodDonorDirectory';
import { ReunionSection } from './components/ReunionSection';
import { AdminPanel } from './components/AdminPanel';
import { Footer } from './components/Footer';
import { JoinBatchModal } from './components/JoinBatchModal';
import { ShareModal } from './components/ShareModal';
import { MemberAccessGate } from './components/MemberAccessGate';
import { EditProfileModal } from './components/EditProfileModal';

import {
  INITIAL_BATCHMATES,
  INITIAL_HALL_OF_FAME,
  INITIAL_GALLERY,
  INITIAL_STORIES,
  INITIAL_REUNION_REGISTRATIONS,
  INITIAL_REUNION_SETTINGS,
} from './data/initialData';
import { Batchmate, HallOfFameItem, GalleryItem, Story, ReunionRegistration, ReunionSettings } from './types';

export default function App() {
  // Theme state
  const [isLightMode, setIsLightMode] = useState<boolean>(() => {
    return localStorage.getItem('dcms23_theme') === 'light';
  });

  // Navigation tab state
  const [currentTab, setCurrentTab] = useState<string>('home');

  // Active member login session
  const [currentUser, setCurrentUser] = useState<Batchmate | null>(() => {
    const saved = localStorage.getItem('dcms23_member_session');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return null;
  });

  // App Data with local storage persistence
  const [batchmates, setBatchmates] = useState<Batchmate[]>(() => {
    const saved = localStorage.getItem('dcms23_batchmates');
    let loaded: Batchmate[] = [];
    if (saved) {
      try {
        const parsed: Batchmate[] = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          // Keep all registered batchmates; only exclude ancient mock demo IDs (dcms23-sci-01 etc)
          loaded = parsed.filter((b) => !b.id.match(/^dcms23-(sci|arts|com)-\d+$/));
        }
      } catch (e) {
        console.error(e);
      }
    }
    // Guarantee that if currentUser is stored in session, they are also present in batchmates
    const savedUser = localStorage.getItem('dcms23_member_session');
    if (savedUser) {
      try {
        const user: Batchmate = JSON.parse(savedUser);
        if (user && user.id) {
          const exists = loaded.some(
            (b) => b.id === user.id || (user.phone && b.phone && b.phone.replace(/\s+/g, '') === user.phone.replace(/\s+/g, ''))
          );
          if (!exists) {
            loaded = [user, ...loaded];
          }
        }
      } catch (e) {
        console.error(e);
      }
    }
    return loaded;
  });

  const [hallOfFame, setHallOfFame] = useState<HallOfFameItem[]>(() => {
    const saved = localStorage.getItem('dcms23_hof');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_HALL_OF_FAME;
  });

  const [gallery, setGallery] = useState<GalleryItem[]>(() => {
    const saved = localStorage.getItem('dcms23_gallery');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const hasCampusPhoto = parsed.some(
            (item: GalleryItem) => item.id === 'gal-campus-01' || item.url?.includes('IMG_c0994971') || item.url?.includes('school-campus')
          );
          if (!hasCampusPhoto && INITIAL_GALLERY.length > 0) {
            return [INITIAL_GALLERY[0], ...parsed];
          }
          return parsed;
        }
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_GALLERY;
  });

  const [stories, setStories] = useState<Story[]>(() => {
    const saved = localStorage.getItem('dcms23_stories');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_STORIES;
  });

  const [registrations, setRegistrations] = useState<ReunionRegistration[]>(() => {
    const saved = localStorage.getItem('dcms23_registrations');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_REUNION_REGISTRATIONS;
  });

  const [reunionSettings, setReunionSettings] = useState<ReunionSettings>(() => {
    const saved = localStorage.getItem('dcms23_reunion_settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_REUNION_SETTINGS;
  });

  const [selectedBatchmate, setSelectedBatchmate] = useState<Batchmate | null>(null);
  const [birthdayModalBatchmates, setBirthdayModalBatchmates] = useState<Batchmate[] | null>(null);
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [isLoginGateOpen, setIsLoginGateOpen] = useState(false);

  // Sync theme to body tag
  useEffect(() => {
    if (isLightMode) {
      document.body.classList.add('light-mode');
      localStorage.setItem('dcms23_theme', 'light');
    } else {
      document.body.classList.remove('light-mode');
      localStorage.setItem('dcms23_theme', 'dark');
    }
  }, [isLightMode]);

  // Persist data
  useEffect(() => {
    localStorage.setItem('dcms23_batchmates', JSON.stringify(batchmates));
  }, [batchmates]);

  useEffect(() => {
    localStorage.setItem('dcms23_hof', JSON.stringify(hallOfFame));
  }, [hallOfFame]);

  useEffect(() => {
    localStorage.setItem('dcms23_gallery', JSON.stringify(gallery));
  }, [gallery]);

  useEffect(() => {
    localStorage.setItem('dcms23_stories', JSON.stringify(stories));
  }, [stories]);

  useEffect(() => {
    localStorage.setItem('dcms23_registrations', JSON.stringify(registrations));
  }, [registrations]);

  useEffect(() => {
    localStorage.setItem('dcms23_reunion_settings', JSON.stringify(reunionSettings));
  }, [reunionSettings]);

  // Check today's birthday on initial load
  useEffect(() => {
    const today = new Date();
    const todayStr = `${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    const todayCelebrators = batchmates.filter((b) => b.birthday === todayStr);

    const shownKey = `dcms23_birthday_shown_${todayStr}`;
    if (todayCelebrators.length > 0 && !sessionStorage.getItem(shownKey)) {
      setBirthdayModalBatchmates(todayCelebrators);
      sessionStorage.setItem(shownKey, 'true');
    }
  }, [batchmates]);

  const toggleTheme = () => {
    setIsLightMode(!isLightMode);
  };

  // Login / Session Handlers
  const handleLoginSuccess = (member: Batchmate) => {
    setBatchmates((prev) => {
      const existsIndex = prev.findIndex(
        (b) => b.id === member.id || (b.phone && member.phone && b.phone.replace(/\s+/g, '') === member.phone.replace(/\s+/g, ''))
      );
      let updated: Batchmate[];
      if (existsIndex === -1) {
        updated = [member, ...prev];
      } else {
        updated = [...prev];
        updated[existsIndex] = { ...updated[existsIndex], ...member };
      }
      localStorage.setItem('dcms23_batchmates', JSON.stringify(updated));
      return updated;
    });
    setCurrentUser(member);
    localStorage.setItem('dcms23_member_session', JSON.stringify(member));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('dcms23_member_session');
  };

  // Handlers
  const handleAddBatchmate = (newMember: Batchmate) => {
    setBatchmates((prev) => [newMember, ...prev]);
    if (!currentUser) {
      setCurrentUser(newMember);
      localStorage.setItem('dcms23_member_session', JSON.stringify(newMember));
    }
  };

  const handleDeleteBatchmate = (id: string) => {
    setBatchmates((prev) => prev.filter((b) => b.id !== id));
    if (currentUser?.id === id) {
      handleLogout();
    }
  };

  const handleUpdateProfile = (updatedMember: Batchmate) => {
    setBatchmates((prev) => prev.map((b) => (b.id === updatedMember.id ? updatedMember : b)));
    if (currentUser?.id === updatedMember.id) {
      setCurrentUser(updatedMember);
      localStorage.setItem('dcms23_member_session', JSON.stringify(updatedMember));
    }
  };

  const handleBulkImport = (newMembers: Batchmate[]) => {
    // Merge or add
    setBatchmates((prev) => {
      const existingNames = new Set(prev.map((b) => b.name.toLowerCase()));
      const toAdd = newMembers.filter((b) => !existingNames.has(b.name.toLowerCase()));
      return [...toAdd, ...prev];
    });
  };

  const handleAddGalleryItem = (item: GalleryItem) => {
    setGallery((prev) => [item, ...prev]);
  };

  const handleDeleteGalleryItem = (id: string) => {
    setGallery((prev) => prev.filter((g) => g.id !== id));
  };

  const handleAddHallOfFame = (item: HallOfFameItem) => {
    setHallOfFame((prev) => [item, ...prev]);
  };

  const handleDeleteHallOfFame = (id: string) => {
    setHallOfFame((prev) => prev.filter((h) => h.id !== id));
  };

  const handleAddStory = (storyData: Omit<Story, 'id' | 'likes' | 'status' | 'timestamp'>) => {
    const newStory: Story = {
      ...storyData,
      id: `story-${Date.now()}`,
      status: 'pending', // Pending for admin moderation
      likes: 0,
      timestamp: Date.now(),
    };
    setStories((prev) => [newStory, ...prev]);
  };

  const handleApproveStory = (id: string) => {
    setStories((prev) =>
      prev.map((s) => (s.id === id ? { ...s, status: 'published' } : s))
    );
  };

  const handleDeleteStory = (id: string) => {
    setStories((prev) => prev.filter((s) => s.id !== id));
  };

  const handleLikeStory = (id: string) => {
    setStories((prev) =>
      prev.map((s) => (s.id === id ? { ...s, likes: s.likes + 1 } : s))
    );
  };

  const handleRegisterReunion = (regData: Omit<ReunionRegistration, 'id' | 'timestamp' | 'confirmed'>) => {
    const newReg: ReunionRegistration = {
      ...regData,
      id: `reg-${Date.now()}`,
      timestamp: Date.now(),
      confirmed: true,
    };
    setRegistrations((prev) => [newReg, ...prev]);
  };

  const handleDeleteRegistration = (id: string) => {
    setRegistrations((prev) => prev.filter((r) => r.id !== id));
  };

  const handleResetData = () => {
    localStorage.removeItem('dcms23_batchmates');
    localStorage.removeItem('dcms23_hof');
    localStorage.removeItem('dcms23_gallery');
    localStorage.removeItem('dcms23_stories');
    localStorage.removeItem('dcms23_registrations');
    localStorage.removeItem('dcms23_reunion_settings');
    setBatchmates(INITIAL_BATCHMATES);
    setHallOfFame(INITIAL_HALL_OF_FAME);
    setGallery(INITIAL_GALLERY);
    setStories(INITIAL_STORIES);
    setRegistrations(INITIAL_REUNION_REGISTRATIONS);
    setReunionSettings(INITIAL_REUNION_SETTINGS);
  };

  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-300 ${
      isLightMode ? 'bg-[#f8fafc] text-slate-900' : 'bg-[#020617] text-slate-100'
    }`}>
      {/* Navigation Bar */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        isLightMode={isLightMode}
        toggleTheme={toggleTheme}
        onOpenShare={() => setIsShareOpen(true)}
        currentUser={currentUser}
        onLogout={handleLogout}
        onOpenEditProfile={() => setIsEditProfileOpen(true)}
        onOpenLoginGate={() => setIsLoginGateOpen(true)}
      />

      {/* Member Access Gate (Modal) - Shown when requested or by member action */}
      {isLoginGateOpen && !currentUser && currentTab !== 'admin' && (
        <MemberAccessGate
          batchmates={batchmates}
          onLoginSuccess={(member) => {
            handleLoginSuccess(member);
            setIsLoginGateOpen(false);
          }}
          onClose={() => setIsLoginGateOpen(false)}
          onAdminBypass={() => {
            setIsLoginGateOpen(false);
            setCurrentTab('admin');
          }}
          isLightMode={isLightMode}
        />
      )}

      {/* Main Content Areas */}
      <main className="flex-1">
        {currentTab === 'admin' ? (
          <div className="pt-20">
            <AdminPanel
              batchmates={batchmates}
              hallOfFame={hallOfFame}
              gallery={gallery}
              stories={stories}
              registrations={registrations}
              reunionSettings={reunionSettings}
              onUpdateReunionSettings={(newSettings) => setReunionSettings(newSettings)}
              onAddBatchmate={handleAddBatchmate}
              onDeleteBatchmate={handleDeleteBatchmate}
              onBulkImportBatchmates={handleBulkImport}
              onAddGalleryItem={handleAddGalleryItem}
              onDeleteGalleryItem={handleDeleteGalleryItem}
              onAddHallOfFame={handleAddHallOfFame}
              onDeleteHallOfFame={handleDeleteHallOfFame}
              onApproveStory={handleApproveStory}
              onDeleteStory={handleDeleteStory}
              onDeleteRegistration={handleDeleteRegistration}
              onResetData={handleResetData}
              isLightMode={isLightMode}
            />
          </div>
        ) : (
          <>
            {/* Hero Section */}
            <Hero
              onNavigate={(tab) => {
                setCurrentTab(tab);
                const elem = document.getElementById(tab);
                if (elem) elem.scrollIntoView({ behavior: 'smooth' });
              }}
              onOpenJoinModal={() => setIsJoinModalOpen(true)}
              onOpenShare={() => setIsShareOpen(true)}
              isLightMode={isLightMode}
              totalMembers={batchmates.length}
              bloodGroupsCount={new Set(batchmates.filter((b) => b.blood).map((b) => b.blood)).size}
              totalMemories={gallery.filter((g) => g.id !== 'gal-campus-01').length + stories.filter((s) => s.status === 'published').length}
            />

            {/* Upcoming Birthdays Notification Strip */}
            <UpcomingBirthdays
              batchmates={batchmates}
              onTriggerModal={(list) => setBirthdayModalBatchmates(list)}
              isLightMode={isLightMode}
            />

            {/* Batchmate Spotlight Marquee */}
            <MemberCarousel
              batchmates={batchmates}
              onSelectMember={(b) => setSelectedBatchmate(b)}
              onViewAll={() => {
                const elem = document.getElementById('directory');
                if (elem) elem.scrollIntoView({ behavior: 'smooth' });
              }}
              onOpenJoinModal={() => setIsJoinModalOpen(true)}
              isLightMode={isLightMode}
            />

            {/* Batchmate Directory Section */}
            <BatchmateDirectory
              batchmates={batchmates}
              onSelectMember={(b) => setSelectedBatchmate(b)}
              currentUser={currentUser}
              onOpenEditProfile={() => setIsEditProfileOpen(true)}
              isLightMode={isLightMode}
            />

            {/* Hall of Fame Section */}
            <HallOfFame
              items={hallOfFame}
              isLightMode={isLightMode}
            />

            {/* Memories Gallery Section */}
            <MemoriesGallery
              galleryItems={gallery}
              onAddGalleryItem={handleAddGalleryItem}
              onDeleteGalleryItem={handleDeleteGalleryItem}
              isLightMode={isLightMode}
            />

            {/* Batch Stories & Memories */}
            <BatchStories
              stories={stories}
              onAddStory={handleAddStory}
              onLikeStory={handleLikeStory}
              isLightMode={isLightMode}
            />

            {/* Blood Bank Directory Section */}
            <BloodDonorDirectory
              batchmates={batchmates}
              isLightMode={isLightMode}
            />

            {/* Reunion Registration Section */}
            <ReunionSection
              registrations={registrations}
              settings={reunionSettings}
              onRegister={handleRegisterReunion}
              isLightMode={isLightMode}
            />
          </>
        )}
      </main>

      {/* Footer */}
      <Footer
        onNavigate={(tab) => {
          setCurrentTab(tab);
          const elem = document.getElementById(tab);
          if (elem) elem.scrollIntoView({ behavior: 'smooth' });
          else window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        isLightMode={isLightMode}
      />

      {/* Batchmate Detail Modal */}
      {selectedBatchmate && (
        <BatchmateDetailModal
          batchmate={selectedBatchmate}
          onClose={() => setSelectedBatchmate(null)}
          isLightMode={isLightMode}
          onDeleteBatchmate={handleDeleteBatchmate}
          currentUser={currentUser}
          onOpenEditProfile={() => setIsEditProfileOpen(true)}
        />
      )}

      {/* Edit Profile Modal for Logged In Batchmate */}
      {currentUser && (
        <EditProfileModal
          isOpen={isEditProfileOpen}
          onClose={() => setIsEditProfileOpen(false)}
          currentUser={currentUser}
          onUpdateProfile={handleUpdateProfile}
          isLightMode={isLightMode}
        />
      )}

      {/* Birthday Celebration Modal */}
      {birthdayModalBatchmates && birthdayModalBatchmates.length > 0 && (
        <BirthdayModal
          birthdayBatchmates={birthdayModalBatchmates}
          onClose={() => setBirthdayModalBatchmates(null)}
          isLightMode={isLightMode}
        />
      )}

      {/* Self Registration Join Batch Modal */}
      <JoinBatchModal
        isOpen={isJoinModalOpen}
        onClose={() => setIsJoinModalOpen(false)}
        onRegisterBatchmate={handleAddBatchmate}
        isLightMode={isLightMode}
      />

      {/* Share / Public Link Modal */}
      <ShareModal
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
        isLightMode={isLightMode}
      />
    </div>
  );
}
