import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Key, 
  Lock, 
  LogOut, 
  Users, 
  Plus, 
  Trash2, 
  Edit, 
  Upload, 
  Check, 
  Image as ImageIcon, 
  Trophy, 
  BookOpen, 
  Calendar, 
  FileSpreadsheet, 
  RefreshCw,
  AlertTriangle,
  Download,
  X,
  Search
} from 'lucide-react';
import { Batchmate, HallOfFameItem, Story, GalleryItem, ReunionRegistration, ReunionSettings, AcademicGroup, BloodGroup } from '../types';
import { compressImageFile } from '../utils/imageUpload';

interface AdminPanelProps {
  batchmates: Batchmate[];
  hallOfFame: HallOfFameItem[];
  gallery: GalleryItem[];
  stories: Story[];
  registrations: ReunionRegistration[];
  reunionSettings: ReunionSettings;
  onUpdateReunionSettings: (settings: ReunionSettings) => void;
  onAddBatchmate: (batchmate: Batchmate) => void;
  onDeleteBatchmate: (id: string) => void;
  onBulkImportBatchmates: (newBatchmates: Batchmate[]) => void;
  onAddGalleryItem: (item: GalleryItem) => void;
  onDeleteGalleryItem: (id: string) => void;
  onAddHallOfFame: (item: HallOfFameItem) => void;
  onDeleteHallOfFame: (id: string) => void;
  onApproveStory: (id: string) => void;
  onDeleteStory: (id: string) => void;
  onDeleteRegistration?: (id: string) => void;
  onResetData: () => void;
  isLightMode: boolean;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  batchmates,
  hallOfFame,
  gallery,
  stories,
  registrations,
  reunionSettings,
  onUpdateReunionSettings,
  onAddBatchmate,
  onDeleteBatchmate,
  onBulkImportBatchmates,
  onAddGalleryItem,
  onDeleteGalleryItem,
  onAddHallOfFame,
  onDeleteHallOfFame,
  onApproveStory,
  onDeleteStory,
  onDeleteRegistration,
  onResetData,
  isLightMode,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState(false);
  const [activeTab, setActiveTab] = useState<'batchmates' | 'import' | 'gallery' | 'fame' | 'stories' | 'reunion'>('batchmates');

  // Admin Password Management State
  const [storedPassword, setStoredPassword] = useState<string>(() => {
    return localStorage.getItem('dcms23_admin_pw') || 'dcms23';
  });
  const [isChangePwOpen, setIsChangePwOpen] = useState(false);
  const [newAdminPw, setNewAdminPw] = useState('');
  const [confirmAdminPw, setConfirmAdminPw] = useState('');
  const [pwChangeSuccess, setPwChangeSuccess] = useState(false);

  // Batchmate Search & Deletion States
  const [adminMemberSearch, setAdminMemberSearch] = useState('');
  const [batchmateToDelete, setBatchmateToDelete] = useState<Batchmate | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Reunion Settings State
  const [reunionDate, setReunionDate] = useState(reunionSettings.targetDate || '2026-12-25T10:00');
  const [reunionDisplayDate, setReunionDisplayDate] = useState(reunionSettings.displayDateText || 'December 25, 2026 • 10:00 AM onwards');
  const [reunionVenue, setReunionVenue] = useState(reunionSettings.venue || 'ধনবাড়ী নওয়াব প্যালেস ও স্কুল অডিটোরিয়াম');
  const [reunionTagline, setReunionTagline] = useState(reunionSettings.tagline || 'স্মৃতির টানে, প্রাণের মেলায়, আবার ফিরি প্রিয় প্রাঙ্গণে...');
  const [reunionSavedNotice, setReunionSavedNotice] = useState(false);

  // Form states for adding batchmate
  const [newBatchmate, setNewBatchmate] = useState({
    name: '',
    nameBangla: '',
    group: 'Science' as AcademicGroup,
    gender: 'Male' as 'Male' | 'Female',
    blood: 'A+',
    dob: '',
    phone: '',
    whatsapp: '',
    email: '',
    address: '',
    currentStatus: '',
    facebook: '',
    bio: '',
    photoUrl: '',
  });

  // Gallery Form
  const [newPhotoUrl, setNewPhotoUrl] = useState('');
  const [newPhotoCaption, setNewPhotoCaption] = useState('');
  const [newPhotoEvent, setNewPhotoEvent] = useState("Farewell & Rag Day '23");

  // Hall of Fame Form
  const [newFameName, setNewFameName] = useState('');
  const [newFameCategory, setNewFameCategory] = useState<'Engineering' | 'Medical' | 'Public University' | 'Leadership'>('Engineering');
  const [newFameAchievement, setNewFameAchievement] = useState('');
  const [newFameInstitution, setNewFameInstitution] = useState('');
  const [newFamePhoto, setNewFamePhoto] = useState('');

  // Bulk import state
  const [sheetUrl, setSheetUrl] = useState('https://docs.google.com/spreadsheets/d/1IkW4D-yGYKweFd2SaXMvSJthxU8XM3D_Xk3HUuH7xrI/export?format=csv');
  const [importStatus, setImportStatus] = useState<string>('');
  const [isImporting, setIsImporting] = useState<boolean>(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === storedPassword || (storedPassword === 'dcms23' && password === 'dcms23')) {
      setIsAuthenticated(true);
      setAuthError(false);
      setPassword('');
    } else {
      setAuthError(true);
    }
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminPw || newAdminPw.length < 4) {
      alert('পাসওয়ার্ড ন্যূনতম ৪ অক্ষরের হতে হবে।');
      return;
    }
    if (newAdminPw !== confirmAdminPw) {
      alert('নতুন পাসওয়ার্ড দুটি মিলছে না!');
      return;
    }
    localStorage.setItem('dcms23_admin_pw', newAdminPw);
    setStoredPassword(newAdminPw);
    setPwChangeSuccess(true);
    setTimeout(() => {
      setPwChangeSuccess(false);
      setIsChangePwOpen(false);
      setNewAdminPw('');
      setConfirmAdminPw('');
    }, 2000);
  };

  const handleCreateBatchmate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBatchmate.name.trim()) return;

    let bday = '';
    if (newBatchmate.dob) {
      const parts = newBatchmate.dob.split('-');
      if (parts.length === 3) {
        bday = `${parts[1]}-${parts[2]}`;
      }
    }

    const created: Batchmate = {
      id: `dcms23-${Date.now()}`,
      name: newBatchmate.name.trim(),
      nameBangla: newBatchmate.nameBangla.trim() || undefined,
      group: newBatchmate.group,
      gender: newBatchmate.gender,
      blood: newBatchmate.blood,
      dob: newBatchmate.dob || undefined,
      birthday: bday || undefined,
      phone: newBatchmate.phone.trim(),
      whatsapp: newBatchmate.whatsapp.trim() || newBatchmate.phone.trim(),
      email: newBatchmate.email.trim() || undefined,
      address: newBatchmate.address.trim() || 'Dhanbari, Tangail',
      currentStatus: newBatchmate.currentStatus.trim() || undefined,
      facebook: newBatchmate.facebook.trim() || undefined,
      bio: newBatchmate.bio.trim() || undefined,
      photoUrl: newBatchmate.photoUrl.trim() || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    };

    onAddBatchmate(created);
    setNewBatchmate({
      name: '',
      nameBangla: '',
      group: 'Science',
      gender: 'Male',
      blood: 'A+',
      dob: '',
      phone: '',
      whatsapp: '',
      email: '',
      address: '',
      currentStatus: '',
      facebook: '',
      bio: '',
      photoUrl: '',
    });
    alert('Batchmate added successfully!');
  };

  const handleAddPhoto = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPhotoUrl.trim()) return;

    onAddGalleryItem({
      id: `photo-${Date.now()}`,
      url: newPhotoUrl.trim(),
      caption: newPhotoCaption.trim() || undefined,
      type: 'photo',
      eventName: newPhotoEvent,
      timestamp: Date.now(),
    });

    setNewPhotoUrl('');
    setNewPhotoCaption('');
    alert('Photo added to gallery!');
  };

  const handleAddFame = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFameName.trim() || !newFameAchievement.trim()) return;

    onAddHallOfFame({
      id: `fame-${Date.now()}`,
      name: newFameName.trim(),
      category: newFameCategory,
      achievement: newFameAchievement.trim(),
      institution: newFameInstitution.trim() || undefined,
      photoUrl: newFamePhoto.trim() || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80',
      year: '2023-2024',
    });

    setNewFameName('');
    setNewFameAchievement('');
    setNewFameInstitution('');
    setNewFamePhoto('');
    alert('Achiever added to Hall of Fame!');
  };

  const parseCsvText = (text: string) => {
    const lines = text.split(/\r?\n/).filter(line => line.trim().length > 0);
    if (lines.length <= 1) return [];

    const result: Batchmate[] = [];
    // Skip header line
    for (let i = 1; i < lines.length; i++) {
      // Basic CSV splitter handling quotes
      const row: string[] = [];
      let inQuotes = false;
      let curr = '';

      for (let ch of lines[i]) {
        if (ch === '"') {
          inQuotes = !inQuotes;
        } else if (ch === ',' && !inQuotes) {
          row.push(curr.trim());
          curr = '';
        } else {
          curr += ch;
        }
      }
      row.push(curr.trim());

      const name = row[1];
      if (!name) continue;

      const rawDob = row[2] || '';
      // Parse MM-DD
      let bday = '';
      if (rawDob.includes('/')) {
        const parts = rawDob.split('/');
        if (parts.length >= 2) {
          bday = `${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
        }
      }

      const gender = (row[3] || 'Male').toLowerCase().includes('female') ? 'Female' : 'Male';
      const blood = row[4] ? row[4].replace(/[^A-Za-z+-]/g, '') : 'O+';
      const address = row[5] || 'Dhanbari, Tangail';
      const phone = row[6] || '';
      const whatsapp = row[7] || phone;
      const email = row[8] || '';
      const facebook = row[9] || '';
      const bio = row[11] || '';
      let photoUrl = row[12] || '';

      if (photoUrl.includes('drive.google.com')) {
        const idMatch = photoUrl.match(/id=([a-zA-Z0-9_-]+)/);
        if (idMatch) {
          photoUrl = `https://lh3.googleusercontent.com/d/${idMatch[1]}`;
        }
      }

      result.push({
        id: `import-${i}-${Date.now()}`,
        name,
        group: i % 3 === 0 ? 'Commerce' : i % 5 === 0 ? 'Humanities' : 'Science',
        gender,
        blood,
        dob: rawDob,
        birthday: bday || undefined,
        address,
        phone,
        whatsapp,
        email,
        facebook,
        bio,
        photoUrl: photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
        currentStatus: undefined,
      });
    }
    return result;
  };

  const handleGoogleSheetImport = async () => {
    if (!sheetUrl.trim()) return;
    setIsImporting(true);
    setImportStatus('Connecting to Google Sheet...');

    try {
      // Use direct fetch or proxy
      let csvContent = '';
      try {
        const res = await fetch(sheetUrl);
        if (res.ok) {
          csvContent = await res.text();
        }
      } catch (err) {
        // Fallback to proxy
        const proxyRes = await fetch(`https://api.allorigins.win/raw?url=${encodeURIComponent(sheetUrl)}`);
        if (proxyRes.ok) {
          csvContent = await proxyRes.text();
        }
      }

      if (!csvContent) {
        throw new Error('Could not fetch CSV from the provided URL. Ensure sheet is set to "Anyone with link can view"');
      }

      const imported = parseCsvText(csvContent);
      if (imported.length === 0) {
        throw new Error('No valid batchmate records parsed from the sheet.');
      }

      onBulkImportBatchmates(imported);
      setImportStatus(`Successfully synced and imported ${imported.length} batchmates!`);
    } catch (e: any) {
      setImportStatus(`Import Error: ${e.message}`);
    } finally {
      setIsImporting(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const imported = parseCsvText(text);
        if (imported.length > 0) {
          onBulkImportBatchmates(imported);
          alert(`Successfully imported ${imported.length} batchmates from CSV file!`);
        } else {
          alert('No valid student rows found in the CSV.');
        }
      } catch (err: any) {
        alert(`Error parsing file: ${err.message}`);
      }
    };
    reader.readAsText(file);
  };

  const handleExportReunionCsv = () => {
    if (registrations.length === 0) {
      alert('No registrations to export.');
      return;
    }

    const headers = 'Name,Group,Phone,Email,Address,T-Shirt Size,Guests,Notes,Registered Date\n';
    const rows = registrations
      .map((r) => `"${r.name}","${r.group}","${r.phone}","${r.email || ''}","${r.address}","${r.tshirtSize}",${r.guestCount},"${r.notes || ''}","${new Date(r.timestamp).toLocaleDateString()}"`)
      .join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dcms-batch23-reunion-registrations-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!isAuthenticated) {
    return (
      <section id="admin" className="py-20 px-4 max-w-md mx-auto">
        <div className={`p-8 rounded-3xl border shadow-2xl text-center ${
          isLightMode ? 'bg-white border-amber-300' : 'bg-slate-900 border-amber-500/30'
        }`}>
          <div className="w-16 h-16 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-amber-400/20">
            <Lock className="w-8 h-8" />
          </div>

          <h2 className="text-2xl font-black gradient-text mb-1">
            DCMS Batch '23 Admin
          </h2>
          <p className="text-xs text-slate-400 mb-6 font-['Hind_Siliguri']">
            ম্যানেজমেন্ট প্যানেলে প্রবেশের জন্য পাসওয়ার্ড প্রদান করুন
          </p>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="relative">
              <Key className="w-4 h-4 text-amber-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="গোপন পাসওয়ার্ড লিখুন (Enter Password)"
                className={`w-full pl-10 pr-4 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                  isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                }`}
              />
            </div>

            {authError && (
              <p className="text-xs text-rose-500 font-medium">
                ভুল পাসওয়ার্ড! অনুগ্রহ করে সঠিক পাসওয়ার্ড দিন।
              </p>
            )}

            <button
              type="submit"
              className="btn-gold w-full py-2.5 text-xs font-bold shadow-md cursor-pointer"
            >
              লগইন করুন (Unlock Dashboard)
            </button>
          </form>
        </div>
      </section>
    );
  }

  return (
    <section id="admin" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-8 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold gradient-text">
              Admin Control Center
            </h2>
            <p className="text-xs text-slate-400">
              Manage DCMS Batch '23 Directory, Gallery, Hall of Fame & Registrations
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsChangePwOpen(true)}
            className="px-3 py-1.5 rounded-xl text-xs font-bold border border-amber-400/40 text-amber-300 hover:bg-amber-400/10 flex items-center gap-1.5 cursor-pointer"
          >
            <Key className="w-3.5 h-3.5" />
            <span>পাসওয়ার্ড পরিবর্তন</span>
          </button>

          <button
            onClick={() => {
              onResetData();
              showToast('✓ ডেমো ডেটা সফলভাবে রিসেট করা হয়েছে!');
            }}
            title="Reset to default initial data"
            className="px-3 py-1.5 rounded-xl text-xs font-bold border border-rose-500/40 text-rose-400 hover:bg-rose-500/10 flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset Demo Data</span>
          </button>

          <button
            onClick={() => setIsAuthenticated(false)}
            className="px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* Change Password Modal */}
      {isChangePwOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
          <div className={`relative w-full max-w-sm rounded-3xl p-6 border shadow-2xl ${
            isLightMode ? 'bg-white border-amber-300 text-slate-800' : 'bg-slate-900 border-amber-500/40 text-slate-100'
          }`}>
            <button
              onClick={() => setIsChangePwOpen(false)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-base font-bold gradient-text mb-1">
              অ্যাডমিন পাসওয়ার্ড পরিবর্তন করুন
            </h3>
            <p className="text-xs text-slate-400 mb-4 font-['Hind_Siliguri']">
              আপনার নিজস্ব গোপন পাসওয়ার্ড সেট করুন।
            </p>

            {pwChangeSuccess ? (
              <div className="p-4 text-center text-emerald-400 text-xs font-bold bg-emerald-500/10 border border-emerald-500/30 rounded-xl">
                ✓ পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে!
              </div>
            ) : (
              <form onSubmit={handleChangePassword} className="space-y-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-300 mb-1">নতুন পাসওয়ার্ড *</label>
                  <input
                    type="password"
                    required
                    value={newAdminPw}
                    onChange={(e) => setNewAdminPw(e.target.value)}
                    placeholder="কমপক্ষে ৪ অক্ষরের পাসওয়ার্ড"
                    className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-300 mb-1">পাসওয়ার্ড নিশ্চিত করুন *</label>
                  <input
                    type="password"
                    required
                    value={confirmAdminPw}
                    onChange={(e) => setConfirmAdminPw(e.target.value)}
                    placeholder="একই পাসওয়ার্ড পুনরায় লিখুন"
                    className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                  />
                </div>

                <button
                  type="submit"
                  className="btn-gold w-full py-2.5 text-xs font-bold cursor-pointer mt-2"
                >
                  পাসওয়ার্ড সেভ করুন
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Admin Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar mb-8">
        {[
          { id: 'batchmates', label: `Batchmates (${batchmates.length})`, icon: Users },
          { id: 'import', label: 'Google Sheet & Bulk Sync', icon: FileSpreadsheet },
          { id: 'gallery', label: `Gallery (${gallery.length})`, icon: ImageIcon },
          { id: 'fame', label: `Hall of Fame (${hallOfFame.length})`, icon: Trophy },
          { id: 'stories', label: `Stories (${stories.length})`, icon: BookOpen },
          { id: 'reunion', label: `Reunion (${registrations.length})`, icon: Calendar },
        ].map((tab) => {
          const Icon = tab.icon;
          const isSel = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-shrink-0 px-4 py-2 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                isSel
                  ? 'bg-amber-400 text-slate-950 shadow-md'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: Batchmates Management */}
      {activeTab === 'batchmates' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Add form */}
          <div className="lg:col-span-5 glass p-6 rounded-3xl border border-amber-500/20">
            <h3 className="text-base font-bold text-amber-400 mb-4 flex items-center gap-2">
              <Plus className="w-4 h-4" />
              <span>Add New Batchmate</span>
            </h3>

            <form onSubmit={handleCreateBatchmate} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-400 mb-1">Full Name (English) *</label>
                <input
                  type="text"
                  required
                  value={newBatchmate.name}
                  onChange={(e) => setNewBatchmate({ ...newBatchmate, name: e.target.value })}
                  placeholder="e.g. Asaduzzaman Abir"
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-400 mb-1">Bangla Name (ঐচ্ছিক)</label>
                <input
                  type="text"
                  value={newBatchmate.nameBangla}
                  onChange={(e) => setNewBatchmate({ ...newBatchmate, nameBangla: e.target.value })}
                  placeholder="যেমন: আসাদুজ্জামান আবির"
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Group *</label>
                  <select
                    value={newBatchmate.group}
                    onChange={(e) => setNewBatchmate({ ...newBatchmate, group: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                  >
                    <option value="Science">Science</option>
                    <option value="Commerce">Commerce</option>
                    <option value="Humanities">Humanities</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Blood Group</label>
                  <select
                    value={newBatchmate.blood}
                    onChange={(e) => setNewBatchmate({ ...newBatchmate, blood: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                  >
                    {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((bg) => (
                      <option key={bg} value={bg}>{bg}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    value={newBatchmate.phone}
                    onChange={(e) => setNewBatchmate({ ...newBatchmate, phone: e.target.value })}
                    placeholder="01700-000000"
                    className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Date of Birth</label>
                  <input
                    type="date"
                    value={newBatchmate.dob}
                    onChange={(e) => setNewBatchmate({ ...newBatchmate, dob: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-400 mb-1">Address / Hometown</label>
                <input
                  type="text"
                  value={newBatchmate.address}
                  onChange={(e) => setNewBatchmate({ ...newBatchmate, address: e.target.value })}
                  placeholder="e.g. College Para, Dhanbari"
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-400 mb-1">Current University / Status</label>
                <input
                  type="text"
                  value={newBatchmate.currentStatus}
                  onChange={(e) => setNewBatchmate({ ...newBatchmate, currentStatus: e.target.value })}
                  placeholder="e.g. Dhaka University (Economics)"
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-amber-400 mb-1">
                  ব্যাচমেটের ছবি (ডিভাইস গ্যালারি থেকে সিলেক্ট করুন)
                </label>
                <div className="border border-dashed border-amber-400/40 rounded-xl p-2.5 text-center bg-slate-950/40 mb-2">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        try {
                          const compressed = await compressImageFile(file, 800, 0.85);
                          setNewBatchmate({ ...newBatchmate, photoUrl: compressed });
                        } catch (err: any) {
                          alert('Error loading image: ' + err.message);
                        }
                      }
                    }}
                    className="text-xs text-slate-300 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-amber-400 file:text-slate-950 hover:file:bg-amber-300 cursor-pointer"
                  />
                  {newBatchmate.photoUrl && (
                    <div className="mt-2 flex items-center justify-center">
                      <img src={newBatchmate.photoUrl} alt="Preview" className="w-14 h-14 rounded-full object-cover border-2 border-amber-400" />
                    </div>
                  )}
                </div>
                <input
                  type="url"
                  value={newBatchmate.photoUrl.startsWith('data:') ? '' : newBatchmate.photoUrl}
                  onChange={(e) => setNewBatchmate({ ...newBatchmate, photoUrl: e.target.value })}
                  placeholder="অথবা ছবির অনলাইন URL দিন (https://...)"
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-400 mb-1">Bio / Message to Batch</label>
                <textarea
                  rows={2}
                  value={newBatchmate.bio}
                  onChange={(e) => setNewBatchmate({ ...newBatchmate, bio: e.target.value })}
                  placeholder="বাণী বা প্রিয় উক্তি..."
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <button
                type="submit"
                className="btn-gold w-full py-2.5 text-xs font-bold cursor-pointer"
              >
                Add Batchmate to Directory
              </button>
            </form>
          </div>

          {/* List of Batchmates */}
          <div className="lg:col-span-7 glass p-6 rounded-3xl border border-amber-500/20">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                  <span>Existing Batchmates</span>
                  <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30">
                    {batchmates.length}
                  </span>
                </h3>

                {batchmates.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      batchmates.forEach((b) => onDeleteBatchmate(b.id));
                      showToast('✓ সকল ব্যাচমেট তালিকা থেকে মুছে ফেলা হয়েছে!');
                    }}
                    className="px-2.5 py-1 rounded-xl text-[11px] font-bold border border-rose-500/40 text-rose-400 hover:bg-rose-500 hover:text-white transition-all cursor-pointer flex items-center gap-1"
                    title="সকল ব্যাচমেট এক ক্লিকে মুছে ফেলুন"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>সব মুছুন</span>
                  </button>
                )}
              </div>

              {/* Search Box in Admin */}
              <div className="relative w-full sm:w-56">
                <Search className="w-3.5 h-3.5 text-amber-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={adminMemberSearch}
                  onChange={(e) => setAdminMemberSearch(e.target.value)}
                  placeholder="নাম বা রোল দিয়ে খুঁজুন..."
                  className="w-full pl-8 pr-3 py-1.5 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            {/* List */}
            <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
              {batchmates
                .filter((b) => {
                  if (!adminMemberSearch) return true;
                  const query = adminMemberSearch.toLowerCase();
                  return (
                    b.name.toLowerCase().includes(query) ||
                    (b.nameBangla && b.nameBangla.includes(query)) ||
                    (b.rollNumber && b.rollNumber.includes(query)) ||
                    b.group.toLowerCase().includes(query)
                  );
                })
                .map((b) => (
                  <div
                    key={b.id}
                    className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-3 hover:border-amber-400/30 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={b.photoUrl}
                        alt={b.name}
                        className="w-9 h-9 rounded-full object-cover border border-amber-400/30 flex-shrink-0"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(b.name)}&background=0f172a&color=fbbf24`;
                        }}
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-slate-200 truncate">{b.name}</h4>
                          {b.rollNumber && (
                            <span className="text-[10px] text-amber-400 font-mono">#{b.rollNumber}</span>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400 truncate">
                          {b.group} • {b.blood} • 📞 {b.phone}
                          {b.hidePhone && (
                            <span className="ml-1 px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30 text-[9px]">
                              [গোপন / Private]
                            </span>
                          )}
                        </p>
                        <p className="text-[9px] text-slate-500 truncate">{b.address}</p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setBatchmateToDelete(b)}
                      className="px-2.5 py-1.5 rounded-xl text-xs font-bold border border-rose-500/40 text-rose-400 hover:bg-rose-500 hover:text-white transition-all cursor-pointer flex items-center gap-1.5 flex-shrink-0"
                      title="মুছে ফেলুন"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>মুছুন</span>
                    </button>
                  </div>
                ))}

              {batchmates.length === 0 && (
                <div className="text-center py-8 text-xs text-slate-400 font-['Hind_Siliguri']">
                  কোনো ব্যাচমেটের তথ্য পাওয়া যায়নি।
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* In-App Delete Confirmation Modal (NO blocked window.confirm) */}
      {batchmateToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
          <div className="relative w-full max-w-sm rounded-3xl p-6 bg-slate-900 border border-rose-500/40 text-slate-100 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mb-3">
              <Trash2 className="w-6 h-6" />
            </div>

            <h4 className="text-base font-bold text-white mb-1">
              ব্যাচমেট মুছে ফেলতে চান?
            </h4>
            <p className="text-xs text-slate-300 mb-4 font-['Hind_Siliguri']">
              আপনি কি নিশ্চিত যে <strong className="text-amber-400">{batchmateToDelete.name}</strong> ({batchmateToDelete.group} বিভাগ) এর তথ্য ডিরেক্টরি থেকে মুছে ফেলতে চান?
            </p>

            <div className="flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setBatchmateToDelete(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
              >
                বাতিল করুন
              </button>
              <button
                type="button"
                onClick={() => {
                  const targetId = batchmateToDelete.id;
                  const targetName = batchmateToDelete.name;
                  onDeleteBatchmate(targetId);
                  setBatchmateToDelete(null);
                  showToast(`✓ ${targetName} সফলভাবে মুছে ফেলা হয়েছে!`);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white transition-colors cursor-pointer shadow-lg shadow-rose-600/30 flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>হ্যাঁ, মুছে ফেলুন</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Success Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 px-4 py-3 rounded-2xl bg-emerald-600 text-white font-bold text-xs shadow-2xl flex items-center gap-2 animate-bounce">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Tab 2: Bulk Import (Google Sheets & CSV) */}
      {activeTab === 'import' && (
        <div className="max-w-2xl mx-auto glass p-8 rounded-3xl border border-amber-500/30">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold gradient-text">
                Google Sheets & CSV Bulk Sync
              </h3>
              <p className="text-xs text-slate-400 font-['Hind_Siliguri']">
                গুগল শিট বা সিএসভি ফাইল থেকে এক ক্লিকে সকল ব্যাচমেটের তথ্য ইমপোর্ট করুন।
              </p>
            </div>
          </div>

          <div className="space-y-6">
            {/* Direct Google Sheet Sync */}
            <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-3">
              <label className="block text-xs font-bold text-amber-400">
                Google Sheets Export CSV Link
              </label>
              <input
                type="url"
                value={sheetUrl}
                onChange={(e) => setSheetUrl(e.target.value)}
                placeholder="https://docs.google.com/spreadsheets/d/.../export?format=csv"
                className="w-full px-3 py-2 rounded-xl text-xs bg-slate-900 border border-slate-700 text-white"
              />
              <button
                onClick={handleGoogleSheetImport}
                disabled={isImporting}
                className="btn-gold w-full py-2.5 text-xs font-bold flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isImporting ? 'animate-spin' : ''}`} />
                <span>{isImporting ? 'Syncing...' : 'Sync Now with Google Sheet'}</span>
              </button>
            </div>

            {/* Upload CSV File */}
            <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 text-center">
              <span className="block text-xs font-bold text-slate-300 mb-2">
                Or Upload CSV File Directly from Your Computer
              </span>
              <label className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 text-amber-400 text-xs font-bold cursor-pointer hover:bg-slate-700">
                <Upload className="w-4 h-4" />
                <span>Choose .csv file</span>
                <input
                  type="file"
                  accept=".csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            {importStatus && (
              <div className="p-3 rounded-xl bg-amber-400/10 border border-amber-400/30 text-amber-300 text-xs font-semibold">
                {importStatus}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 3: Gallery Manager */}
      {activeTab === 'gallery' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-5 glass p-6 rounded-3xl border border-amber-500/20">
            <h3 className="text-base font-bold text-amber-400 mb-4 flex items-center gap-2">
              <Plus className="w-4 h-4" />
              <span>Add Memory to Gallery</span>
            </h3>

            <form onSubmit={handleAddPhoto} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-amber-400 mb-1">
                  গ্যালারি / ডিভাইস থেকে ছবি সিলেক্ট করুন
                </label>
                <div className="border border-dashed border-amber-400/40 rounded-xl p-3 text-center bg-slate-950/40 mb-2">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        try {
                          const compressed = await compressImageFile(file, 1400, 0.85);
                          setNewPhotoUrl(compressed);
                        } catch (err: any) {
                          alert('Error loading image: ' + err.message);
                        }
                      }
                    }}
                    className="text-xs text-slate-300 file:mr-2 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-amber-400 file:text-slate-950 hover:file:bg-amber-300 cursor-pointer"
                  />
                  {newPhotoUrl && (
                    <div className="mt-2 flex flex-col items-center">
                      <img src={newPhotoUrl} alt="Preview" className="h-24 max-w-full object-cover rounded-lg border border-amber-400/30" />
                      <span className="text-[10px] text-emerald-400 font-bold mt-1">✓ ছবি লোড হয়েছে</span>
                    </div>
                  )}
                </div>

                <div className="text-[10px] text-slate-500 mb-1 text-center">অথবা ছবির অনলাইন URL দিন:</div>
                <input
                  type="url"
                  value={newPhotoUrl.startsWith('data:') ? '' : newPhotoUrl}
                  onChange={(e) => setNewPhotoUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Event / Album *</label>
                <select
                  value={newPhotoEvent}
                  onChange={(e) => setNewPhotoEvent(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                >
                  <option value="Farewell & Rag Day '23">Farewell & Rag Day '23</option>
                  <option value="SSC Examination 2023">SSC Examination 2023</option>
                  <option value="Annual Sports & Cultural Week">Annual Sports & Cultural Week</option>
                  <option value="Classroom & Campus Life">Classroom & Campus Life</option>
                  <option value="Annual Tour 2023">Annual Tour 2023</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Caption (ঐচ্ছিক)</label>
                <input
                  type="text"
                  value={newPhotoCaption}
                  onChange={(e) => setNewPhotoCaption(e.target.value)}
                  placeholder="ছবির বর্ণনা বা ক্যাপশন..."
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <button
                type="submit"
                className="btn-gold w-full py-2.5 text-xs font-bold cursor-pointer"
              >
                Add Photo to Gallery
              </button>
            </form>
          </div>

          <div className="lg:col-span-7 glass p-6 rounded-3xl border border-amber-500/20">
            <h3 className="text-base font-bold text-slate-100 mb-4">
              Current Gallery Photos ({gallery.length})
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[500px] overflow-y-auto pr-1">
              {gallery.map((photo) => (
                <div key={photo.id} className="relative rounded-2xl overflow-hidden aspect-video border border-slate-800 bg-slate-950 shadow-md group">
                  <img src={photo.url} alt={photo.caption || ''} className="w-full h-full object-cover" />
                  
                  {/* Delete button permanently visible at top-right for mobile & touch friendliness */}
                  <button
                    type="button"
                    onClick={() => {
                      onDeleteGalleryItem(photo.id);
                      showToast('✓ ছবিটি সফলভাবে মুছে ফেলা হয়েছে!');
                    }}
                    className="absolute top-2 right-2 p-2 rounded-xl bg-slate-950/85 hover:bg-rose-600 text-rose-400 hover:text-white border border-rose-500/40 backdrop-blur-md transition-all cursor-pointer z-10 shadow-lg"
                    title="ছবিটি মুছুন"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>

                  {/* Caption badge at bottom */}
                  {photo.caption && (
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-slate-950/90 to-transparent p-2">
                      <p className="text-[10px] text-slate-200 truncate font-['Hind_Siliguri']">
                        {photo.caption}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Hall of Fame Manager */}
      {activeTab === 'fame' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-5 glass p-6 rounded-3xl border border-amber-500/20">
            <h3 className="text-base font-bold text-amber-400 mb-4 flex items-center gap-2">
              <Plus className="w-4 h-4" />
              <span>Add Achiever to Hall of Fame</span>
            </h3>

            <form onSubmit={handleAddFame} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Achiever's Name *</label>
                <input
                  type="text"
                  required
                  value={newFameName}
                  onChange={(e) => setNewFameName(e.target.value)}
                  placeholder="e.g. Tanvir Ahmed Shanto"
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Category *</label>
                <select
                  value={newFameCategory}
                  onChange={(e) => setNewFameCategory(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                >
                  <option value="Engineering">Engineering (BUET / CKRUET)</option>
                  <option value="Medical">Medical (DMC / RMC / SSMC)</option>
                  <option value="Public University">Public University (DU / JU / RU)</option>
                  <option value="Leadership">Debate & Leadership</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Institution</label>
                <input
                  type="text"
                  value={newFameInstitution}
                  onChange={(e) => setNewFameInstitution(e.target.value)}
                  placeholder="e.g. BUET (CSE)"
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Achievement Description *</label>
                <textarea
                  rows={3}
                  required
                  value={newFameAchievement}
                  onChange={(e) => setNewFameAchievement(e.target.value)}
                  placeholder="e.g. Secured Top Merit Position in National Entrance..."
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Photo URL</label>
                <input
                  type="url"
                  value={newFamePhoto}
                  onChange={(e) => setNewFamePhoto(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <button
                type="submit"
                className="btn-gold w-full py-2.5 text-xs font-bold cursor-pointer"
              >
                Add to Hall of Fame
              </button>
            </form>
          </div>

          <div className="lg:col-span-7 glass p-6 rounded-3xl border border-amber-500/20">
            <h3 className="text-base font-bold text-slate-100 mb-4">
              Current Hall of Fame Achievers ({hallOfFame.length})
            </h3>

            <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
              {hallOfFame.map((item) => (
                <div key={item.id} className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img src={item.photoUrl} alt={item.name} className="w-10 h-10 rounded-xl object-cover border border-amber-400/40" />
                    <div>
                      <h4 className="text-xs font-bold text-slate-200">{item.name}</h4>
                      <p className="text-[10px] text-amber-400 font-semibold">{item.category} • {item.institution}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => onDeleteHallOfFame(item.id)}
                    className="p-2 text-rose-400 hover:bg-rose-500/20 rounded-xl transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Story Moderation */}
      {activeTab === 'stories' && (
        <div className="glass p-6 rounded-3xl border border-amber-500/20 max-w-4xl mx-auto">
          <h3 className="text-base font-bold text-slate-100 mb-6 flex items-center justify-between">
            <span>Submitted Stories ({stories.length})</span>
          </h3>

          <div className="space-y-4">
            {stories.map((s) => (
              <div key={s.id} className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
                <div className="flex items-start justify-between gap-4 mb-2">
                  <div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full mr-2 ${
                      s.status === 'published' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-400/20 text-amber-400'
                    }`}>
                      {s.status.toUpperCase()}
                    </span>
                    <h4 className="text-sm font-bold text-slate-100 inline">{s.title}</h4>
                    <p className="text-xs text-slate-400 mt-0.5">By {s.author} • {s.date}</p>
                  </div>

                  <div className="flex items-center gap-2">
                    {s.status === 'pending' && (
                      <button
                        onClick={() => onApproveStory(s.id)}
                        className="px-3 py-1 rounded-xl text-xs font-bold bg-emerald-600 text-white hover:bg-emerald-500 flex items-center gap-1 cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Approve</span>
                      </button>
                    )}
                    <button
                      onClick={() => onDeleteStory(s.id)}
                      className="p-1.5 text-rose-400 hover:bg-rose-500/20 rounded-lg cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <p className="text-xs text-slate-300 font-['Hind_Siliguri'] mt-2 leading-relaxed">
                  {s.content}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 6: Reunion Settings & Registrations */}
      {activeTab === 'reunion' && (
        <div className="space-y-8 max-w-5xl mx-auto">
          {/* Reunion Date & Venue Settings Card */}
          <div className="glass p-6 sm:p-8 rounded-3xl border border-amber-500/30">
            <div className="flex items-center justify-between gap-4 mb-4 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold gradient-text">
                    রিইউনিয়ন তারিখ ও স্থান পরিবর্তন (Reunion Date & Venue Settings)
                  </h3>
                  <p className="text-xs text-slate-400 font-['Hind_Siliguri']">
                    এখান থেকে আপনি যেকোনো সময় রিইউনিয়নের দিনক্ষণ ও ভেন্যু পরিবর্তন করতে পারবেন।
                  </p>
                </div>
              </div>

              {reunionSavedNotice && (
                <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/40 animate-pulse">
                  <Check className="w-4 h-4" />
                  <span>তারিখ সফলভাবে আপডেট হয়েছে!</span>
                </div>
              )}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                onUpdateReunionSettings({
                  targetDate: reunionDate,
                  displayDateText: reunionDisplayDate,
                  venue: reunionVenue,
                  tagline: reunionTagline,
                });
                setReunionSavedNotice(true);
                setTimeout(() => setReunionSavedNotice(false), 3000);
              }}
              className="grid grid-cols-1 sm:grid-cols-2 gap-4"
            >
              <div>
                <label className="block text-xs font-bold text-amber-400 mb-1">
                  Reunion Date & Time (কাউন্টডাউন টাইমার তারিখ) *
                </label>
                <input
                  type="datetime-local"
                  required
                  value={reunionDate}
                  onChange={(e) => setReunionDate(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  কাউন্টডাউন ঘড়ি এই তারিখ অনুযায়ী স্বয়ংক্রিয়ভাবে চলবে।
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-amber-400 mb-1">
                  Display Date Text (ব্যানারে প্রদর্শিত তারিখের লেখা) *
                </label>
                <input
                  type="text"
                  required
                  value={reunionDisplayDate}
                  onChange={(e) => setReunionDisplayDate(e.target.value)}
                  placeholder="e.g. December 25, 2026 • 10:00 AM onwards"
                  className="w-full px-3 py-2.5 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Venue / স্থান *
                </label>
                <input
                  type="text"
                  required
                  value={reunionVenue}
                  onChange={(e) => setReunionVenue(e.target.value)}
                  placeholder="যেমন: ধনবাড়ী নওয়াব প্যালেস ও স্কুল অডিটোরিয়াম"
                  className="w-full px-3 py-2.5 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Slogan / স্লোগান
                </label>
                <input
                  type="text"
                  value={reunionTagline}
                  onChange={(e) => setReunionTagline(e.target.value)}
                  placeholder="যেমন: স্মৃতির টানে, প্রাণের মেলায়, আবার ফিরি প্রিয় প্রাঙ্গণে..."
                  className="w-full px-3 py-2.5 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                />
              </div>

              <div className="sm:col-span-2 pt-2">
                <button
                  type="submit"
                  className="btn-gold px-6 py-2.5 text-xs font-bold cursor-pointer flex items-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  <span>তারিখ ও সেটিংস সংরক্ষণ করুন (Save Reunion Settings)</span>
                </button>
              </div>
            </form>
          </div>

          {/* Registrations List */}
          <div className="glass p-6 rounded-3xl border border-amber-500/20">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-100">
                  Reunion Registrations ({registrations.length})
                </h3>
                <p className="text-xs text-slate-400">
                  Total Guests: {registrations.reduce((acc, r) => acc + 1 + r.guestCount, 0)} people
                </p>
              </div>

            <button
              onClick={handleExportReunionCsv}
              className="btn-gold px-4 py-2 text-xs font-bold flex items-center gap-2 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV (ডাউনলোড করুন)</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/80 text-slate-400 uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Name</th>
                  <th className="py-2.5 px-3">Group</th>
                  <th className="py-2.5 px-3">Phone</th>
                  <th className="py-2.5 px-3">T-Shirt</th>
                  <th className="py-2.5 px-3">Guests</th>
                  <th className="py-2.5 px-3">Address</th>
                  <th className="py-2.5 px-3">Notes</th>
                  <th className="py-2.5 px-3 text-right">Delete</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-medium">
                {registrations.map((reg) => (
                  <tr key={reg.id} className="hover:bg-slate-950/40">
                    <td className="py-2.5 px-3 font-bold text-slate-200">{reg.name}</td>
                    <td className="py-2.5 px-3 text-amber-400">{reg.group}</td>
                    <td className="py-2.5 px-3 text-slate-300">{reg.phone}</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded-full bg-slate-800 text-amber-300 font-bold">
                        {reg.tshirtSize}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-400">{reg.guestCount}</td>
                    <td className="py-2.5 px-3 text-slate-400 truncate max-w-[150px]">{reg.address}</td>
                    <td className="py-2.5 px-3 text-slate-400 italic truncate max-w-[150px]">{reg.notes || '-'}</td>
                    <td className="py-2.5 px-3 text-right">
                      {onDeleteRegistration && (
                        <button
                          type="button"
                          onClick={() => onDeleteRegistration(reg.id)}
                          title="রেজিস্ট্রেশন ডিলিট করুন"
                          className="p-1.5 rounded-lg bg-rose-500/15 text-rose-400 hover:bg-rose-600 hover:text-white transition-colors cursor-pointer inline-flex items-center gap-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span className="text-[10px] font-bold">Delete</span>
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        </div>
      )}
    </section>
  );
};
