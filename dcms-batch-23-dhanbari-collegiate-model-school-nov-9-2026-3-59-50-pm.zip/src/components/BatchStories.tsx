import React, { useState } from 'react';
import { BookOpen, Heart, PlusCircle, MessageSquare, Sparkles, User, Calendar, CheckCircle2, X } from 'lucide-react';
import { Story, AcademicGroup } from '../types';

interface BatchStoriesProps {
  stories: Story[];
  onAddStory: (story: Omit<Story, 'id' | 'likes' | 'status' | 'timestamp'>) => void;
  onLikeStory: (storyId: string) => void;
  isLightMode: boolean;
}

export const BatchStories: React.FC<BatchStoriesProps> = ({
  stories,
  onAddStory,
  onLikeStory,
  isLightMode,
}) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [group, setGroup] = useState<AcademicGroup>('Science');
  const [content, setContent] = useState('');
  const [submittedMessage, setSubmittedMessage] = useState(false);

  const publishedStories = stories.filter((s) => s.status === 'published');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !author.trim() || !content.trim()) return;

    onAddStory({
      title: title.trim(),
      author: author.trim(),
      authorGroup: group,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      content: content.trim(),
      photoUrl: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=800&auto=format&fit=crop&q=80',
    });

    setTitle('');
    setAuthor('');
    setContent('');
    setSubmittedMessage(true);
    setTimeout(() => {
      setSubmittedMessage(false);
      setModalOpen(false);
    }, 2500);
  };

  return (
    <section id="stories" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-semibold mb-3">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Campus Memories • স্মৃতিচারণ</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold gradient-text mb-2">
            Stories From DCMS Batch '23
          </h2>
          <p className="text-sm sm:text-base text-slate-400 font-['Hind_Siliguri']">
            স্কুল জীবনের সেরা দিনগুলো, আবেগ আর বন্ধুত্বের গল্পগুলো ছড়িয়ে থাকুক চিরকাল।
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="btn-gold px-6 py-3 text-sm font-bold flex items-center gap-2 self-start md:self-auto cursor-pointer"
        >
          <PlusCircle className="w-4 h-4 text-slate-950" />
          <span>আপনার স্মৃতি শেয়ার করুন (Share Story)</span>
        </button>
      </div>

      {/* Stories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {publishedStories.map((story) => (
          <div
            key={story.id}
            className={`glass-card rounded-3xl p-6 border flex flex-col justify-between transition-all duration-300 ${
              isLightMode
                ? 'bg-white border-amber-200/90 shadow-md hover:border-amber-400'
                : 'bg-slate-900/60 border-amber-500/20 shadow-xl hover:border-amber-400'
            }`}
          >
            <div>
              {/* Optional story banner photo */}
              {story.photoUrl && (
                <div className="rounded-2xl overflow-hidden aspect-video mb-4 border border-amber-500/20">
                  <img
                    src={story.photoUrl}
                    alt={story.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              {/* Title */}
              <h3 className="text-lg font-bold text-slate-100 mb-2 font-['Hind_Siliguri'] line-clamp-2">
                {story.title}
              </h3>

              {/* Author & Date */}
              <div className="flex items-center gap-2 text-xs text-slate-400 mb-4">
                <div className="w-6 h-6 rounded-full bg-amber-400/20 text-amber-400 flex items-center justify-center font-bold text-[10px]">
                  {story.author[0]}
                </div>
                <span className="font-semibold text-slate-300 font-['Hind_Siliguri']">{story.author}</span>
                {story.authorGroup && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">
                    {story.authorGroup}
                  </span>
                )}
                <span>• {story.date}</span>
              </div>

              {/* Story Content */}
              <p className="text-xs sm:text-sm text-slate-300 font-['Hind_Siliguri'] leading-relaxed whitespace-pre-line line-clamp-6">
                {story.content}
              </p>
            </div>

            {/* Bottom Actions */}
            <div className="pt-4 mt-6 border-t border-slate-800/80 flex items-center justify-between">
              <button
                onClick={() => onLikeStory(story.id)}
                className="flex items-center gap-1.5 text-xs font-bold text-rose-500 hover:scale-105 transition-transform cursor-pointer"
              >
                <Heart className="w-4 h-4 fill-rose-500" />
                <span>{story.likes} Likes</span>
              </button>

              <span className="text-[11px] text-amber-400/80 font-medium">
                DCMS Batch '23
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Submit Story Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
          <div className={`relative w-full max-w-lg rounded-3xl p-6 sm:p-8 border shadow-2xl ${
            isLightMode
              ? 'bg-white border-amber-300 text-slate-800'
              : 'bg-slate-900 border-amber-500/40 text-slate-100'
          }`}>
            <button
              onClick={() => setModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-bold gradient-text mb-1">
              Share Your Memory
            </h3>
            <p className="text-xs text-slate-400 mb-6 font-['Hind_Siliguri']">
              আপনার স্মৃতি বা ক্যাম্পাসের কোনো বিশেষ মুহূর্ত লিখে সবার সাথে ভাগ করে নিন।
            </p>

            {submittedMessage ? (
              <div className="p-8 text-center flex flex-col items-center">
                <CheckCircle2 className="w-14 h-14 text-emerald-400 mb-3 animate-bounce" />
                <h4 className="text-lg font-bold text-slate-100">ধন্যবাদ! গল্প জমা হয়েছে!</h4>
                <p className="text-xs text-slate-400 mt-1 font-['Hind_Siliguri']">
                  অ্যাডমিন মডারেশন সম্পন্ন হলে আপনার স্মৃতিচারণটি ওয়েবসাইটে প্রকাশিত হবে।
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Title / শিরোনাম *
                  </label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="যেমন: শেষ ক্লাসের কান্না ও প্রিয় বন্ধুরা..."
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Your Name / নাম *
                    </label>
                    <input
                      type="text"
                      required
                      value={author}
                      onChange={(e) => setAuthor(e.target.value)}
                      placeholder="আপনার পূর্ণ নাম"
                      className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                        isLightMode ? 'bg-slate-50 border-slate-300' : 'bg-slate-950 border-slate-800 text-white'
                      }`}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Group / বিভাগ *
                    </label>
                    <select
                      value={group}
                      onChange={(e) => setGroup(e.target.value as AcademicGroup)}
                      className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                        isLightMode ? 'bg-slate-50 border-slate-300' : 'bg-slate-950 border-slate-800 text-white'
                      }`}
                    >
                      <option value="Science">Science (বিজ্ঞান)</option>
                      <option value="Commerce">Commerce (বাণিজ্য)</option>
                      <option value="Humanities">Humanities (মানবিক)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Memory Story / স্মৃতিচারণ *
                  </label>
                  <textarea
                    required
                    rows={5}
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="আপনার প্রিয় মুহূর্ত বা অনুভূতি বিস্তারিত লিখুন..."
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  />
                </div>

                <button
                  type="submit"
                  className="btn-gold w-full py-3 text-xs font-bold cursor-pointer"
                >
                  Submit Memory (স্মৃতি প্রকাশ করুন)
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
