import React, { useState } from 'react';
import { 
  X, 
  Phone, 
  Mail, 
  MapPin, 
  Calendar, 
  Heart, 
  ExternalLink, 
  Copy, 
  Check, 
  MessageCircle, 
  GraduationCap, 
  Quote,
  Share2,
  Trash2,
  Edit,
  User
} from 'lucide-react';
import { Batchmate } from '../types';

interface BatchmateDetailModalProps {
  batchmate: Batchmate | null;
  onClose: () => void;
  isLightMode: boolean;
  onDeleteBatchmate?: (id: string) => void;
  currentUser?: Batchmate | null;
  onOpenEditProfile?: (batchmate: Batchmate) => void;
}

export const BatchmateDetailModal: React.FC<BatchmateDetailModalProps> = ({
  batchmate,
  onClose,
  isLightMode,
  onDeleteBatchmate,
  currentUser,
  onOpenEditProfile,
}) => {
  const [copied, setCopied] = useState(false);
  const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = useState(false);

  if (!batchmate) return null;

  const handleCopyPhone = () => {
    if (batchmate.phone) {
      navigator.clipboard.writeText(batchmate.phone);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div 
        className={`relative w-full max-w-xl rounded-3xl p-6 sm:p-8 border shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto ${
          isLightMode
            ? 'bg-white border-amber-300 text-slate-800'
            : 'bg-slate-900 border-amber-500/30 text-slate-100 shadow-amber-500/10'
        }`}
      >
        {/* Top Gold Trim */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-amber-400 via-amber-300 to-amber-600"></div>

        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-100 hover:bg-slate-800/60 transition-colors z-10 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Profile Header */}
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 pt-2">
          {/* Avatar with golden glow */}
          <div className="relative">
            <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl p-1 bg-gradient-to-tr from-amber-400 via-amber-200 to-amber-600 shadow-xl shadow-amber-500/25">
              <img
                src={batchmate.photoUrl}
                alt={batchmate.name}
                className="w-full h-full object-cover rounded-[22px]"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(batchmate.name)}&background=0f172a&color=fbbf24&size=300`;
                }}
              />
            </div>
            {batchmate.blood && (
              <span className="absolute -bottom-2 -right-2 px-2.5 py-1 rounded-full text-xs font-black bg-rose-600 text-white shadow-lg flex items-center gap-1">
                <Heart className="w-3 h-3 fill-white" />
                {batchmate.blood}
              </span>
            )}
          </div>

          {/* Details */}
          <div className="text-center sm:text-left flex-1">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-400/20 text-amber-400 border border-amber-400/30">
                {batchmate.group} Group
              </span>
              {batchmate.rollNumber && (
                <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-slate-800 text-slate-300 border border-slate-700">
                  Roll: #{batchmate.rollNumber}
                </span>
              )}
              {batchmate.isRepresentative && (
                <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40">
                  Batch Rep
                </span>
              )}
            </div>

            <h3 className="text-2xl font-black gradient-text">
              {batchmate.name}
            </h3>
            {batchmate.nameBangla && (
              <p className="text-sm font-medium text-slate-400 font-['Hind_Siliguri']">
                {batchmate.nameBangla}
              </p>
            )}

            {batchmate.currentStatus && (
              <div className="inline-flex items-center gap-1.5 mt-2 px-3 py-1 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
                <GraduationCap className="w-3.5 h-3.5" />
                <span>{batchmate.currentStatus}</span>
              </div>
            )}
          </div>
        </div>

        {/* Message / Bio Quote */}
        {batchmate.bio && (
          <div className={`mt-6 p-4 rounded-2xl border relative ${
            isLightMode
              ? 'bg-amber-50/70 border-amber-200'
              : 'bg-slate-950/60 border-amber-500/20'
          }`}>
            <Quote className="w-5 h-5 text-amber-400/50 absolute top-3 left-3 -scale-x-100" />
            <p className="text-xs sm:text-sm italic text-slate-300 pl-6 font-['Hind_Siliguri'] leading-relaxed">
              "{batchmate.bio}"
            </p>
          </div>
        )}

        {/* Info Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-6">
          <div className={`p-3 rounded-2xl border flex items-center gap-3 ${
            isLightMode ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/40 border-slate-800'
          }`}>
            <MapPin className="w-4 h-4 text-amber-400 flex-shrink-0" />
            <div className="min-w-0">
              <span className="text-[10px] uppercase font-semibold text-slate-400 block">Address</span>
              <span className="text-xs font-medium text-slate-200 truncate block">{batchmate.address}</span>
            </div>
          </div>

          <div className={`p-3 rounded-2xl border flex items-center gap-3 ${
            isLightMode ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/40 border-slate-800'
          }`}>
            <Calendar className="w-4 h-4 text-amber-400 flex-shrink-0" />
            <div>
              <span className="text-[10px] uppercase font-semibold text-slate-400 block">Date of Birth</span>
              <span className="text-xs font-medium text-slate-200">
                {batchmate.dob || (batchmate.birthday ? `Birthday: ${batchmate.birthday}` : 'Not specified')}
              </span>
            </div>
          </div>

          {batchmate.email && (
            <div className={`p-3 rounded-2xl border flex items-center gap-3 sm:col-span-2 ${
              isLightMode ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/40 border-slate-800'
            }`}>
              <Mail className="w-4 h-4 text-amber-400 flex-shrink-0" />
              <div className="min-w-0 flex-1">
                <span className="text-[10px] uppercase font-semibold text-slate-400 block">Email Address</span>
                <a href={`mailto:${batchmate.email}`} className="text-xs font-medium text-amber-400 hover:underline truncate block">
                  {batchmate.email}
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Direct Action Contacts */}
        <div className="mt-6 pt-5 border-t border-slate-800/80 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Direct Connect</span>
            {batchmate.phone && (!batchmate.hidePhone || (currentUser && currentUser.id === batchmate.id)) && (
              <button
                onClick={handleCopyPhone}
                className="text-xs text-slate-400 hover:text-amber-400 flex items-center gap-1 transition-colors cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy Number'}</span>
              </button>
            )}
          </div>

          {batchmate.hidePhone && (!currentUser || currentUser.id !== batchmate.id) ? (
            <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 text-center">
              <span className="text-xs text-slate-400 font-['Hind_Siliguri']">
                🔒 এই মেম্বার তার ফোন নম্বর সাধারণ মেম্বারদের কাছে গোপন রেখেছেন (শুধুমাত্র অ্যাডমিন দেখতে পারবে)।
              </span>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {batchmate.phone && (
                <a
                  href={`tel:${batchmate.phone.replace(/[^0-9]/g, '')}`}
                  className="p-2.5 rounded-xl bg-amber-400 text-slate-950 hover:bg-amber-300 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call Now</span>
                </a>
              )}

              {batchmate.whatsapp || batchmate.phone ? (
                <a
                  href={`https://wa.me/88${(batchmate.whatsapp || batchmate.phone).replace(/[^0-9]/g, '')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>
              ) : null}

              {batchmate.facebook && (
                <a
                  href={batchmate.facebook}
                  target="_blank"
                  rel="noreferrer"
                  className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors col-span-2 sm:col-span-1"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Facebook</span>
                </a>
              )}
            </div>
          )}
        </div>

          {/* Edit My Profile button if user views their own profile */}
          {currentUser && currentUser.id === batchmate.id && onOpenEditProfile && (
            <div className="pt-3">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenEditProfile(batchmate);
                }}
                className="w-full py-3 rounded-xl font-bold text-xs sm:text-sm bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 cursor-pointer transition-transform active:scale-[0.99]"
              >
                <Edit className="w-4 h-4" />
                <span>আমার প্রোফাইল পরিবর্তন / এডিট করুন (Edit Profile)</span>
              </button>
            </div>
          )}

          {/* Delete Batchmate Profile Button */}
          {onDeleteBatchmate && (
            <div className="pt-4 mt-4 border-t border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-slate-400 font-['Hind_Siliguri']">
                প্রোফাইল তালিকা থেকে সরাতে চান?
              </span>
              <button
                type="button"
                onClick={() => setIsConfirmDeleteOpen(true)}
                className="px-3 py-1.5 rounded-xl text-xs font-bold border border-rose-500/40 text-rose-400 hover:bg-rose-500/15 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>প্রোফাইল মুছুন (Delete)</span>
              </button>
            </div>
          )}

        {/* In-app Delete Confirmation Modal */}
        {isConfirmDeleteOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
            <div className="relative w-full max-w-sm rounded-3xl p-6 bg-slate-900 border border-rose-500/40 text-slate-100 shadow-2xl">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center mb-3">
                <Trash2 className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-white mb-1">
                প্রোফাইল মুছে ফেলবেন?
              </h4>
              <p className="text-xs text-slate-300 mb-4 font-['Hind_Siliguri']">
                আপনি কি নিশ্চিত যে <strong className="text-amber-400">{batchmate.name}</strong>-এর প্রোফাইল তালিকা থেকে স্থায়ীভাবে মুছে ফেলতে চান?
              </p>
              <div className="flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsConfirmDeleteOpen(false)}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onDeleteBatchmate?.(batchmate.id);
                    setIsConfirmDeleteOpen(false);
                    onClose();
                  }}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white flex items-center gap-1.5 cursor-pointer shadow-lg shadow-rose-600/30"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>হ্যাঁ, মুছে ফেলুন</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
