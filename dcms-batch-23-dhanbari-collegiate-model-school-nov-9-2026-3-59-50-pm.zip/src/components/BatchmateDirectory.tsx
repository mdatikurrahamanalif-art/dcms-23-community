import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Users, 
  MapPin, 
  Heart, 
  Phone, 
  MessageCircle, 
  ExternalLink, 
  LayoutGrid, 
  List,
  Sparkles,
  GraduationCap,
  UserPlus,
  User,
  Edit
} from 'lucide-react';
import { Batchmate, AcademicGroup } from '../types';

interface BatchmateDirectoryProps {
  batchmates: Batchmate[];
  onSelectMember: (batchmate: Batchmate) => void;
  onOpenJoinModal?: () => void;
  currentUser?: Batchmate | null;
  onOpenEditProfile?: (batchmate: Batchmate) => void;
  isLightMode: boolean;
}

export const BatchmateDirectory: React.FC<BatchmateDirectoryProps> = ({
  batchmates,
  onSelectMember,
  onOpenJoinModal,
  currentUser,
  onOpenEditProfile,
  isLightMode,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<string>('ALL');
  const [selectedBlood, setSelectedBlood] = useState<string>('ALL');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const bloodGroups = ['ALL', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const groups = [
    { id: 'ALL', label: 'All Groups', bangla: 'সকল বিভাগ' },
    { id: 'Science', label: 'Science', bangla: 'বিজ্ঞান' },
    { id: 'Commerce', label: 'Commerce', bangla: 'বাণিজ্য' },
    { id: 'Humanities', label: 'Humanities', bangla: 'মানবিক' },
  ];

  const filteredBatchmates = useMemo(() => {
    return batchmates.filter((b) => {
      const matchSearch =
        b.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (b.nameBangla && b.nameBangla.includes(searchTerm)) ||
        b.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (b.blood && b.blood.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (b.currentStatus && b.currentStatus.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchGroup = selectedGroup === 'ALL' || b.group === selectedGroup;
      const matchBlood = selectedBlood === 'ALL' || b.blood === selectedBlood;

      return matchSearch && matchGroup && matchBlood;
    });
  }, [batchmates, searchTerm, selectedGroup, selectedBlood]);

  return (
    <section id="directory" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-semibold mb-3">
            <Users className="w-3.5 h-3.5" />
            <span>Batch Directory • ব্যাচমেট ডিরেক্টরি</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold gradient-text mb-2">
            DCMS Batch '23 Batchmates
          </h2>
          <p className="text-sm sm:text-base text-slate-400 font-['Hind_Siliguri']">
            সহপাঠীদের সাথে যোগাযোগ রাখুন। খুঁজে নিন বিজ্ঞান, বাণিজ্য ও মানবিক বিভাগের বন্ধুদের প্রোফাইল।
          </p>
        </div>

        {currentUser && onOpenEditProfile && (
          <button
            onClick={() => onOpenEditProfile(currentUser)}
            className="btn-gold px-5 py-2.5 text-xs font-bold flex items-center gap-2 self-start md:self-auto cursor-pointer shadow-lg shadow-amber-400/20"
          >
            <User className="w-4 h-4 text-slate-950" />
            <span>আমার প্রোফাইল এডিট করুন</span>
          </button>
        )}
      </div>

      {/* Search and Filters Bar */}
      <div className={`p-4 sm:p-6 rounded-3xl border shadow-xl mb-8 ${
        isLightMode
          ? 'bg-white border-amber-200'
          : 'bg-slate-900/80 border-amber-500/20 backdrop-blur-xl'
      }`}>
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-5 h-5 text-amber-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by name, address (e.g. Tangail), blood group, university..."
              className={`w-full pl-12 pr-4 py-3 rounded-2xl text-sm border focus:outline-none focus:ring-2 focus:ring-amber-400 transition-all ${
                isLightMode
                  ? 'bg-slate-50 border-slate-200 text-slate-800 placeholder-slate-400'
                  : 'bg-slate-950/70 border-slate-800 text-slate-100 placeholder-slate-500'
              }`}
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-amber-400 px-2 py-1"
              >
                Clear
              </button>
            )}
          </div>

          {/* Blood group selector and View Mode switch */}
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="flex items-center gap-1.5 px-3 py-2 rounded-2xl border text-xs font-semibold bg-slate-950/40 border-slate-800">
              <Heart className="w-3.5 h-3.5 text-rose-500" />
              <span className="text-slate-400">Blood:</span>
              <select
                value={selectedBlood}
                onChange={(e) => setSelectedBlood(e.target.value)}
                className="bg-transparent text-amber-400 font-bold focus:outline-none cursor-pointer"
              >
                {bloodGroups.map((bg) => (
                  <option key={bg} value={bg} className="bg-slate-900 text-slate-200">
                    {bg === 'ALL' ? 'All Blood Groups' : bg}
                  </option>
                ))}
              </select>
            </div>

            {/* View Mode */}
            <div className="flex items-center p-1 rounded-2xl border border-slate-800 bg-slate-950/50">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors ${
                  viewMode === 'grid'
                    ? 'bg-amber-400 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Grid View"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors ${
                  viewMode === 'list'
                    ? 'bg-amber-400 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="List View"
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Group Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-4 border-t border-slate-800/60 mt-4">
          {groups.map((grp) => {
            const isSel = selectedGroup === grp.id;
            return (
              <button
                key={grp.id}
                onClick={() => setSelectedGroup(grp.id)}
                className={`flex-shrink-0 px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  isSel
                    ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md shadow-amber-400/20'
                    : isLightMode
                    ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    : 'bg-slate-950/60 text-slate-300 hover:bg-slate-800 hover:text-amber-400'
                }`}
              >
                <span>{grp.label}</span>
                <span className="text-[10px] opacity-75">({grp.bangla})</span>
              </button>
            );
          })}
          <div className="ml-auto text-xs text-slate-400 font-medium">
            Showing <span className="text-amber-400 font-bold">{filteredBatchmates.length}</span> batchmates
          </div>
        </div>
      </div>

      {/* Batchmate Cards Grid */}
      {filteredBatchmates.length === 0 ? (
        <div className="text-center py-16 p-8 glass rounded-3xl border border-dashed border-amber-500/30 max-w-xl mx-auto my-6">
          <div className="w-16 h-16 rounded-3xl bg-amber-400/20 text-amber-400 flex items-center justify-center mx-auto mb-4 border border-amber-400/30">
            <Users className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold gradient-text mb-2">
            {batchmates.length === 0 ? 'ডিরেক্টরি বর্তমানে সম্পূর্ণ খালি' : 'কোনো সহপাঠীর তথ্য পাওয়া যায়নি'}
          </h3>
          <p className="text-sm text-slate-300 font-['Hind_Siliguri'] mt-1 leading-relaxed mb-6">
            {batchmates.length === 0 
              ? 'সকল ডেমো ব্যাচমেট সফলভাবে মুছে ফেলা হয়েছে। এখন ডিসিএমএস ব্যাচ ২৩ এর আসল বন্ধুদের নাম, ছবি ও রক্তের গ্রুপ যুক্ত করার জন্য প্ল্যাটফর্মটি প্রস্তুত।'
              : 'আপনার খোঁজার তথ্যের সাথে মিল পাওয়া যায়নি। অন্য ফিল্টার দিয়ে চেষ্টা করুন।'}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            {batchmates.length > 0 && (
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedGroup('ALL');
                  setSelectedBlood('ALL');
                }}
                className="px-4 py-2.5 rounded-full text-xs font-bold border border-slate-700 bg-slate-900 text-slate-300 hover:text-white cursor-pointer"
              >
                রিসেট ফিল্টার
              </button>
            )}
          </div>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {filteredBatchmates.map((b) => (
            <div
              key={b.id}
              onClick={() => onSelectMember(b)}
              className={`glass-card rounded-3xl p-5 border flex flex-col justify-between transition-all duration-300 cursor-pointer group ${
                isLightMode
                  ? 'bg-white border-amber-200/90 shadow-lg hover:border-amber-400'
                  : 'bg-slate-900/60 border-amber-500/20 shadow-xl hover:border-amber-400'
              }`}
            >
              <div>
                {/* Header with Avatar & Badges */}
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="relative">
                    <div className="w-16 h-16 rounded-2xl overflow-hidden p-0.5 bg-gradient-to-tr from-amber-400 via-yellow-200 to-amber-600 shadow-md group-hover:scale-105 transition-transform">
                      <img
                        src={b.photoUrl}
                        alt={b.name}
                        className="w-full h-full object-cover rounded-[14px]"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(b.name)}&background=0f172a&color=fbbf24`;
                        }}
                      />
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-1">
                    {currentUser && currentUser.id === b.id && (
                      <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 shadow-sm flex items-center gap-0.5">
                        <User className="w-2.5 h-2.5" />
                        আপনি (You)
                      </span>
                    )}

                    <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                      b.group === 'Science'
                        ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
                        : b.group === 'Commerce'
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                        : 'bg-purple-500/10 text-purple-400 border-purple-500/30'
                    }`}>
                      {b.group}
                    </span>

                    {b.blood && (
                      <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-rose-600 text-white shadow-sm flex items-center gap-0.5">
                        <Heart className="w-2.5 h-2.5 fill-white" />
                        {b.blood}
                      </span>
                    )}
                  </div>
                </div>

                {/* Name & Title */}
                <h3 className="text-base font-bold text-slate-100 group-hover:text-amber-400 transition-colors line-clamp-1">
                  {b.name}
                </h3>
                {b.nameBangla && (
                  <p className="text-xs text-slate-400 font-['Hind_Siliguri'] line-clamp-1 mb-1">
                    {b.nameBangla}
                  </p>
                )}

                {/* Status / Uni */}
                {b.currentStatus && (
                  <div className="flex items-center gap-1.5 text-xs text-amber-300 font-medium mb-2 line-clamp-1">
                    <GraduationCap className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                    <span className="truncate">{b.currentStatus}</span>
                  </div>
                )}

                {/* Address */}
                <div className="flex items-center gap-1.5 text-xs text-slate-400 line-clamp-1 mb-3">
                  <MapPin className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
                  <span className="truncate">{b.address}</span>
                </div>

                {/* Bio Snippet */}
                {b.bio && (
                  <p className="text-xs italic text-slate-400/80 font-['Hind_Siliguri'] line-clamp-2 border-l-2 border-amber-400/40 pl-2 mb-4">
                    "{b.bio}"
                  </p>
                )}
              </div>

              {/* Action buttons footer */}
              <div 
                className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onSelectMember(b)}
                    className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
                  >
                    <span>Profile</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>

                  {currentUser && currentUser.id === b.id && onOpenEditProfile && (
                    <button
                      onClick={() => onOpenEditProfile(b)}
                      className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-amber-400/20 text-amber-300 border border-amber-400/40 hover:bg-amber-400 hover:text-slate-950 flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Edit className="w-3 h-3" />
                      <span>এডিট</span>
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-1.5">
                  {b.hidePhone && (!currentUser || currentUser.id !== b.id) ? (
                    <span className="text-[10px] text-slate-500 font-medium px-2 py-0.5 rounded bg-slate-800/80" title="ফোন নম্বর গোপন রাখা হয়েছে (অ্যাডমিন ছাড়া অন্যরা দেখতে পারবে না)">
                      🔒 গোপন
                    </span>
                  ) : (
                    <>
                      {b.phone && (
                        <a
                          href={`tel:${b.phone.replace(/[^0-9]/g, '')}`}
                          title="Call"
                          className="p-1.5 rounded-lg bg-amber-400/10 text-amber-400 hover:bg-amber-400 hover:text-slate-950 transition-colors"
                        >
                          <Phone className="w-3.5 h-3.5" />
                        </a>
                      )}
                      {b.whatsapp || b.phone ? (
                        <a
                          href={`https://wa.me/88${(b.whatsapp || b.phone).replace(/[^0-9]/g, '')}`}
                          target="_blank"
                          rel="noreferrer"
                          title="WhatsApp"
                          className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500 hover:text-white transition-colors"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                        </a>
                      ) : null}
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* List / Table View */
        <div className={`rounded-3xl border overflow-hidden shadow-xl ${
          isLightMode ? 'bg-white border-amber-200' : 'bg-slate-900/80 border-amber-500/20'
        }`}>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/80 text-slate-400 uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-3.5 px-4">Student</th>
                  <th className="py-3.5 px-4">Group</th>
                  <th className="py-3.5 px-4">Blood Group</th>
                  <th className="py-3.5 px-4">Current Institution / Status</th>
                  <th className="py-3.5 px-4">Hometown</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-medium">
                {filteredBatchmates.map((b) => (
                  <tr
                    key={b.id}
                    onClick={() => onSelectMember(b)}
                    className="hover:bg-amber-400/5 cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-4 flex items-center gap-3">
                      <img
                        src={b.photoUrl}
                        alt={b.name}
                        className="w-8 h-8 rounded-full object-cover border border-amber-400/40"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(b.name)}&background=0f172a&color=fbbf24`;
                        }}
                      />
                      <div>
                        <span className="font-bold text-slate-200 hover:text-amber-400 block">{b.name}</span>
                        {b.nameBangla && (
                          <span className="text-[11px] text-slate-500 font-['Hind_Siliguri']">{b.nameBangla}</span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400/10 text-amber-400 border border-amber-400/20">
                        {b.group}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-black text-rose-500 bg-rose-500/10 px-2 py-0.5 rounded-full">
                        {b.blood}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-300">
                      {b.currentStatus || 'Higher Studies'}
                    </td>
                    <td className="py-3 px-4 text-slate-400">
                      {b.address}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectMember(b);
                        }}
                        className="btn-gold px-3 py-1 text-[11px] font-bold"
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </section>
  );
};
