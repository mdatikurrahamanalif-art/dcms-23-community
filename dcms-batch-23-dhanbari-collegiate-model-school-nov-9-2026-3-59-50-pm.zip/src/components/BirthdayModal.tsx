import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Cake, Sparkles, X, MessageCircle, Heart, Share2 } from 'lucide-react';
import { Batchmate } from '../types';

interface BirthdayModalProps {
  birthdayBatchmates: Batchmate[];
  onClose: () => void;
  isLightMode: boolean;
}

export const BirthdayModal: React.FC<BirthdayModalProps> = ({
  birthdayBatchmates,
  onClose,
  isLightMode,
}) => {
  useEffect(() => {
    // Fire festive fireworks confetti
    const duration = 3.5 * 1000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 4,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#fbbf24', '#f59e0b', '#ec4899', '#38bdf8', '#ffffff'],
      });
      confetti({
        particleCount: 4,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#fbbf24', '#f59e0b', '#ec4899', '#38bdf8', '#ffffff'],
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();
  }, []);

  if (!birthdayBatchmates || birthdayBatchmates.length === 0) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className={`relative w-full max-w-lg rounded-3xl p-6 sm:p-8 border shadow-2xl text-center overflow-hidden ${
        isLightMode
          ? 'bg-white border-amber-300 text-slate-800'
          : 'bg-slate-900 border-amber-500/40 text-slate-100 shadow-amber-500/20'
      }`}>
        {/* Top glowing banner */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-amber-400 via-rose-500 to-amber-500"></div>

        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-100 hover:bg-slate-800/50 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Icon */}
        <div className="mx-auto w-16 h-16 rounded-full bg-gradient-to-tr from-amber-400 to-amber-600 flex items-center justify-center mb-4 shadow-lg shadow-amber-500/30">
          <Cake className="w-8 h-8 text-slate-950 animate-bounce" />
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-semibold mb-2">
          <Sparkles className="w-3.5 h-3.5" />
          <span>আজকের জন্মদিন • Today's Birthday!</span>
        </div>

        <h3 className="text-2xl sm:text-3xl font-black gradient-text mb-1">
          শুভ জন্মদিন!
        </h3>
        <p className="text-xs sm:text-sm text-slate-400 mb-6 font-['Hind_Siliguri']">
          ডিসিএমএস ব্যাচ ২৩ এর পক্ষ থেকে জানাই উষ্ণ অভিনন্দন ও ভালোবাসা!
        </p>

        {/* Batchmates celebrating today */}
        <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-1">
          {birthdayBatchmates.map((b) => (
            <div
              key={b.id}
              className={`p-4 rounded-2xl border flex flex-col items-center gap-3 transition-transform ${
                isLightMode
                  ? 'bg-amber-50/70 border-amber-200'
                  : 'bg-slate-950/60 border-amber-500/30'
              }`}
            >
              <div className="relative">
                <div className="w-24 h-24 rounded-full p-1 bg-gradient-to-tr from-amber-400 to-amber-600 shadow-xl shadow-amber-500/30">
                  <img
                    src={b.photoUrl}
                    alt={b.name}
                    className="w-full h-full object-cover rounded-full"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(b.name)}&background=0f172a&color=fbbf24&size=200`;
                    }}
                  />
                </div>
                <span className="absolute -bottom-1 -right-1 text-2xl">🎉</span>
              </div>

              <div>
                <h4 className="text-lg font-bold text-amber-400">{b.name}</h4>
                {b.nameBangla && (
                  <p className="text-xs text-slate-400 font-['Hind_Siliguri']">{b.nameBangla}</p>
                )}
                <div className="flex items-center justify-center gap-2 mt-1">
                  <span className="text-[11px] px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 font-medium">
                    {b.group} Group
                  </span>
                  <span className="text-[11px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-medium">
                    Blood: {b.blood}
                  </span>
                </div>
                {b.bio && (
                  <p className="text-xs italic text-slate-400 mt-2 max-w-sm font-['Hind_Siliguri']">
                    "{b.bio}"
                  </p>
                )}
              </div>

              {/* Wish buttons */}
              <div className="flex items-center gap-2 mt-2 w-full justify-center">
                {b.facebook && (
                  <a
                    href={b.facebook}
                    target="_blank"
                    rel="noreferrer"
                    className="btn-gold px-4 py-2 text-xs font-bold flex items-center gap-1.5"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Wish on Facebook</span>
                  </a>
                )}

                {b.phone && (
                  <a
                    href={`https://wa.me/88${b.phone.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2 text-xs font-bold rounded-full bg-emerald-600 text-white hover:bg-emerald-500 transition-colors flex items-center gap-1.5"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp Wish</span>
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={onClose}
          className="mt-6 text-xs text-slate-400 hover:text-amber-400 underline transition-colors cursor-pointer"
        >
          Close Celebration Window
        </button>
      </div>
    </div>
  );
};
