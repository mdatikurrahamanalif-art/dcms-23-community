import React, { useState } from 'react';
import { Heart, Phone, MessageCircle, MapPin, AlertCircle, Search, ShieldCheck } from 'lucide-react';
import { Batchmate, BloodGroup } from '../types';

interface BloodDonorDirectoryProps {
  batchmates: Batchmate[];
  isLightMode: boolean;
}

export const BloodDonorDirectory: React.FC<BloodDonorDirectoryProps> = ({
  batchmates,
  isLightMode,
}) => {
  const [selectedBlood, setSelectedBlood] = useState<string>('ALL');
  const [searchLocation, setSearchLocation] = useState<string>('');

  const bloodTypes: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  // Filter batchmates with valid blood group
  const donors = batchmates.filter((b) => b.blood && b.blood !== 'N/A');

  const filteredDonors = donors.filter((d) => {
    const matchBlood = selectedBlood === 'ALL' || d.blood === selectedBlood;
    const matchLocation =
      searchLocation === '' ||
      d.address.toLowerCase().includes(searchLocation.toLowerCase()) ||
      d.name.toLowerCase().includes(searchLocation.toLowerCase());
    return matchBlood && matchLocation;
  });

  return (
    <section id="blood" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-semibold mb-3">
          <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
          <span>Life Saving Blood Bank • রক্তদাতা ডিরেক্টরি</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold gradient-text mb-3">
          DCMS '23 Emergency Blood Bank
        </h2>
        <p className="text-sm sm:text-base text-slate-400 font-['Hind_Siliguri']">
          জরুরী প্রয়োজনে রক্তের সন্ধান করুন। ধনবাড়ী, টাঙ্গাইল ও ঢাকাসহ যে কোনো স্থানে ব্যাচমেট রক্তদাতাদের তাৎক্ষণিক কল করুন।
        </p>
      </div>

      {/* Emergency Notice Card */}
      <div className={`p-4 sm:p-5 rounded-3xl border mb-8 flex flex-col sm:flex-row items-center gap-4 ${
        isLightMode
          ? 'bg-rose-50 border-rose-200 text-slate-800'
          : 'bg-rose-950/30 border-rose-500/30 text-rose-200'
      }`}>
        <div className="w-12 h-12 rounded-2xl bg-rose-600 text-white flex items-center justify-center flex-shrink-0 shadow-lg shadow-rose-600/30">
          <AlertCircle className="w-6 h-6" />
        </div>
        <div className="flex-1 text-center sm:text-left">
          <h4 className="text-sm font-bold text-rose-400">রক্তদানের নিয়মাবলী ও সতর্কবার্তা</h4>
          <p className="text-xs text-slate-300 font-['Hind_Siliguri'] mt-0.5">
            রক্তদাতা ও গ্রহীতার শারীরিক সুস্থতা নিশ্চিত করে ক্রস-ম্যাচিং করুন। শেষ রক্তদানের পর ন্যূনতম ৩-৪ মাস অতিবাহিত হতে হবে।
          </p>
        </div>
        <div className="text-xs font-bold px-3 py-1.5 rounded-full bg-rose-600/20 text-rose-300 border border-rose-500/40">
          Total Donors: {donors.length}
        </div>
      </div>

      {/* Blood Group Selector Filter Grid */}
      <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-9 gap-2 mb-8">
        <button
          onClick={() => setSelectedBlood('ALL')}
          className={`py-3 px-2 rounded-2xl text-xs font-bold border transition-all text-center cursor-pointer ${
            selectedBlood === 'ALL'
              ? 'bg-amber-400 text-slate-950 border-amber-400 shadow-md'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-amber-400'
          }`}
        >
          <span>All Groups</span>
          <span className="block text-[10px] opacity-75 mt-0.5">({donors.length})</span>
        </button>

        {bloodTypes.map((bg) => {
          const count = donors.filter((d) => d.blood === bg).length;
          const isSel = selectedBlood === bg;
          return (
            <button
              key={bg}
              onClick={() => setSelectedBlood(bg)}
              className={`py-3 px-2 rounded-2xl text-xs font-bold border transition-all text-center cursor-pointer ${
                isSel
                  ? 'bg-rose-600 text-white border-rose-500 shadow-lg shadow-rose-600/30 scale-105'
                  : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-rose-500'
              }`}
            >
              <span className="text-sm font-black">{bg}</span>
              <span className="block text-[10px] opacity-75 mt-0.5">({count} donors)</span>
            </button>
          );
        })}
      </div>

      {/* Donors Grid */}
      {filteredDonors.length === 0 ? (
        <div className="text-center py-12 p-6 glass rounded-3xl border border-dashed border-rose-500/30 max-w-md mx-auto">
          <Heart className="w-10 h-10 text-rose-500/60 mx-auto mb-2" />
          <h4 className="text-base font-bold text-slate-200 mb-1">
            রক্তদাতা তালিকা বর্তমানে খালি
          </h4>
          <p className="text-xs text-slate-400 font-['Hind_Siliguri']">
            ব্যাচমেটরা 'Join Batch' বা রেজিস্ট্রেশন করার সময় রক্তের গ্রুপ দিলেই এখানে স্বয়ংক্রিয়ভাবে জরুরি যোগাযোগের জন্য প্রদর্শিত হবে।
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredDonors.map((donor) => (
          <div
            key={donor.id}
            className={`glass-card rounded-3xl p-5 border flex items-center justify-between gap-4 transition-all ${
              isLightMode
                ? 'bg-white border-amber-200'
                : 'bg-slate-900/70 border-amber-500/20'
            }`}
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="relative">
                <div className="w-14 h-14 rounded-2xl overflow-hidden p-0.5 bg-gradient-to-tr from-rose-500 to-amber-500 shadow-md">
                  <img
                    src={donor.photoUrl}
                    alt={donor.name}
                    className="w-full h-full object-cover rounded-xl"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(donor.name)}&background=0f172a&color=fbbf24`;
                    }}
                  />
                </div>
                <span className="absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded-full text-[9px] font-black bg-rose-600 text-white shadow-md">
                  {donor.blood}
                </span>
              </div>

              <div className="min-w-0">
                <h4 className="text-sm font-bold text-slate-100 truncate">
                  {donor.name}
                </h4>
                <p className="text-[11px] text-amber-400 font-medium">
                  {donor.group} Group
                </p>
                <div className="flex items-center gap-1 text-[11px] text-slate-400 truncate mt-0.5">
                  <MapPin className="w-3 h-3 text-slate-500 flex-shrink-0" />
                  <span className="truncate">{donor.address}</span>
                </div>
              </div>
            </div>

            {/* Direct Connect Buttons */}
            <div className="flex flex-col gap-1.5 flex-shrink-0">
              {donor.phone && (
                <a
                  href={`tel:${donor.phone.replace(/[^0-9]/g, '')}`}
                  className="p-2 rounded-xl bg-amber-400 text-slate-950 hover:bg-amber-300 transition-colors shadow-sm"
                  title="Call Donor"
                >
                  <Phone className="w-4 h-4" />
                </a>
              )}
              {donor.whatsapp || donor.phone ? (
                <a
                  href={`https://wa.me/88${(donor.whatsapp || donor.phone).replace(/[^0-9]/g, '')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="p-2 rounded-xl bg-emerald-600 text-white hover:bg-emerald-500 transition-colors shadow-sm"
                  title="WhatsApp"
                >
                  <MessageCircle className="w-4 h-4" />
                </a>
              ) : null}
            </div>
          </div>
        ))}
        </div>
      )}
    </section>
  );
};
