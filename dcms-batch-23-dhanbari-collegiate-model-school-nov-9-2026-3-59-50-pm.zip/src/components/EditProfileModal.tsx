import React, { useState, useEffect } from 'react';
import { 
  X, 
  Save, 
  Camera, 
  User, 
  Phone, 
  MapPin, 
  GraduationCap, 
  Heart, 
  Share2, 
  Check, 
  AlertCircle,
  KeyRound,
  Eye,
  EyeOff
} from 'lucide-react';
import { Batchmate, AcademicGroup, BloodGroup } from '../types';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: Batchmate;
  onUpdateProfile: (updatedMember: Batchmate) => void;
  isLightMode: boolean;
}

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUpdateProfile,
  isLightMode,
}) => {
  const [name, setName] = useState(currentUser.name || '');
  const [nameBangla, setNameBangla] = useState(currentUser.nameBangla || '');
  const [rollNumber, setRollNumber] = useState(currentUser.rollNumber || '');
  const [group, setGroup] = useState<AcademicGroup>(currentUser.group || 'Science');
  const [gender, setGender] = useState<'Male' | 'Female'>(currentUser.gender || 'Male');
  const [blood, setBlood] = useState<BloodGroup | string>(currentUser.blood || 'A+');
  const [phone, setPhone] = useState(currentUser.phone || '');
  const [whatsapp, setWhatsapp] = useState(currentUser.whatsapp || currentUser.phone || '');
  const [address, setAddress] = useState(currentUser.address || 'ধনবাড়ী, টাঙ্গাইল');
  const [currentStatus, setCurrentStatus] = useState(currentUser.currentStatus || '');
  const [bio, setBio] = useState(currentUser.bio || '');
  const [facebook, setFacebook] = useState(currentUser.facebook || '');
  const [pin, setPin] = useState(currentUser.pin || '');
  const [showPin, setShowPin] = useState(false);
  const [photoUrl, setPhotoUrl] = useState(currentUser.photoUrl || '');
  const [hidePhone, setHidePhone] = useState<boolean>(currentUser.hidePhone ?? false);
  
  const [error, setError] = useState('');
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setName(currentUser.name || '');
      setNameBangla(currentUser.nameBangla || '');
      setRollNumber(currentUser.rollNumber || '');
      setGroup(currentUser.group || 'Science');
      setGender(currentUser.gender || 'Male');
      setBlood(currentUser.blood || 'A+');
      setPhone(currentUser.phone || '');
      setWhatsapp(currentUser.whatsapp || currentUser.phone || '');
      setAddress(currentUser.address || 'ধনবাড়ী, টাঙ্গাইল');
      setCurrentStatus(currentUser.currentStatus || '');
      setBio(currentUser.bio || '');
      setFacebook(currentUser.facebook || '');
      setPin(currentUser.pin || '');
      setPhotoUrl(currentUser.photoUrl || '');
      setHidePhone(currentUser.hidePhone ?? false);
      setError('');
      setSavedSuccess(false);
    }
  }, [isOpen, currentUser]);

  if (!isOpen) return null;

  // Handle Photo File Upload
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError('ছবির সাইজ সর্বোচ্চ ৫ মেগাবাইট হতে পারবে।');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        setPhotoUrl(reader.result as string);
        setError('');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('নাম ফাঁকা রাখা যাবে না।');
      return;
    }
    if (!phone.trim()) {
      setError('মোবাইল নম্বর ফাঁকা রাখা যাবে না।');
      return;
    }

    const updated: Batchmate = {
      ...currentUser,
      name: name.trim(),
      nameBangla: nameBangla.trim() || undefined,
      rollNumber: rollNumber.trim() || undefined,
      group,
      gender,
      blood,
      phone: phone.trim(),
      whatsapp: whatsapp.trim() || phone.trim(),
      address: address.trim(),
      currentStatus: currentStatus.trim() || undefined,
      bio: bio.trim() || undefined,
      facebook: facebook.trim() || undefined,
      pin: pin.trim() || currentUser.pin,
      photoUrl: photoUrl || currentUser.photoUrl,
      hidePhone,
    };

    onUpdateProfile(updated);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div 
        className={`relative w-full max-w-2xl rounded-3xl p-5 sm:p-8 border shadow-2xl overflow-hidden max-h-[92vh] flex flex-col ${
          isLightMode
            ? 'bg-white border-amber-300 text-slate-800'
            : 'bg-slate-900 border-amber-500/30 text-slate-100 shadow-amber-500/10'
        }`}
      >
        {/* Top Gold Bar */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-amber-400 via-amber-300 to-amber-600" />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-700/40">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400/20 text-amber-400 flex items-center justify-center">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold">আমার প্রোফাইল এডিট করুন</h3>
              <p className="text-xs text-slate-400 font-['Hind_Siliguri']">
                আপনার নাম, ছবি, রক্তের গ্রুপ, বর্তমান পড়াশোনা ও যোগাযোগের তথ্য আপডেট করুন
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body (Scrollable) */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto py-4 space-y-4 pr-1">
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {savedSuccess && (
            <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>আপনার প্রোফাইল সফলভাবে আপডেট হয়েছে!</span>
            </div>
          )}

          {/* Photo Edit */}
          <div className="flex items-center gap-4 p-3 rounded-2xl bg-slate-950/50 border border-slate-800">
            <div className="relative group shrink-0">
              <img
                src={photoUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(name || 'Batchmate')}&background=0f172a&color=fbbf24&size=200`}
                alt="Profile"
                className="w-16 h-16 rounded-2xl object-cover border-2 border-amber-400 shadow-md"
              />
              <label className="absolute inset-0 rounded-2xl cursor-pointer flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity">
                <Camera className="w-5 h-5 text-white" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
              </label>
            </div>
            <div className="flex-1">
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                ছবি পরিবর্তন করুন (মোবাইল গ্যালারি বা ক্যামেরা)
              </label>
              <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-amber-400/20 hover:bg-amber-400/30 text-amber-300 border border-amber-400/40 cursor-pointer transition-colors">
                <Camera className="w-3.5 h-3.5" />
                <span>নতুন ছবি সিলেক্ট করুন</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Names */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                পূর্ণ নাম (English) *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700 focus:border-amber-400 focus:outline-none text-white text-xs"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                বাংলায় নাম
              </label>
              <input
                type="text"
                value={nameBangla}
                onChange={(e) => setNameBangla(e.target.value)}
                placeholder="যেমন: শাকিল আহমেদ"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700 focus:border-amber-400 focus:outline-none text-white text-xs font-['Hind_Siliguri']"
              />
            </div>
          </div>

          {/* Academic Info */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                এসএসসি রোল নং
              </label>
              <input
                type="text"
                value={rollNumber}
                onChange={(e) => setRollNumber(e.target.value)}
                placeholder="রোল নম্বর"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700 focus:border-amber-400 focus:outline-none text-white text-xs font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                গ্রুপ / বিভাগ
              </label>
              <select
                value={group}
                onChange={(e) => setGroup(e.target.value as AcademicGroup)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700 focus:border-amber-400 focus:outline-none text-white text-xs"
              >
                <option value="Science">বিজ্ঞান (Science)</option>
                <option value="Humanities">মানবিক (Humanities)</option>
                <option value="Commerce">ব্যবসায় শিক্ষা (Commerce)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                রক্তের গ্রুপ
              </label>
              <select
                value={blood}
                onChange={(e) => setBlood(e.target.value as BloodGroup)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700 focus:border-amber-400 focus:outline-none text-white text-xs"
              >
                <option value="A+">A+ (পজেটিভ)</option>
                <option value="A-">A- (নেগেটিভ)</option>
                <option value="B+">B+ (পজেটিভ)</option>
                <option value="B-">B- (নেগেটিভ)</option>
                <option value="O+">O+ (পজেটিভ)</option>
                <option value="O-">O- (নেগেটিভ)</option>
                <option value="AB+">AB+ (পজেটিভ)</option>
                <option value="AB-">AB- (নেগেটিভ)</option>
              </select>
            </div>
          </div>

          {/* Present Status & Location */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                বর্তমান কলেজ / পড়াশোনা / অবস্থান
              </label>
              <input
                type="text"
                value={currentStatus}
                onChange={(e) => setCurrentStatus(e.target.value)}
                placeholder="যেমন: ধনবাড়ী সরকারি কলেজ / HSC '25"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700 focus:border-amber-400 focus:outline-none text-white text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                ঠিকানা / গ্রাম
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="যেমন: ধনবাড়ী, টাঙ্গাইল"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700 focus:border-amber-400 focus:outline-none text-white text-xs"
              />
            </div>
          </div>

          {/* Contact Details */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                মোবাইল নম্বর *
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700 focus:border-amber-400 focus:outline-none text-white text-xs"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                হোয়াটসঅ্যাপ নম্বর
              </label>
              <input
                type="tel"
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700 focus:border-amber-400 focus:outline-none text-white text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                ৪ ডিজিট পিন কোড (লগইনের জন্য)
              </label>
              <div className="relative">
                <input
                  type={showPin ? 'text' : 'password'}
                  maxLength={8}
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="পিন কোড"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700 focus:border-amber-400 focus:outline-none text-white text-xs font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPin(!showPin)}
                  className="absolute right-2.5 top-2 text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  {showPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>

          {/* Privacy: Hide Phone option */}
          <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-start gap-3">
            <input
              type="checkbox"
              id="hidePhoneCheckbox"
              checked={hidePhone}
              onChange={(e) => setHidePhone(e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded text-amber-500 bg-slate-900 border-slate-700 focus:ring-amber-400 cursor-pointer"
            />
            <label htmlFor="hidePhoneCheckbox" className="text-xs text-slate-300 cursor-pointer select-none">
              <span className="font-bold text-amber-300 block mb-0.5">
                মোবাইল নম্বর সবার কাছ থেকে গোপন রাখুন (Private Phone)
              </span>
              <span className="text-[11px] text-slate-400 block font-['Hind_Siliguri']">
                এটি টিক দিলে সাধারণ সহপাঠীরা আপনার ফোন নম্বর দেখতে পারবে না বা কল দিতে পারবে না, শুধুমাত্র অ্যাডমিন প্যানেল থেকে দেখতে পারবে।
              </span>
            </label>
          </div>

          {/* Bio & Facebook */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                ফেসবুক আইডি / লিংক (ঐচ্ছিক)
              </label>
              <input
                type="url"
                value={facebook}
                onChange={(e) => setFacebook(e.target.value)}
                placeholder="https://facebook.com/your.profile"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700 focus:border-amber-400 focus:outline-none text-white text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                স্কুলের স্মৃতি / বায়ো
              </label>
              <input
                type="text"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="যেমন: স্কুলের ফিল্ডের আড্ডা কখনো ভুলব না..."
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700 focus:border-amber-400 focus:outline-none text-white text-xs"
              />
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer transition-colors"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 flex items-center gap-1.5 shadow-lg shadow-amber-400/20 cursor-pointer transition-transform active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>পরিবর্তন সংরক্ষণ করুন</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
