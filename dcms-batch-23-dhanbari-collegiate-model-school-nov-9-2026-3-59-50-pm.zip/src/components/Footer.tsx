import React from 'react';
import { GraduationCap, Heart, ArrowUp, Sparkles, MapPin, Mail, Phone } from 'lucide-react';

interface FooterProps {
  onNavigate: (tab: string) => void;
  isLightMode: boolean;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, isLightMode }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className={`border-t relative pt-16 pb-12 overflow-hidden ${
      isLightMode
        ? 'bg-slate-100 border-amber-200 text-slate-700'
        : 'bg-slate-950 border-amber-500/20 text-slate-400'
    }`}>
      {/* Top golden gradient line */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-amber-400 to-transparent"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand Col */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full p-0.5 bg-gradient-to-tr from-amber-400 to-amber-600 flex items-center justify-center">
                <div className="w-full h-full rounded-full bg-slate-950 flex flex-col items-center justify-center text-center">
                  <span className="text-[10px] font-black text-amber-400">DCMS</span>
                  <span className="text-sm font-black text-amber-300 leading-none">'23</span>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-black gradient-text">
                  DCMS BATCH '23
                </h3>
                <p className="text-xs font-semibold text-amber-400 font-['Hind_Siliguri']">
                  ধনবাড়ী কলেজিয়েট মডেল স্কুল • ব্যাচ ২০২৩
                </p>
              </div>
            </div>

            <p className="text-xs leading-relaxed text-slate-400 max-w-md font-['Hind_Siliguri']">
              একসাথে পথচলা, অগণিত স্মৃতি, অটুট বন্ধন।<br />
              ধনবাড়ীর ঐতিহ্যবাহী স্কুলের প্রাঙ্গণ থেকে শুরু হওয়া ব্যাচ ’২৩—বন্ধুত্বের এই বন্ধন থাকুক চিরকাল।
            </p>

            <div className="flex items-center gap-2 text-xs text-slate-400">
              <MapPin className="w-3.5 h-3.5 text-amber-400" />
              <span>Dhanbari, Tangail, Dhaka Division, Bangladesh</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-4">
              Quick Portals
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('directory')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Batchmate Directory (ডিরেক্টরি)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('fame')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Hall of Fame (কৃতিত্ব)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('gallery')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Photo Memories (স্মৃতির অ্যালবাম)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('stories')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Campus Stories (স্মৃতিচারণ)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('blood')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Blood Bank (জরুরী রক্তদাতা)
                </button>
              </li>
            </ul>
          </div>

          {/* Event & Admin */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-4">
              Events & Portal
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('reunion')}
                  className="hover:text-amber-400 transition-colors cursor-pointer font-semibold text-amber-400"
                >
                  Grand Reunion 2026 Registration
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('admin')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Admin Control Panel (লগইন)
                </button>
              </li>
              <li className="pt-2">
                <span className="text-[11px] text-slate-500 block">Motto:</span>
                <span className="text-xs font-bold text-amber-400">One Batch, One Bond, One Legacy ❤️</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <p className="text-slate-500 text-center sm:text-left">
            © 2026 DCMS Batch '23. Dhanbari Collegiate Model School, Tangail. All rights reserved.
          </p>

          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-slate-400">
              Made with <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" /> for Batch '23
            </span>
            <button
              onClick={scrollToTop}
              className="p-2 rounded-xl bg-amber-400 text-slate-950 hover:bg-amber-300 transition-colors cursor-pointer"
              title="Scroll to Top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
