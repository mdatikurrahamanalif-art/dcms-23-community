import React, { useState } from 'react';
import { Award, Trophy, Star, Sparkles, Building, ChevronRight } from 'lucide-react';
import { HallOfFameItem } from '../types';

interface HallOfFameProps {
  items: HallOfFameItem[];
  isLightMode: boolean;
}

export const HallOfFame: React.FC<HallOfFameProps> = ({ items, isLightMode }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const categories = [
    { id: 'ALL', label: 'All Achievements' },
    { id: 'Engineering', label: 'Engineering' },
    { id: 'Medical', label: 'Medical' },
    { id: 'Public University', label: 'Public Universities' },
    { id: 'Leadership', label: 'Debate & Leadership' },
  ];

  const filteredItems = items.filter(
    (item) => selectedCategory === 'ALL' || item.category === selectedCategory
  );

  return (
    <section id="fame" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Section Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-semibold mb-3">
          <Trophy className="w-3.5 h-3.5 text-amber-400" />
          <span>Batch Hall of Fame • গৌরবগাথা</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold gradient-text mb-3">
          Celebrating Batch '23 Achievers
        </h2>
        <p className="text-sm sm:text-base text-slate-400 font-['Hind_Siliguri']">
          আমাদের ব্যাচের গৌরব যারা দেশসেরা বুয়েট, মেডিকেল ও ঢাকা বিশ্ববিদ্যালয়সহ বিভিন্ন ক্ষেত্রে ডিসিএমএস-এর নাম উজ্জ্বল করেছে।
        </p>

        {/* Filter Chips */}
        <div className="flex flex-wrap items-center justify-center gap-2 mt-6">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                  : isLightMode
                  ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  : 'bg-slate-900 border border-amber-500/20 text-slate-300 hover:text-amber-400'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Achievers */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            className={`glass-card rounded-3xl p-6 border relative overflow-hidden transition-all duration-300 ${
              isLightMode
                ? 'bg-white border-amber-200 shadow-xl hover:border-amber-400'
                : 'bg-slate-900/70 border-amber-500/30 shadow-2xl hover:border-amber-400 hover:shadow-amber-500/10'
            }`}
          >
            {/* Top gold glow accent */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none"></div>

            <div className="flex items-start gap-4 mb-4">
              <div className="relative">
                <div className="w-18 h-18 sm:w-20 sm:h-20 rounded-2xl p-1 bg-gradient-to-tr from-amber-400 via-yellow-200 to-amber-600 shadow-xl shadow-amber-500/20 overflow-hidden">
                  <img
                    src={item.photoUrl}
                    alt={item.name}
                    className="w-full h-full object-cover rounded-xl"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(item.name)}&background=0f172a&color=fbbf24`;
                    }}
                  />
                </div>
                <div className="absolute -bottom-2 -right-2 p-1.5 rounded-full bg-amber-400 text-slate-950 shadow-md">
                  <Star className="w-3.5 h-3.5 fill-slate-950" />
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30 mb-1">
                  {item.category}
                </span>
                <h3 className="text-lg font-bold text-slate-100 truncate">
                  {item.name}
                </h3>
                {item.institution && (
                  <p className="text-xs font-semibold text-amber-400 flex items-center gap-1 mt-0.5">
                    <Building className="w-3 h-3 flex-shrink-0" />
                    <span className="truncate">{item.institution}</span>
                  </p>
                )}
                {item.year && (
                  <span className="text-[10px] text-slate-500">Session: {item.year}</span>
                )}
              </div>
            </div>

            <div className={`p-3.5 rounded-2xl border text-xs font-medium leading-relaxed ${
              isLightMode ? 'bg-amber-50/60 border-amber-200/80 text-slate-700' : 'bg-slate-950/50 border-slate-800 text-slate-300'
            }`}>
              {item.achievement}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
