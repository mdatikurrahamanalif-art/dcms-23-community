import React, { useState, useEffect } from 'react';
import { Users, Calendar, Heart, Sparkles, ChevronDown, GraduationCap, Award, UserPlus, School, Eye, ZoomIn, X, MapPin, Share2 } from 'lucide-react';

interface HeroProps {
  onNavigate: (tab: string) => void;
  onOpenJoinModal?: () => void;
  isLightMode: boolean;
  totalMembers: number;
  bloodGroupsCount: number;
  totalMemories: number;
  onOpenShare?: () => void;
}

export const Hero: React.FC<HeroProps> = ({ 
  onNavigate, 
  isLightMode, 
  totalMembers, 
  bloodGroupsCount,
  totalMemories,
  onOpenShare 
}) => {
  const [typedText, setTypedText] = useState('');
  const fullText = "Dhanbari Collegiate Model School — One Batch, One Bond, One Legacy... Batch ’23 ❤️";

  useEffect(() => {
    let index = 0;
    const interval = setInterval(() => {
      if (index <= fullText.length) {
        setTypedText(fullText.slice(0, index));
        index++;
      } else {
        clearInterval(interval);
      }
    }, 45);

    return () => clearInterval(interval);
  }, []);

  const [isPhotoZoomOpen, setIsPhotoZoomOpen] = useState(false);
  const campusPhotoUrl = '/assets/aistudio/IMG_c0994971-40ad-450c-85db-54079a561c7e_21b59f8d.jpg';

  return (
    <section className="relative min-h-[92vh] flex flex-col items-center justify-center pt-24 pb-16 px-4 overflow-hidden">
      {/* Authentic School Campus Full Background */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-all duration-700 opacity-90 sm:opacity-95"
        style={{ 
          backgroundImage: `url('${campusPhotoUrl}')`,
          backgroundPosition: 'center 35%',
        }}
      />
      {/* Balanced scrim gradient: ensures the 3-story building, trees and field are crisp and clear while text is fully readable */}
      <div className={`absolute inset-0 ${
        isLightMode
          ? 'bg-gradient-to-b from-slate-950/70 via-slate-950/45 to-slate-950/85'
          : 'bg-gradient-to-b from-[#020617]/80 via-[#020617]/50 to-[#020617]/95'
      }`} />

      {/* Floating Campus Badge indicator */}
      <div className="absolute top-20 right-4 sm:right-8 z-20 hidden md:flex items-center gap-2">
        <button
          onClick={() => setIsPhotoZoomOpen(true)}
          className="px-3.5 py-1.5 rounded-full text-xs font-semibold bg-slate-950/80 hover:bg-amber-400 hover:text-slate-950 text-amber-300 border border-amber-400/40 backdrop-blur-md shadow-lg transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <School className="w-3.5 h-3.5 text-amber-400" />
          <span>আমাদের ক্যাম্পাস • ফুলস্ক্রিন দেখুন</span>
          <ZoomIn className="w-3.5 h-3.5 ml-0.5" />
        </button>
      </div>

      {/* Background glow and ambient gradient */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full blur-[140px] opacity-20 bg-amber-500" />
      </div>

      {/* Floating particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="particle-item"
            style={{
              width: `${(i % 5) * 2 + 3}px`,
              height: `${(i % 5) * 2 + 3}px`,
              left: `${(i * 4.8) % 100}%`,
              animationDuration: `${12 + (i % 8) * 3}s`,
              animationDelay: `${(i % 6) * 1.5}s`,
              opacity: (i % 3 === 0) ? 0.6 : 0.3,
            }}
          />
        ))}
      </div>

      {/* Main Hero Container with glass backdrop */}
      <div className="relative z-10 max-w-4xl mx-auto text-center flex flex-col items-center bg-slate-950/65 backdrop-blur-md border border-amber-400/30 rounded-3xl p-6 sm:p-10 shadow-2xl my-4">
        {/* Animated Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full mb-6 border border-amber-400/40 bg-amber-400/15 backdrop-blur-md">
          <School className="w-4 h-4 text-amber-400" />
          <span className="text-xs sm:text-sm font-semibold tracking-wide text-amber-300">
            Dhanbari Collegiate Model School, Tangail
          </span>
        </div>

        {/* School Crest / Batch Emblem */}
        <div className="relative mb-5 hero-logo-pulse">
          <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full p-1 bg-gradient-to-tr from-amber-500 via-yellow-300 to-amber-600 shadow-2xl shadow-amber-500/40 flex items-center justify-center">
            <div className="w-full h-full rounded-full bg-slate-950 flex flex-col items-center justify-center border-2 border-amber-400/30 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-500/20 via-transparent to-transparent"></div>
              <GraduationCap className="w-7 h-7 sm:w-9 sm:h-9 text-amber-400 mb-0.5" />
              <span className="text-xs sm:text-sm font-black text-amber-300 tracking-wider">DCMS</span>
              <span className="text-lg sm:text-2xl font-black bg-gradient-to-b from-amber-200 via-amber-400 to-amber-600 bg-clip-text text-transparent">
                '23
              </span>
            </div>
          </div>
          {/* Subtle outer glow ring */}
          <div className="absolute -inset-2 rounded-full border border-amber-400/20 animate-ping opacity-30 pointer-events-none"></div>
        </div>

        {/* Title */}
        <h1 className="text-3xl sm:text-5xl md:text-6xl font-extrabold tracking-tight mb-3">
          <span className="gradient-text drop-shadow-md">DCMS BATCH '23</span>
        </h1>

        {/* Typewriter text */}
        <div className="min-h-[44px] sm:min-h-[32px] max-w-2xl px-4 flex items-center justify-center mb-6">
          <p className="text-xs sm:text-sm md:text-base font-medium italic text-slate-200 drop-shadow">
            "{typedText}
            <span className="inline-block w-1.5 h-4 ml-1 bg-amber-400 animate-pulse align-middle"></span>"
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 sm:gap-3.5 mb-8">

          <button
            onClick={() => onNavigate('directory')}
            className="px-4 py-3 text-xs sm:text-sm font-bold rounded-full border border-amber-400/40 bg-slate-900/80 text-slate-100 hover:border-amber-400 hover:text-amber-300 transition-all duration-300 flex items-center gap-2 cursor-pointer shadow-md"
          >
            <Users className="w-4 h-4 text-amber-400" />
            <span>ব্যাচমেট তালিকা (Directory)</span>
          </button>

          <button
            onClick={() => onNavigate('reunion')}
            className="px-4 py-3 text-xs sm:text-sm font-bold rounded-full border border-amber-400 text-amber-300 hover:bg-amber-400 hover:text-slate-950 transition-all duration-300 flex items-center gap-2 cursor-pointer shadow-md"
          >
            <Calendar className="w-4 h-4" />
            <span>রিইউনিয়ন (Reunion)</span>
          </button>

          <button
            onClick={() => onNavigate('blood')}
            className="px-3.5 py-3 text-xs font-semibold rounded-full border border-rose-500/50 bg-slate-900/70 text-rose-300 hover:bg-rose-500/20 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Heart className="w-4 h-4 text-rose-500 fill-rose-500/40" />
            <span>রক্তদাতা (Blood)</span>
          </button>

          <button
            onClick={() => setIsPhotoZoomOpen(true)}
            className="px-3.5 py-3 text-xs font-semibold rounded-full border border-sky-500/40 bg-slate-950/70 text-sky-300 hover:bg-sky-500/20 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <ZoomIn className="w-4 h-4 text-sky-400" />
            <span>ক্যাম্পাস ছবি জুম</span>
          </button>

          {onOpenShare && (
            <button
              onClick={onOpenShare}
              className="px-4 py-3 text-xs sm:text-sm font-bold rounded-full bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 transition-all duration-300 flex items-center gap-1.5 cursor-pointer shadow-lg shadow-amber-400/20"
            >
              <Share2 className="w-4 h-4 text-slate-950" />
              <span>ওয়েবসাইট শেয়ার করুন (Share)</span>
            </button>
          )}
        </div>

        {/* Quick Highlights / Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-4 w-full">
          <div className="bg-slate-950/80 backdrop-blur-md p-3.5 rounded-2xl flex flex-col items-center border border-amber-500/30 shadow-md">
            <span className="text-xl sm:text-2xl font-black text-amber-400">{totalMembers}</span>
            <span className="text-xs font-medium mt-0.5 text-slate-300">Total Batchmates</span>
            <span className="text-[10px] text-amber-400/80 font-['Hind_Siliguri']">নিবন্ধিত সহপাঠী</span>
          </div>

          <div className="bg-slate-950/80 backdrop-blur-md p-3.5 rounded-2xl flex flex-col items-center border border-amber-500/30 shadow-md">
            <span className="text-xl sm:text-2xl font-black text-amber-400">100%</span>
            <span className="text-xs font-medium mt-0.5 text-slate-300">SSC '23 Success</span>
            <span className="text-[10px] text-amber-400/80 font-['Hind_Siliguri']">গৌরবোজ্জ্বল ফলাফল</span>
          </div>

          <div className="bg-slate-950/80 backdrop-blur-md p-3.5 rounded-2xl flex flex-col items-center border border-amber-500/30 shadow-md">
            <span className="text-xl sm:text-2xl font-black text-amber-400">{bloodGroupsCount}</span>
            <span className="text-xs font-medium mt-0.5 text-slate-300">Blood Groups</span>
            <span className="text-[10px] text-rose-400 font-medium font-['Hind_Siliguri']">রক্তদাতা ক্যাটাগরি</span>
          </div>

          <div className="bg-slate-950/80 backdrop-blur-md p-3.5 rounded-2xl flex flex-col items-center border border-amber-500/30 shadow-md">
            <span className="text-xl sm:text-2xl font-black text-amber-400">{totalMemories}</span>
            <span className="text-xs font-medium mt-0.5 text-slate-300">Sweet Memories</span>
            <span className="text-[10px] text-amber-400/80 font-['Hind_Siliguri']">ছবি ও স্মৃতিচারণ</span>
          </div>
        </div>
      </div>

      {/* Fullscreen Campus Photo Lightbox Modal */}
      {isPhotoZoomOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-md animate-fadeIn">
          <div className="relative max-w-5xl w-full bg-slate-900 border border-amber-400/40 rounded-3xl overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950">
              <div className="flex items-center gap-2">
                <School className="w-5 h-5 text-amber-400" />
                <span className="font-bold text-slate-100 text-sm sm:text-base font-['Hind_Siliguri']">
                  ধনবাড়ী কলেজিয়েট মডেল স্কুল ৩ তলা ভবন ও মুক্ত প্রাঙ্গণ
                </span>
              </div>
              <button
                onClick={() => setIsPhotoZoomOpen(false)}
                className="p-1.5 rounded-full bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 sm:p-5 bg-black flex flex-col items-center justify-center">
              <img
                src={campusPhotoUrl}
                alt="Dhanbari Collegiate Model School Campus"
                className="max-h-[75vh] w-auto max-w-full rounded-xl object-contain shadow-2xl"
              />
            </div>

            <div className="p-4 bg-slate-950 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs sm:text-sm">
              <div className="text-slate-300 font-['Hind_Siliguri']">
                <span className="font-semibold text-amber-400">ক্যাম্পাস পরিচয়: </span>
                ধনবাড়ী কলেজিয়েট মডেল স্কুল ৩ তলা একাডেমিক ভবন ও মুক্ত প্রাঙ্গণ, ধনবাড়ী, টাঙ্গাইল।
              </div>
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full bg-amber-400/10 text-amber-300 border border-amber-400/30 text-xs font-semibold">
                  DCMS Batch '23 Campus
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Scroll indicator */}
      <button 
        onClick={() => onNavigate('directory')}
        className="mt-8 text-slate-300 hover:text-amber-400 transition-colors animate-bounce cursor-pointer flex flex-col items-center text-xs z-10"
      >
        <span>Explore Batch '23</span>
        <ChevronDown className="w-5 h-5 mt-1" />
      </button>
    </section>
  );
};
