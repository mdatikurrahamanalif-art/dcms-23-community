import React, { useState, useRef } from 'react';
import { 
  UserPlus, 
  X, 
  CheckCircle2, 
  Upload, 
  Camera, 
  Sparkles, 
  Phone, 
  Heart, 
  Calendar, 
  MapPin, 
  GraduationCap 
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Batchmate, AcademicGroup, BloodGroup } from '../types';
import { compressImageFile } from '../utils/imageUpload';

interface JoinBatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRegisterBatchmate: (batchmate: Batchmate) => void;
  isLightMode: boolean;
}

export const JoinBatchModal: React.FC<JoinBatchModalProps> = ({
  isOpen,
  onClose,
  onRegisterBatchmate,
  isLightMode,
}) => {
  const [name, setName] = useState('');
  const [nameBangla, setNameBangla] = useState('');
  const [group, setGroup] = useState<AcademicGroup>('Science');
  const [gender, setGender] = useState<'Male' | 'Female'>('Male');
  const [rollNumber, setRollNumber] = useState('');
  const [blood, setBlood] = useState<string>('O+');
  const [dob, setDob] = useState('');
  const [phone, setPhone] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [currentStatus, setCurrentStatus] = useState('');
  const [facebook, setFacebook] = useState('');
  const [bio, setBio] = useState('');
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [isProcessingPhoto, setIsProcessingPhoto] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsProcessingPhoto(true);
      const compressed = await compressImageFile(file, 800, 0.85);
      setPhotoPreview(compressed);
    } catch (err: any) {
      alert(`ছবি লোড করতে সমস্যা হয়েছে: ${err.message}`);
    } finally {
      setIsProcessingPhoto(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      alert('দয়া করে আপনার নাম এবং মোবাইল নম্বর প্রদান করুন।');
      return;
    }

    // Extract birthday MM-DD
    let bday = '';
    if (dob) {
      const parts = dob.split('-');
      if (parts.length === 3) {
        bday = `${parts[1]}-${parts[2]}`;
      }
    }

    const defaultAvatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(name.trim())}&background=0f172a&color=fbbf24&size=400`;

    const newMember: Batchmate = {
      id: `student-${Date.now()}`,
      name: name.trim(),
      nameBangla: nameBangla.trim() || undefined,
      group,
      gender,
      rollNumber: rollNumber.trim() || undefined,
      blood,
      dob: dob || undefined,
      birthday: bday || undefined,
      phone: phone.trim(),
      whatsapp: whatsapp.trim() || phone.trim(),
      email: email.trim() || undefined,
      address: address.trim() || 'Dhanbari, Tangail',
      currentStatus: currentStatus.trim() || undefined,
      facebook: facebook.trim() || undefined,
      bio: bio.trim() || undefined,
      photoUrl: photoPreview || defaultAvatar,
    };

    onRegisterBatchmate(newMember);
    setIsSuccess(true);

    // Fire celebratory confetti!
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#fbbf24', '#f59e0b', '#38bdf8', '#34d399', '#ec4899'],
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className={`relative w-full max-w-2xl my-8 rounded-3xl p-6 sm:p-8 border shadow-2xl overflow-hidden ${
        isLightMode
          ? 'bg-white border-amber-300 text-slate-800'
          : 'bg-slate-900 border-amber-500/30 text-slate-100 shadow-amber-500/10'
      }`}>
        {/* Top Gold Trim */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-amber-400 via-amber-300 to-amber-600"></div>

        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {isSuccess ? (
          <div className="p-8 text-center flex flex-col items-center">
            <div className="w-20 h-20 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-4">
              <CheckCircle2 className="w-12 h-12" />
            </div>
            <h3 className="text-2xl font-black gradient-text mb-2">
              অভিনন্দন! আপনি যুক্ত হয়েছেন!
            </h3>
            <p className="text-sm text-slate-300 font-['Hind_Siliguri'] max-w-md mb-6">
              আপনার প্রোফাইল ডিসিএমএস ব্যাচ '২৩ এর ব্যাচমেট ডিরেক্টরি এবং রক্তদাতা তালিকায় তাৎক্ষণিকভাবে যুক্ত হয়েছে।
            </p>
            <button
              onClick={() => {
                setIsSuccess(false);
                onClose();
              }}
              className="btn-gold px-8 py-3 text-xs font-bold cursor-pointer"
            >
              ডিরেক্টরিতে আমার নাম দেখুন
            </button>
          </div>
        ) : (
          <div>
            {/* Header */}
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-600 text-slate-950 flex items-center justify-center shadow-lg shadow-amber-500/20">
                <UserPlus className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl sm:text-2xl font-black gradient-text">
                  ব্যাচমেট রেজিস্ট্রেশন (Join Batch Directory)
                </h3>
                <p className="text-xs text-slate-400 font-['Hind_Siliguri']">
                  ডিসিএমএস ব্যাচ '২৩ এর যে কোনো বন্ধু এখানে আপনার প্রোফাইল তৈরি করতে পারেন।
                </p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Photo Upload Area */}
              <div className="flex flex-col sm:flex-row items-center gap-4 p-4 rounded-2xl bg-slate-950/40 border border-amber-500/20">
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="relative w-24 h-24 rounded-2xl overflow-hidden border-2 border-dashed border-amber-400 cursor-pointer group flex items-center justify-center bg-slate-900"
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    onChange={handlePhotoSelect}
                    className="hidden"
                  />
                  {photoPreview ? (
                    <img src={photoPreview} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <div className="flex flex-col items-center text-center p-2">
                      <Camera className="w-6 h-6 text-amber-400 mb-1 group-hover:scale-110 transition-transform" />
                      <span className="text-[10px] text-slate-300 font-bold">ছবি দিন</span>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                    <Upload className="w-5 h-5 text-amber-400" />
                  </div>
                </div>

                <div className="flex-1 text-center sm:text-left">
                  <span className="text-xs font-bold text-amber-400 block mb-1">
                    আপনার ছবি আপলোড করুন (ফোন গ্যালারি থেকে)
                  </span>
                  <p className="text-[11px] text-slate-400 leading-relaxed font-['Hind_Siliguri']">
                    আপনার মোবাইল বা কম্পিউটার থেকে পাসপোর্ট সাইজ বা সুন্দর একটি হাসিমুখের ছবি সিলেক্ট করুন। (ছবি না দিলেও চলবে)
                  </p>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="mt-2 text-xs font-bold px-3 py-1 rounded-lg bg-amber-400/20 text-amber-300 border border-amber-400/30 hover:bg-amber-400 hover:text-slate-950 transition-colors cursor-pointer"
                  >
                    {isProcessingPhoto ? 'প্রসেস হচ্ছে...' : photoPreview ? 'ছবি পরিবর্তন করুন' : 'গ্যালারি থেকে ছবি বাছুন'}
                  </button>
                </div>
              </div>

              {/* Name inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Full Name (ইংরেজিতে আপনার নাম) *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Asaduzzaman Abir"
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    নাম (বাংলায়)
                  </label>
                  <input
                    type="text"
                    value={nameBangla}
                    onChange={(e) => setNameBangla(e.target.value)}
                    placeholder="যেমন: আসাদুজ্জামান আবির"
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  />
                </div>
              </div>

              {/* Group, Gender, Blood */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    বিভাগ (Group) *
                  </label>
                  <select
                    value={group}
                    onChange={(e) => setGroup(e.target.value as AcademicGroup)}
                    className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  >
                    <option value="Science">Science (বিজ্ঞান)</option>
                    <option value="Commerce">Commerce (বাণিজ্য)</option>
                    <option value="Humanities">Humanities (মানবিক)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    রক্তের গ্রুপ *
                  </label>
                  <select
                    value={blood}
                    onChange={(e) => setBlood(e.target.value)}
                    className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  >
                    {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((bg) => (
                      <option key={bg} value={bg}>{bg}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    লিঙ্গ (Gender) *
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as any)}
                    className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  >
                    <option value="Male">ছেলে (Male)</option>
                    <option value="Female">মেয়ে (Female)</option>
                  </select>
                </div>
              </div>

              {/* Phone, WhatsApp & DOB */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    মোবাইল নম্বর *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="01700-000000"
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    হোয়াটসঅ্যাপ (ঐচ্ছিক)
                  </label>
                  <input
                    type="tel"
                    value={whatsapp}
                    onChange={(e) => setWhatsapp(e.target.value)}
                    placeholder="01700-000000"
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    জন্মতারিখ (Date of Birth)
                  </label>
                  <input
                    type="date"
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  />
                </div>
              </div>

              {/* Address and Current University */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    স্থায়ী/বর্তমান ঠিকানা (Hometown / Address) *
                  </label>
                  <input
                    type="text"
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="যেমন: কলেজ পাড়া, ধনবাড়ী, টাঙ্গাইল"
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    বর্তমান প্রতিষ্ঠান / পড়াশোনা / পেশা
                  </label>
                  <input
                    type="text"
                    value={currentStatus}
                    onChange={(e) => setCurrentStatus(e.target.value)}
                    placeholder="যেমন: ঢাকা বিশ্ববিদ্যালয় (অর্থনীতি) বা BUET"
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  />
                </div>
              </div>

              {/* Facebook & Personal Bio */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    ফেসবুক প্রোফাইল লিংক (ঐচ্ছিক)
                  </label>
                  <input
                    type="url"
                    value={facebook}
                    onChange={(e) => setFacebook(e.target.value)}
                    placeholder="https://facebook.com/your.username"
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    স্কুলের রোল নম্বর (ঐচ্ছিক)
                  </label>
                  <input
                    type="text"
                    value={rollNumber}
                    onChange={(e) => setRollNumber(e.target.value)}
                    placeholder="e.g. 05"
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  বন্ধুদের উদ্দেশ্যে বার্তা বা প্রিয় উক্তি (Message to Batch)
                </label>
                <textarea
                  rows={2}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="যেমন: জীবনের প্রতিটি পদক্ষেপে ডিসিএমএস ব্যাচ ২৩ এক অনুপ্রেরণা..."
                  className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                    isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                  }`}
                />
              </div>

              <button
                type="submit"
                className="btn-gold w-full py-3.5 text-xs sm:text-sm font-bold shadow-lg shadow-amber-400/20 cursor-pointer"
              >
                নিবন্ধন সম্পন্ন করুন (Join DCMS Batch '23)
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
