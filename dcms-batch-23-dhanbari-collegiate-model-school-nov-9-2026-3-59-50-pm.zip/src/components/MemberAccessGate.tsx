import React, { useState } from 'react';
import { 
  Lock, 
  Phone, 
  GraduationCap, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  School,
  ArrowRight,
  ShieldCheck,
  User,
  KeyRound,
  Eye,
  EyeOff,
  X
} from 'lucide-react';
import { Batchmate } from '../types';

interface MemberAccessGateProps {
  batchmates: Batchmate[];
  onLoginSuccess: (member: Batchmate) => void;
  onAdminBypass: () => void;
  onClose?: () => void;
  isLightMode: boolean;
}

export const MemberAccessGate: React.FC<MemberAccessGateProps> = ({
  batchmates,
  onLoginSuccess,
  onAdminBypass,
  onClose,
  isLightMode,
}) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [fullName, setFullName] = useState('');
  const [hidePhone, setHidePhone] = useState(false);
  const [promoCode, setPromoCode] = useState('');
  const [promoApplied, setPromoApplied] = useState(false);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Campus photo URL
  const campusPhotoUrl = '/assets/aistudio/IMG_c0994971-40ad-450c-85db-54079a561c7e_21b59f8d.jpg';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const rawPhone = phoneNumber.trim().replace(/\s+/g, '');
    const cleanPw = password.trim();

    if (!rawPhone || rawPhone.length < 6) {
      setError('দয়া করে আপনার সঠিক মোবাইল নম্বরটি লিখুন।');
      return;
    }

    if (!cleanPw) {
      setError('দয়া করে আপনার গোপন পাসওয়ার্ড লিখুন।');
      return;
    }

    setIsSubmitting(true);

    // Check if a member with this phone number already exists
    const existing = batchmates.find((b) => {
      const matchPhone = b.phone && b.phone.replace(/\s+/g, '') === rawPhone;
      return matchPhone;
    });

    if (existing) {
      // Verify existing password
      if (existing.pin && existing.pin !== cleanPw) {
        setError('ভুল পাসওয়ার্ড! সঠিক পাসওয়ার্ড দিয়ে চেষ্টা করুন।');
        setIsSubmitting(false);
        return;
      }

      // If user also provided a name, update their name if it was empty or default
      let updatedUser = { ...existing };
      if (!existing.pin) {
        updatedUser.pin = cleanPw;
      }
      if (fullName.trim() && (!existing.name || existing.name.startsWith('সহপাঠী'))) {
        updatedUser.name = fullName.trim();
      }
      onLoginSuccess(updatedUser);
      return;
    }

    // New Member Registration with Phone + Password
    const memberName = fullName.trim() || `সহপাঠী (${rawPhone.slice(-4)})`;
    const newMemberId = `batchmate-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const newMember: Batchmate = {
      id: newMemberId,
      name: memberName,
      phone: rawPhone,
      whatsapp: rawPhone,
      pin: cleanPw,
      hidePhone: hidePhone,
      group: 'Science',
      gender: 'Male',
      blood: 'A+',
      address: 'ধনবাড়ী, টাঙ্গাইল',
      currentStatus: 'DCMS Batch 23 Student',
      photoUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(memberName)}&background=0f172a&color=fbbf24&size=300`,
      isRepresentative: promoApplied || promoCode.trim().toUpperCase() === 'DCMS-23',
    };

    onLoginSuccess(newMember);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-slate-950/90 backdrop-blur-md">
      {/* Authentic School Campus Background */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-all duration-700 opacity-40 sm:opacity-50"
        style={{ 
          backgroundImage: `url('${campusPhotoUrl}')`,
          backgroundPosition: 'center 40%',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#020617]/95 via-[#020617]/85 to-[#020617]/98 pointer-events-none" />

      {/* Main Container Card */}
      <div className="relative z-10 w-full max-w-lg my-auto rounded-3xl bg-slate-900/90 border border-amber-500/30 p-6 sm:p-8 shadow-2xl shadow-amber-500/10 backdrop-blur-xl text-slate-100 animate-fade-in">
        {/* Optional Close / Skip Button */}
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            title="গেস্ট হিসেবে ওয়েবসাইট ঘুরে দেখুন"
            className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors z-20 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Header Crest */}
        <div className="text-center mb-6">
          <div className="inline-flex relative mb-3">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full p-0.5 bg-gradient-to-tr from-amber-400 via-amber-200 to-amber-600 shadow-xl shadow-amber-500/30 flex items-center justify-center mx-auto">
              <div className="w-full h-full rounded-full bg-slate-950 flex flex-col items-center justify-center border border-amber-400/40">
                <GraduationCap className="w-5 h-5 sm:w-7 sm:h-7 text-amber-400 mb-0.5" />
                <span className="text-[10px] sm:text-xs font-black text-amber-300 tracking-wider leading-none">DCMS</span>
                <span className="text-sm sm:text-base font-black bg-gradient-to-b from-amber-200 via-amber-400 to-amber-600 bg-clip-text text-transparent leading-none">
                  '23
                </span>
              </div>
            </div>
            <div className="absolute -bottom-1 -right-1 bg-amber-400 text-slate-950 p-1 rounded-full shadow">
              <Lock className="w-3.5 h-3.5" />
            </div>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 text-xs font-semibold mb-2">
            <School className="w-3.5 h-3.5 text-amber-400" />
            <span>ধানবাড়ী কলেজিয়েট মডেল স্কুল • ব্যাচ '২৩</span>
          </div>

          <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            মেম্বার আইডি এন্ট্রি ও রেজিস্ট্রেশন
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 font-['Hind_Siliguri']">
            প্রবেশ করতে বা নতুন আইডি খুলতে মোবাইল নম্বর ও পাসওয়ার্ড দিন।
          </p>
        </div>

        {/* Fast & Simple Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Phone Number */}
          <div>
            <label className="block text-xs font-bold text-amber-300 mb-1.5 flex items-center justify-between">
              <span>মোবাইল নম্বর (Phone Number) *</span>
              <span className="text-[10px] text-emerald-400 font-normal">লগইন আইডি</span>
            </label>
            <div className="relative">
              <input
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="যেমন: 017XXXXXXXX"
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 focus:border-amber-400 focus:outline-none text-white text-sm font-medium tracking-wide placeholder:text-slate-500 shadow-inner"
                required
                autoFocus
              />
              <Phone className="w-4 h-4 text-amber-400 absolute right-3.5 top-3.5" />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="block text-xs font-bold text-amber-300 mb-1.5 flex items-center justify-between">
              <span>পাসওয়ার্ড (Password) *</span>
              <span className="text-[10px] text-slate-400 font-normal">গোপন কোড</span>
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="আপনার পাসওয়ার্ড লিখুন"
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 focus:border-amber-400 focus:outline-none text-white text-sm font-mono tracking-wider placeholder:text-slate-500 shadow-inner"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-[11px] text-slate-400 mt-1 font-['Hind_Siliguri']">
              পূর্বে আইডি খোলা থাকলে আপনার পাসওয়ার্ড দিন, নতুন হলে একটি সহজ পাসওয়ার্ড সেট করুন।
            </p>
          </div>

          {/* Name (Optional) */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
              <span>আপনার নাম (ঐচ্ছিক / Optional)</span>
              <span className="text-[10px] text-slate-400">পরেও দেওয়া যাবে</span>
            </label>
            <div className="relative">
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="যেমন: সাকিব আহমেদ"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950/80 border border-slate-700 focus:border-amber-400 focus:outline-none text-white text-xs"
              />
              <User className="w-4 h-4 text-slate-500 absolute right-3.5 top-3" />
            </div>
          </div>

          {/* Privacy: Hide Phone Checkbox */}
          <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-start gap-2.5">
            <input
              type="checkbox"
              id="hidePhoneGateCheckbox"
              checked={hidePhone}
              onChange={(e) => setHidePhone(e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded text-amber-500 bg-slate-900 border-slate-700 focus:ring-amber-400 cursor-pointer"
            />
            <label htmlFor="hidePhoneGateCheckbox" className="text-xs text-slate-300 cursor-pointer select-none">
              <span className="font-bold text-amber-300 block mb-0.5">
                মোবাইল নম্বর সাধারণ মেম্বারদের কাছে গোপন রাখুন
              </span>
              <span className="text-[11px] text-slate-400 block font-['Hind_Siliguri']">
                এটি টিক দিলে সাধারণ সহপাঠীরা আপনার নম্বর দেখতে পারবে না, শুধুমাত্র অ্যাডমিন দেখতে পারবে।
              </span>
            </label>
          </div>

          {/* Promo Code: Secret entry */}
          <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-amber-300">
                প্রমো কোড (Promo Code) <span className="text-[10px] text-slate-500 font-normal">(ঐচ্ছিক)</span>
              </label>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={promoCode}
                onChange={(e) => {
                  setPromoCode(e.target.value);
                  setPromoApplied(e.target.value.trim().toUpperCase() === 'DCMS-23');
                }}
                placeholder="প্রমো কোড থাকলে লিখুন..."
                className={`flex-1 px-3 py-2 rounded-xl text-xs uppercase font-mono tracking-wider border focus:outline-none focus:ring-1 focus:ring-amber-400 ${
                  promoApplied ? 'border-emerald-500 bg-emerald-950/20 text-emerald-300' : 'bg-slate-950 border-slate-700 text-white'
                }`}
              />
              <button
                type="button"
                onClick={() => {
                  if (promoCode.trim().toUpperCase() === 'DCMS-23') {
                    setPromoApplied(true);
                  }
                }}
                className="px-3.5 py-2 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 cursor-pointer shadow"
              >
                Apply
              </button>
            </div>
            {promoApplied && (
              <p className="text-[11px] font-bold text-emerald-400 mt-1.5 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>প্রমো কোড কার্যকর হয়েছে! ভিআইপি ব্যাচমেট ব্যাজ যুক্ত হবে।</span>
              </p>
            )}
          </div>

          {/* Quick Notice */}
          <div className="p-2.5 rounded-2xl bg-amber-400/10 border border-amber-400/30 text-xs text-amber-300 font-['Hind_Siliguri'] flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              আইডি খোলার সাথে সাথে আপনার প্রোফাইল ব্যাচমেট তালিকায় দেখা যাবে এবং ভেতরে ঢুকে প্রোফাইল থেকে ছবি ও রক্তের গ্রুপ যোগ করতে পারবেন।
            </p>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 rounded-xl font-bold text-sm bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 cursor-pointer transition-transform active:scale-[0.99]"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>প্রবেশ করুন / আইডি খুলুন</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="w-full py-2.5 rounded-xl text-xs font-semibold text-slate-400 hover:text-amber-300 hover:bg-slate-800/60 border border-slate-800 transition-colors cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>আইডি ছাড়া সাধারণ দর্শক (Guest) হিসেবে ওয়েবসাইট দেখুন</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </form>

        {/* Footer info & Admin Bypass */}
        <div className="mt-6 pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>ডিসিএমএস '২৩ ব্যাচমেটদের জন্য সংরক্ষিত</span>
          </div>

          <button
            type="button"
            onClick={onAdminBypass}
            className="text-xs text-slate-400 hover:text-amber-400 underline cursor-pointer"
          >
            অ্যাডমিন প্যানেল দিয়ে প্রবেশ
          </button>
        </div>
      </div>
    </div>
  );
};
