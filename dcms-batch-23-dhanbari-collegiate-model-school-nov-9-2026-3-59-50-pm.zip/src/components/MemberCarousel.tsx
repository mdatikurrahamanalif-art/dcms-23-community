import React, { useState } from 'react';
import { Users, ArrowRight, Pause, Play, UserPlus } from 'lucide-react';
import { Batchmate } from '../types';

interface MemberCarouselProps {
  batchmates: Batchmate[];
  onSelectMember: (batchmate: Batchmate) => void;
  onViewAll: () => void;
  isLightMode: boolean;
  onOpenJoinModal?: () => void;
}

export const MemberCarousel: React.FC<MemberCarouselProps> = ({
  batchmates,
  onSelectMember,
  onViewAll,
  isLightMode,
  onOpenJoinModal,
}) => {
  const [isPaused, setIsPaused] = useState(false);

  // If there are no batchmates yet
  if (batchmates.length === 0) {
    return (
      <section className="py-10 relative overflow-hidden border-y border-amber-500/10 bg-slate-950/40">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-semibold mb-3">
            <Users className="w-3.5 h-3.5" />
            <span>ব্যাচমেট স্পটলাইট • Batch Spotlight</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold gradient-text mb-2">
            সহপাঠীদের তালিকা
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 font-['Hind_Siliguri'] mb-2 max-w-lg mx-auto">
            আপনারা যারা ধনবাড়ী কলেজিয়েট মডেল স্কুল ব্যাচ ২৩ এর শিক্ষার্থী, আইডি রেজিস্টার করলেই আপনার প্রোফাইল স্বয়ংক্রিয়ভাবে এখানে প্রদর্শিত হবে।
          </p>
        </div>
      </section>
    );
  }

  // Duplicate list appropriately to achieve continuous smooth looping
  const multiplier = batchmates.length < 5 ? 4 : 2;
  const items = Array(multiplier).fill(batchmates).flat();

  return (
    <section className="py-12 relative overflow-hidden border-y border-amber-500/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Community Spotlight
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold gradient-text">
            Meet Our DCMS Batch '23 Family
          </h2>
        </div>

        <div className="flex items-center gap-3">
          {/* Pause / Play Button */}
          <button
            onClick={() => setIsPaused(!isPaused)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition-all flex items-center gap-1.5 cursor-pointer ${
              isPaused
                ? 'bg-amber-400 text-slate-950 border-amber-400 shadow-md'
                : 'border-slate-700 bg-slate-900/80 text-slate-300 hover:border-amber-400 hover:text-amber-300'
            }`}
            title={isPaused ? 'Resume scrolling' : 'Pause scrolling'}
          >
            {isPaused ? <Play className="w-3.5 h-3.5 fill-current" /> : <Pause className="w-3.5 h-3.5" />}
            <span>{isPaused ? 'চালান (Resume)' : 'থামান (Pause)'}</span>
          </button>

          <button
            onClick={onViewAll}
            className="text-xs sm:text-sm font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1 group cursor-pointer"
          >
            <span>সকল ব্যাচমেট দেখুন</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>

      {/* Infinite marquee track container with fade edges */}
      <div className="relative w-full overflow-hidden">
        {/* Left and right edge gradient masks */}
        <div className={`absolute top-0 bottom-0 left-0 w-16 sm:w-28 z-10 pointer-events-none bg-gradient-to-r ${
          isLightMode ? 'from-slate-100 to-transparent' : 'from-[#020617] to-transparent'
        }`} />
        <div className={`absolute top-0 bottom-0 right-0 w-16 sm:w-28 z-10 pointer-events-none bg-gradient-to-l ${
          isLightMode ? 'from-slate-100 to-transparent' : 'from-[#020617] to-transparent'
        }`} />

        <div className={`animate-marquee hover:[animation-play-state:paused] py-2 ${isPaused ? 'is-paused' : ''}`}>
          {items.map((b, idx) => (
            <div
              key={`${b.id}-${idx}`}
              onClick={() => onSelectMember(b)}
              className={`flex-shrink-0 w-52 sm:w-60 mx-2 sm:mx-3 p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer group hover:scale-[1.03] ${
                isLightMode
                  ? 'bg-white/90 border-amber-200/80 shadow-md hover:border-amber-400'
                  : 'bg-slate-900/70 border-amber-500/20 shadow-lg shadow-black/40 hover:border-amber-400 hover:shadow-amber-500/10'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-12 h-12 rounded-full overflow-hidden p-0.5 bg-gradient-to-tr from-amber-400 to-amber-600 shadow-md">
                    <img
                      src={b.photoUrl}
                      alt={b.name}
                      className="w-full h-full object-cover rounded-full group-hover:scale-105 transition-transform"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(b.name)}&background=0f172a&color=fbbf24`;
                      }}
                    />
                  </div>
                  {b.blood && (
                    <span className="absolute -bottom-1 -right-1 text-[9px] font-bold px-1 py-0.2 rounded-full bg-rose-600 text-white leading-none">
                      {b.blood}
                    </span>
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <h4 className="text-xs sm:text-sm font-bold text-slate-100 group-hover:text-amber-400 transition-colors truncate">
                    {b.name}
                  </h4>
                  <p className="text-[11px] text-slate-400 truncate">
                    {b.currentStatus || `${b.group} Group`}
                  </p>
                  <span className="inline-block text-[10px] text-amber-400/90 font-medium">
                    {b.address.split(',')[0]}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
