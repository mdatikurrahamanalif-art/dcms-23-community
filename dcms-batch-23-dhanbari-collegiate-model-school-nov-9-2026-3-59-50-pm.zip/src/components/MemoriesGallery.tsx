import React, { useState, useRef } from 'react';
import { 
  Image as ImageIcon, 
  Film, 
  Eye, 
  X, 
  Sparkles, 
  Calendar, 
  Download, 
  Share2,
  ChevronLeft,
  ChevronRight,
  Upload,
  Plus,
  CheckCircle2,
  Trash2
} from 'lucide-react';
import { GalleryItem } from '../types';
import { compressImageFile } from '../utils/imageUpload';

interface MemoriesGalleryProps {
  galleryItems: GalleryItem[];
  onAddGalleryItem?: (item: GalleryItem) => void;
  onDeleteGalleryItem?: (id: string) => void;
  isLightMode: boolean;
}

export const MemoriesGallery: React.FC<MemoriesGalleryProps> = ({ 
  galleryItems, 
  onAddGalleryItem,
  onDeleteGalleryItem,
  isLightMode 
}) => {
  const [selectedEvent, setSelectedEvent] = useState<string>('ALL');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [itemToDelete, setItemToDelete] = useState<GalleryItem | null>(null);

  // Upload modal state
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [uploadPreview, setUploadPreview] = useState<string | null>(null);
  const [uploadCaption, setUploadCaption] = useState('');
  const [uploadEvent, setUploadEvent] = useState("Farewell & Rag Day '23");
  const [customEvent, setCustomEvent] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Extract unique events
  const events = ['ALL', ...Array.from(new Set(galleryItems.map((g) => g.eventName)))];

  const filteredItems = galleryItems.filter(
    (item) => selectedEvent === 'ALL' || item.eventName === selectedEvent
  );

  const activeLightboxItem = lightboxIndex !== null ? filteredItems[lightboxIndex] : null;

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex !== null && lightboxIndex > 0) {
      setLightboxIndex(lightboxIndex - 1);
    } else if (lightboxIndex === 0) {
      setLightboxIndex(filteredItems.length - 1);
    }
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex !== null && lightboxIndex < filteredItems.length - 1) {
      setLightboxIndex(lightboxIndex + 1);
    } else {
      setLightboxIndex(0);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsProcessing(true);
      const compressedDataUrl = await compressImageFile(file, 1400, 0.85);
      setUploadPreview(compressedDataUrl);
    } catch (err: any) {
      alert(`ছবি লোড করতে সমস্যা হয়েছে: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadPreview) {
      alert('দয়া করে ফোন বা ডিভাইস গ্যালারি থেকে একটি ছবি নির্বাচন করুন।');
      return;
    }

    const eventNameToUse = uploadEvent === 'create_new' ? (customEvent.trim() || 'General Memories') : uploadEvent;

    const newItem: GalleryItem = {
      id: `gallery-upload-${Date.now()}`,
      url: uploadPreview,
      caption: uploadCaption.trim() || undefined,
      type: 'photo',
      eventName: eventNameToUse,
      timestamp: Date.now(),
    };

    if (onAddGalleryItem) {
      onAddGalleryItem(newItem);
    }

    setUploadPreview(null);
    setUploadCaption('');
    setCustomEvent('');
    setIsUploadOpen(false);
    alert('ছবিটি সফলভাবে স্মৃতি অ্যালবামে আপলোড করা হয়েছে!');
  };

  return (
    <section id="gallery" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-6 mb-10">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-semibold mb-3">
            <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
            <span>Photo Memories • স্মৃতির অ্যালবাম</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold gradient-text mb-2">
            DCMS '23 Memory Vault
          </h2>
          <p className="text-sm sm:text-base text-slate-400 font-['Hind_Siliguri']">
            বিদায় সংবর্ধনা, রাগ ডে, বার্ষিক ক্রীড়া প্রতিযোগিতা ও ক্যাম্পাসের অমূল্য মুহূর্তগুলো।
          </p>
        </div>

        {/* Direct Upload button */}
        {onAddGalleryItem && (
          <button
            onClick={() => setIsUploadOpen(true)}
            className="btn-gold px-5 py-3 text-xs sm:text-sm font-bold flex items-center gap-2 flex-shrink-0 cursor-pointer shadow-lg shadow-amber-400/20"
          >
            <Upload className="w-4 h-4 text-slate-950" />
            <span>গ্যালারি থেকে ছবি আপলোড করুন</span>
          </button>
        )}
      </div>

      {/* Event Tabs */}
      <div className="flex flex-wrap items-center gap-2 mb-8">
        {events.map((ev) => (
          <button
            key={ev}
            onClick={() => setSelectedEvent(ev)}
            className={`px-4 py-2 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
              selectedEvent === ev
                ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                : isLightMode
                ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-amber-400'
            }`}
          >
            {ev === 'ALL' ? 'All Memories (সকল ছবি)' : ev}
          </button>
        ))}
      </div>

      {/* Gallery Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map((item, index) => (
          <div
            key={item.id}
            onClick={() => setLightboxIndex(index)}
            className={`group rounded-3xl overflow-hidden border cursor-pointer relative transition-all duration-300 hover:scale-[1.02] ${
              isLightMode
                ? 'bg-white border-amber-200 shadow-md hover:border-amber-400'
                : 'bg-slate-900 border-slate-800 shadow-xl hover:border-amber-400/60'
            }`}
          >
            <div className="relative aspect-[4/3] overflow-hidden bg-slate-950">
              <img
                src={item.url}
                alt={item.caption || 'DCMS Batch 23 memory'}
                className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=800&auto=format&fit=crop&q=80';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-60 group-hover:opacity-80 transition-opacity"></div>

              {/* Event Badge */}
              <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-950/70 text-amber-300 backdrop-blur-md border border-amber-400/30">
                {item.eventName}
              </span>

              {/* Direct Delete button on card */}
              {onDeleteGalleryItem && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setItemToDelete(item);
                  }}
                  className="absolute top-3 right-3 p-2 rounded-full bg-slate-950/80 hover:bg-rose-600 text-rose-400 hover:text-white border border-rose-500/40 backdrop-blur-md transition-all cursor-pointer z-10 shadow-md"
                  title="ছবি মুছুন"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}

              {/* Hover overlay icon */}
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="w-12 h-12 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center shadow-lg shadow-amber-400/40">
                  <Eye className="w-6 h-6" />
                </div>
              </div>
            </div>

            {/* Caption */}
            {item.caption && (
              <div className="p-4">
                <p className="text-xs font-semibold text-slate-200 line-clamp-2 font-['Hind_Siliguri']">
                  {item.caption}
                </p>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Lightbox Modal */}
      {activeLightboxItem && (
        <div 
          onClick={() => setLightboxIndex(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-xl animate-fade-in"
        >
          <div 
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-5xl w-full flex flex-col items-center"
          >
            {/* Close Button */}
            <button
              onClick={() => setLightboxIndex(null)}
              className="absolute -top-12 right-0 p-2 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-8 h-8" />
            </button>

            {/* Prev & Next navigation buttons */}
            <button
              onClick={handlePrev}
              className="absolute left-2 sm:-left-14 top-1/2 -translate-y-1/2 p-3 rounded-full bg-slate-900/80 text-amber-400 border border-amber-400/30 hover:bg-amber-400 hover:text-slate-950 transition-all z-10 cursor-pointer"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              onClick={handleNext}
              className="absolute right-2 sm:-right-14 top-1/2 -translate-y-1/2 p-3 rounded-full bg-slate-900/80 text-amber-400 border border-amber-400/30 hover:bg-amber-400 hover:text-slate-950 transition-all z-10 cursor-pointer"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Image display */}
            <div className="rounded-3xl overflow-hidden border border-amber-500/30 max-h-[75vh] bg-slate-950 shadow-2xl">
              <img
                src={activeLightboxItem.url}
                alt={activeLightboxItem.caption || 'DCMS Batch 23 memory'}
                className="max-h-[75vh] w-auto max-w-full object-contain mx-auto"
              />
            </div>

            {/* Caption & Controls */}
            <div className="mt-4 text-center px-4 flex flex-col items-center">
              <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30 mb-2">
                {activeLightboxItem.eventName}
              </span>
              {activeLightboxItem.caption && (
                <p className="text-sm sm:text-base text-slate-100 font-medium font-['Hind_Siliguri'] mb-2">
                  {activeLightboxItem.caption}
                </p>
              )}

              {/* Lightbox Delete Button */}
              {onDeleteGalleryItem && (
                <button
                  type="button"
                  onClick={() => setItemToDelete(activeLightboxItem)}
                  className="mt-2 px-4 py-2 rounded-xl text-xs font-bold bg-rose-600/90 hover:bg-rose-500 text-white flex items-center gap-1.5 transition-colors cursor-pointer shadow-lg shadow-rose-950/50"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>গ্যালারি থেকে ছবিটি মুছে ফেলুন (Delete Photo)</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Delete Gallery Item Confirmation Modal */}
      {itemToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
          <div className="relative w-full max-w-sm rounded-3xl p-6 bg-slate-900 border border-rose-500/40 text-slate-100 shadow-2xl">
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center mb-3">
              <Trash2 className="w-5 h-5" />
            </div>
            <h4 className="text-base font-bold text-white mb-1">
              ছবিটি মুছে ফেলতে চান?
            </h4>
            <p className="text-xs text-slate-300 mb-4 font-['Hind_Siliguri']">
              আপনি কি নিশ্চিত যে এই ছবিটি স্মৃতি অ্যালবাম থেকে চিরতরে মুছে ফেলতে চান?
            </p>
            <div className="flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setItemToDelete(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                onClick={() => {
                  const targetId = itemToDelete.id;
                  onDeleteGalleryItem?.(targetId);
                  setItemToDelete(null);
                  setLightboxIndex(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white flex items-center gap-1.5 cursor-pointer shadow-lg shadow-rose-600/30"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>হ্যাঁ, মুছে ফেলুন</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upload Photo Modal */}
      {isUploadOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
          <div className={`relative w-full max-w-lg rounded-3xl p-6 sm:p-8 border shadow-2xl ${
            isLightMode
              ? 'bg-white border-amber-300 text-slate-800'
              : 'bg-slate-900 border-amber-500/40 text-slate-100'
          }`}>
            <button
              onClick={() => {
                setIsUploadOpen(false);
                setUploadPreview(null);
              }}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
                <Upload className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold gradient-text">
                  ডিভাইস গ্যালারি থেকে ছবি আপলোড
                </h3>
                <p className="text-xs text-slate-400 font-['Hind_Siliguri']">
                  আপনার মোবাইল বা কম্পিউটারের গ্যালারি থেকে ছবি নির্বাচন করুন
                </p>
              </div>
            </div>

            <form onSubmit={handleUploadSubmit} className="space-y-4">
              {/* File picker drop area */}
              <div 
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-2xl p-5 text-center cursor-pointer transition-all ${
                  uploadPreview
                    ? 'border-emerald-500/60 bg-emerald-500/5'
                    : 'border-amber-400/40 hover:border-amber-400 bg-slate-950/50'
                }`}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                />

                {uploadPreview ? (
                  <div className="flex flex-col items-center">
                    <img
                      src={uploadPreview}
                      alt="Upload Preview"
                      className="w-full max-h-48 object-contain rounded-xl mb-2"
                    />
                    <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>ছবি সফলভাবে লোড হয়েছে (ক্লিক করে পরিবর্তন করুন)</span>
                    </span>
                  </div>
                ) : (
                  <div className="flex flex-col items-center py-4">
                    <Upload className="w-8 h-8 text-amber-400 mb-2 animate-bounce" />
                    <span className="text-xs font-bold text-slate-200">
                      {isProcessing ? 'ছবি প্রসেস হচ্ছে...' : 'ছবি সিলেক্ট করতে এখানে ক্লিক করুন'}
                    </span>
                    <span className="text-[11px] text-slate-400 mt-1">
                      মোবাইলের গ্যালারি বা ফোল্ডার থেকে JPG, PNG ইত্যাদি নির্বাচন করুন
                    </span>
                  </div>
                )}
              </div>

              {/* Event Album selector */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  ইভেন্ট / অ্যালবাম নির্বাচন করুন *
                </label>
                <select
                  value={uploadEvent}
                  onChange={(e) => setUploadEvent(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                >
                  <option value="Farewell & Rag Day '23">Farewell & Rag Day '23</option>
                  <option value="SSC Examination 2023">SSC Examination 2023</option>
                  <option value="Annual Sports & Cultural Week">Annual Sports & Cultural Week</option>
                  <option value="Classroom & Campus Life">Classroom & Campus Life</option>
                  <option value="Annual Tour 2023">Annual Tour 2023</option>
                  <option value="create_new">+ নতুন ইভেন্টের নাম লিখুন...</option>
                </select>

                {uploadEvent === 'create_new' && (
                  <input
                    type="text"
                    required
                    value={customEvent}
                    onChange={(e) => setCustomEvent(e.target.value)}
                    placeholder="নতুন অ্যালবামের নাম লিখুন (যেমন: Reunion 2026)"
                    className="w-full mt-2 px-3.5 py-2 rounded-xl text-xs bg-slate-950 border border-amber-400/50 text-white focus:outline-none"
                  />
                )}
              </div>

              {/* Caption */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  ক্যাপশন (ঐচ্ছিক)
                </label>
                <input
                  type="text"
                  value={uploadCaption}
                  onChange={(e) => setUploadCaption(e.target.value)}
                  placeholder="ছবির বিশেষ কোনো স্মৃতি বা বন্ধুদের নাম লিখুন..."
                  className="w-full px-3.5 py-2.5 rounded-xl text-xs bg-slate-950 border border-slate-800 text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                />
              </div>

              <button
                type="submit"
                disabled={!uploadPreview || isProcessing}
                className="btn-gold w-full py-3 text-xs font-bold shadow-md cursor-pointer disabled:opacity-50"
              >
                {isProcessing ? 'প্রসেস হচ্ছে...' : 'অ্যালবামে যুক্ত করুন (Upload Photo)'}
              </button>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
