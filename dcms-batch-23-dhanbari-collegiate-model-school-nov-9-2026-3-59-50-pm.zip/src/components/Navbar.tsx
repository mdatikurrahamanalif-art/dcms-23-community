import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Award, 
  Image as ImageIcon, 
  BookOpen, 
  Heart, 
  Calendar, 
  ShieldCheck, 
  Sun, 
  Moon, 
  Menu, 
  X,
  GraduationCap,
  Share2,
  LogOut,
  User
} from 'lucide-react';
import { Batchmate } from '../types';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  isLightMode: boolean;
  toggleTheme: () => void;
  onOpenShare?: () => void;
  currentUser?: Batchmate | null;
  onLogout?: () => void;
  onOpenEditProfile?: (batchmate: Batchmate) => void;
  onOpenLoginGate?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  isLightMode,
  toggleTheme,
  onOpenShare,
  currentUser,
  onLogout,
  onOpenEditProfile,
  onOpenLoginGate,
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'home', label: 'Home', bangla: 'হোম', icon: GraduationCap },
    { id: 'directory', label: 'Directory', bangla: 'ব্যাচমেট', icon: Users },
    { id: 'fame', label: 'Hall of Fame', bangla: 'কৃতিত্ব', icon: Award },
    { id: 'gallery', label: 'Gallery', bangla: 'গ্যালারি', icon: ImageIcon },
    { id: 'stories', label: 'Stories', bangla: 'স্মৃতিচারণ', icon: BookOpen },
    { id: 'blood', label: 'Blood Bank', bangla: 'রক্তদান', icon: Heart },
    { id: 'reunion', label: 'Reunion', bangla: 'রিইউনিয়ন', icon: Calendar },
    { id: 'admin', label: 'Admin', bangla: 'অ্যাডমিন', icon: ShieldCheck },
  ];

  const handleNavClick = (id: string) => {
    setCurrentTab(id);
    setMobileMenuOpen(false);
    
    // If on home page and clicking a section on home page
    const elem = document.getElementById(id);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? isLightMode
            ? 'bg-white/90 backdrop-blur-md shadow-md border-b border-amber-200'
            : 'bg-slate-950/85 backdrop-blur-md shadow-xl border-b border-amber-500/20'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo / Crest */}
          <div 
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative w-12 h-12 rounded-full p-0.5 bg-gradient-to-tr from-amber-400 via-amber-200 to-amber-600 shadow-lg shadow-amber-500/20 group-hover:scale-105 transition-transform">
              <div className="w-full h-full rounded-full bg-slate-950 flex flex-col items-center justify-center text-center p-1">
                <span className="text-[10px] font-black text-amber-400 tracking-tighter leading-none">DCMS</span>
                <span className="text-[14px] font-black bg-gradient-to-r from-amber-300 to-amber-500 bg-clip-text text-transparent leading-tight">'23</span>
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold tracking-tight gradient-text">
                DCMS BATCH '23
              </span>
              <span className={`text-[11px] font-medium tracking-wide ${isLightMode ? 'text-slate-600' : 'text-slate-400'}`}>
                ধনবাড়ী কলেজিয়েট মডেল স্কুল
              </span>
            </div>
          </div>

          {/* Desktop Nav Links */}
          <div className="hidden lg:flex items-center space-x-1">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = currentTab === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-semibold transition-all duration-200 ${
                    isActive
                      ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                      : isLightMode
                      ? 'text-slate-700 hover:text-amber-600 hover:bg-amber-50'
                      : 'text-slate-300 hover:text-amber-300 hover:bg-slate-900/60'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-slate-950' : 'text-amber-400'}`} />
                  <span>{link.label}</span>
                  <span className="text-[10px] opacity-75">({link.bangla})</span>
                </button>
              );
            })}

            {/* Share Website Button, Member Badge, & Theme Toggle */}
            <div className="pl-2 border-l border-amber-500/30 flex items-center gap-2">
              {currentUser ? (
                <div className="flex items-center gap-2 px-2.5 py-1 rounded-full bg-amber-400/15 border border-amber-400/40 text-xs">
                  <button
                    onClick={() => onOpenEditProfile?.(currentUser)}
                    title="আমার প্রোফাইল এডিট করুন"
                    className="flex items-center gap-2 text-left cursor-pointer group"
                  >
                    <img
                      src={currentUser.photoUrl}
                      alt={currentUser.name}
                      className="w-5 h-5 rounded-full object-cover border border-amber-400 shrink-0 group-hover:ring-1 group-hover:ring-amber-300 transition-all"
                    />
                    <div className="flex flex-col text-left">
                      <span className="font-bold text-amber-300 group-hover:text-amber-200 max-w-[90px] truncate leading-none">
                        {currentUser.name.split(' ')[0]}
                      </span>
                      {currentUser.rollNumber && (
                        <span className="text-[9px] text-amber-400/90 font-mono leading-none mt-0.5">
                          রোল: #{currentUser.rollNumber}
                        </span>
                      )}
                    </div>
                  </button>
                  {onLogout && (
                    <button
                      onClick={onLogout}
                      title="আইডি লগআউট করুন"
                      className="p-1 rounded-full text-slate-400 hover:text-rose-400 hover:bg-rose-500/20 transition-colors cursor-pointer ml-1"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ) : (
                onOpenLoginGate && (
                  <button
                    onClick={onOpenLoginGate}
                    className="px-3 py-1.5 rounded-full text-xs font-bold bg-amber-400/20 hover:bg-amber-400 text-amber-300 hover:text-slate-950 border border-amber-400/40 flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
                  >
                    <User className="w-3.5 h-3.5" />
                    <span>লগইন / আইডি খুলুন</span>
                  </button>
                )
              )}

              {onOpenShare && (
                <button
                  onClick={onOpenShare}
                  title="শেয়ার বা পাবলিক লিঙ্ক"
                  className="px-3 py-1.5 rounded-full text-xs font-bold bg-amber-400 text-slate-950 hover:bg-amber-300 shadow-md shadow-amber-400/20 flex items-center gap-1.5 cursor-pointer transition-transform hover:scale-105"
                >
                  <Share2 className="w-3.5 h-3.5 text-slate-950" />
                  <span>শেয়ার</span>
                </button>
              )}

              <button
                onClick={toggleTheme}
                title={isLightMode ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
                className={`p-2.5 rounded-full transition-all duration-300 cursor-pointer ${
                  isLightMode
                    ? 'bg-amber-100 text-amber-800 hover:bg-amber-200'
                    : 'bg-slate-800 text-amber-300 hover:bg-slate-700'
                }`}
              >
                {isLightMode ? (
                  <Moon className="w-4 h-4 text-slate-800" />
                ) : (
                  <Sun className="w-4 h-4 text-amber-300" />
                )}
              </button>
            </div>
          </div>

          {/* Mobile Right Controls */}
          <div className="flex items-center lg:hidden gap-1.5">
            {onOpenShare && (
              <button
                onClick={onOpenShare}
                className="px-2.5 py-1.5 rounded-full text-xs font-bold bg-amber-400 text-slate-950 hover:bg-amber-300 flex items-center gap-1 cursor-pointer shadow-md"
              >
                <Share2 className="w-3 h-3 text-slate-950" />
                <span>শেয়ার</span>
              </button>
            )}
            <button
              onClick={toggleTheme}
              className={`p-2 rounded-full cursor-pointer ${
                isLightMode ? 'bg-amber-100 text-amber-800' : 'bg-slate-800 text-amber-300'
              }`}
            >
              {isLightMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`p-2 rounded-lg cursor-pointer ${
                isLightMode ? 'text-slate-800 hover:bg-slate-100' : 'text-slate-200 hover:bg-slate-800'
              }`}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className={`lg:hidden border-b px-4 pt-2 pb-6 space-y-1 transition-all ${
          isLightMode
            ? 'bg-white/95 backdrop-blur-xl border-amber-200 shadow-xl'
            : 'bg-slate-950/95 backdrop-blur-xl border-amber-500/20 shadow-2xl'
        }`}>
          {!currentUser && onOpenLoginGate && (
            <div className="p-3 mb-3 rounded-2xl bg-amber-400/15 border border-amber-400/40 flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold text-amber-300">ব্যাচ '২৩ মেম্বার?</h4>
                <p className="text-[11px] text-slate-400">লগইন করুন বা নতুন আইডি খুলুন</p>
              </div>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenLoginGate();
                }}
                className="px-3 py-1.5 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow"
              >
                <User className="w-3.5 h-3.5" />
                <span>লগইন / আইডি খুলুন</span>
              </button>
            </div>
          )}

          {currentUser && (
            <div className="p-3 mb-3 rounded-2xl bg-amber-400/15 border border-amber-400/40 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <img
                  src={currentUser.photoUrl}
                  alt={currentUser.name}
                  className="w-10 h-10 rounded-full object-cover border-2 border-amber-400 shrink-0"
                />
                <div>
                  <h4 className="text-sm font-bold text-amber-300">{currentUser.name}</h4>
                  <p className="text-[11px] text-slate-400">
                    {currentUser.rollNumber ? `রোল: #${currentUser.rollNumber} • ` : ''}{currentUser.group}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {onOpenEditProfile && (
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      onOpenEditProfile(currentUser);
                    }}
                    className="px-2.5 py-1.5 rounded-lg bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1 cursor-pointer shadow"
                  >
                    <span>এডিট</span>
                  </button>
                )}
                {onLogout && (
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      onLogout();
                    }}
                    className="px-2.5 py-1.5 rounded-lg bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>লগআউট</span>
                  </button>
                )}
              </div>
            </div>
          )}
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive = currentTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm font-semibold ${
                  isActive
                    ? 'bg-amber-400 text-slate-950 shadow-md'
                    : isLightMode
                    ? 'text-slate-700 hover:bg-amber-50'
                    : 'text-slate-200 hover:bg-slate-900'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-slate-950' : 'text-amber-400'}`} />
                  <span>{link.label}</span>
                </div>
                <span className="text-xs opacity-75">{link.bangla}</span>
              </button>
            );
          })}
        </div>
      )}
    </nav>
  );
};
