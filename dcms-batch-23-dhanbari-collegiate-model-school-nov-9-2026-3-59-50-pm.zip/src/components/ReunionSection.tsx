import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  Sparkles, 
  Shirt, 
  Users, 
  Ticket,
  Utensils,
  Music,
  Camera
} from 'lucide-react';
import { ReunionRegistration, ReunionSettings } from '../types';

interface ReunionSectionProps {
  registrations: ReunionRegistration[];
  settings: ReunionSettings;
  onRegister: (reg: Omit<ReunionRegistration, 'id' | 'timestamp' | 'confirmed'>) => void;
  isLightMode: boolean;
}

export const ReunionSection: React.FC<ReunionSectionProps> = ({
  registrations,
  settings,
  onRegister,
  isLightMode,
}) => {
  // Reunion target date from dynamic settings
  const targetDate = new Date(settings.targetDate).getTime() || new Date('December 25, 2026 10:00:00').getTime();

  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date().getTime();
      const diff = Math.max(0, targetDate - now);

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds });
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [targetDate]);

  // Form State
  const [name, setName] = useState('');
  const [group, setGroup] = useState('Science');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [tshirtSize, setTshirtSize] = useState<'S' | 'M' | 'L' | 'XL' | 'XXL'>('L');
  const [guestCount, setGuestCount] = useState<number>(0);
  const [notes, setNotes] = useState('');
  const [promoCode, setPromoCode] = useState('');
  const [promoApplied, setPromoApplied] = useState(false);
  const [promoError, setPromoError] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const handleApplyPromo = () => {
    if (promoCode.trim().toUpperCase() === 'DCMS-23') {
      setPromoApplied(true);
      setPromoError('');
    } else {
      setPromoApplied(false);
      setPromoError('অকার্যকর কোড! সঠিক প্রমো কোড "DCMS-23" লিখুন।');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !address.trim()) return;

    const finalNotes = promoApplied 
      ? `[প্রমো কোড: DCMS-23 প্রযোজিত - VIP অ্যাক্সেস] ${notes.trim()}`.trim()
      : notes.trim();

    onRegister({
      name: name.trim(),
      group,
      phone: phone.trim(),
      email: email.trim(),
      address: address.trim(),
      tshirtSize,
      guestCount: Number(guestCount),
      notes: finalNotes,
    });

    setIsSuccess(true);
    setName('');
    setPhone('');
    setEmail('');
    setAddress('');
    setNotes('');
  };

  return (
    <section id="reunion" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-semibold mb-3">
          <Calendar className="w-3.5 h-3.5" />
          <span>Grand Reunion 2026 • মহা মিলনমেলা</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold gradient-text mb-3">
          DCMS Batch '23 Grand Reunion
        </h2>
        <p className="text-sm sm:text-base text-slate-400 font-['Hind_Siliguri']">
          "{settings.tagline || 'স্মৃতির টানে, প্রাণের মেলায়, আবার ফিরি প্রিয় প্রাঙ্গণে...'}"
        </p>
      </div>

      {/* Countdown Clock Banner */}
      <div className={`p-6 sm:p-10 rounded-3xl border shadow-2xl mb-12 relative overflow-hidden text-center ${
        isLightMode
          ? 'bg-gradient-to-b from-amber-50 to-white border-amber-300'
          : 'bg-gradient-to-b from-slate-900 to-slate-950 border-amber-500/30'
      }`}>
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-2 text-xs font-bold uppercase tracking-widest text-amber-400 mb-6">
          <Clock className="w-4 h-4" />
          <span>{settings.displayDateText || 'December 25, 2026 • 10:00 AM onwards'}</span>
          <span className="hidden sm:inline">•</span>
          <span className="flex items-center gap-1 font-['Hind_Siliguri']">
            <MapPin className="w-3.5 h-3.5" />
            {settings.venue || 'ধনবাড়ী নওয়াব প্যালেস ও স্কুল অডিটোরিয়াম'}
          </span>
        </div>

        {/* 4 Clock Boxes */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-2xl mx-auto mb-6">
          <div className="glass p-4 sm:p-6 rounded-2xl border border-amber-500/30 flex flex-col items-center">
            <span className="text-3xl sm:text-5xl font-black text-amber-400 font-mono">
              {String(timeLeft.days).padStart(2, '0')}
            </span>
            <span className="text-xs uppercase tracking-wider font-semibold text-slate-400 mt-2">Days</span>
          </div>

          <div className="glass p-4 sm:p-6 rounded-2xl border border-amber-500/30 flex flex-col items-center">
            <span className="text-3xl sm:text-5xl font-black text-amber-400 font-mono">
              {String(timeLeft.hours).padStart(2, '0')}
            </span>
            <span className="text-xs uppercase tracking-wider font-semibold text-slate-400 mt-2">Hours</span>
          </div>

          <div className="glass p-4 sm:p-6 rounded-2xl border border-amber-500/30 flex flex-col items-center">
            <span className="text-3xl sm:text-5xl font-black text-amber-400 font-mono">
              {String(timeLeft.minutes).padStart(2, '0')}
            </span>
            <span className="text-xs uppercase tracking-wider font-semibold text-slate-400 mt-2">Minutes</span>
          </div>

          <div className="glass p-4 sm:p-6 rounded-2xl border border-amber-500/30 flex flex-col items-center">
            <span className="text-3xl sm:text-5xl font-black text-amber-400 font-mono">
              {String(timeLeft.seconds).padStart(2, '0')}
            </span>
            <span className="text-xs uppercase tracking-wider font-semibold text-slate-400 mt-2">Seconds</span>
          </div>
        </div>

        {/* Program Highlights */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-3xl mx-auto pt-4 border-t border-slate-800/80">
          <div className="flex items-center justify-center gap-2 text-xs text-slate-300">
            <Shirt className="w-4 h-4 text-amber-400" />
            <span>Custom T-Shirt & Crest</span>
          </div>
          <div className="flex items-center justify-center gap-2 text-xs text-slate-300">
            <Utensils className="w-4 h-4 text-amber-400" />
            <span>Grand Buffet Feast</span>
          </div>
          <div className="flex items-center justify-center gap-2 text-xs text-slate-300">
            <Music className="w-4 h-4 text-amber-400" />
            <span>Cultural & Band Show</span>
          </div>
          <div className="flex items-center justify-center gap-2 text-xs text-slate-300">
            <Camera className="w-4 h-4 text-amber-400" />
            <span>Batch Photo Session</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Registration Form & Registered Batchmates */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Registration Form */}
        <div className={`lg:col-span-7 rounded-3xl p-6 sm:p-8 border shadow-xl ${
          isLightMode ? 'bg-white border-amber-200' : 'bg-slate-900/80 border-amber-500/20'
        }`}>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shadow-md">
              <Ticket className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold gradient-text">
                Reunion Registration Form
              </h3>
              <p className="text-xs text-slate-400 font-['Hind_Siliguri']">
                রিইউনিয়নে অংশ নিতে নিচের ফর্মটি পূরণ করে আসন নিশ্চিত করুন।
              </p>
            </div>
          </div>

          {isSuccess ? (
            <div className="p-8 text-center flex flex-col items-center">
              <CheckCircle2 className="w-16 h-16 text-emerald-400 mb-3 animate-bounce" />
              <h4 className="text-xl font-black text-slate-100">রেজিস্ট্রেশন সফল হয়েছে!</h4>
              <p className="text-xs text-slate-400 mt-2 font-['Hind_Siliguri'] max-w-md">
                অভিনন্দন! ডিসিএমএস ব্যাচ ২৩ এর গ্র্যান্ড রিইউনিয়নে আপনার আসন সংরক্ষিত হয়েছে। আপনার সাথে দ্রুতই যোগাযোগ করা হবে।
              </p>
              <button
                onClick={() => setIsSuccess(false)}
                className="mt-6 px-6 py-2.5 rounded-full text-xs font-bold bg-amber-400 text-slate-950 cursor-pointer"
              >
                আরেকটি রেজিস্ট্রেশন করুন
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Full Name / পূর্ণ নাম *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Tanvir Ahmed Shanto"
                  className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                    isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                  }`}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Group / বিভাগ *
                  </label>
                  <select
                    value={group}
                    onChange={(e) => setGroup(e.target.value)}
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  >
                    <option value="Science">Science (বিজ্ঞান)</option>
                    <option value="Commerce">Commerce (বাণিজ্য)</option>
                    <option value="Humanities">Humanities (মানবিক)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    T-Shirt Size / টি-শার্টের সাইজ *
                  </label>
                  <select
                    value={tshirtSize}
                    onChange={(e) => setTshirtSize(e.target.value as any)}
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  >
                    <option value="S">S (Chest 36")</option>
                    <option value="M">M (Chest 38")</option>
                    <option value="L">L (Chest 40")</option>
                    <option value="XL">XL (Chest 42")</option>
                    <option value="XXL">XXL (Chest 44")</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Phone Number / ফোন নম্বর *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. 01712-345678"
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Email Address / ইমেইল (ঐচ্ছিক)
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="student@example.com"
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Present Address / বর্তমান ঠিকানা *
                  </label>
                  <input
                    type="text"
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="e.g. Dhanbari, Tangail or Dhaka"
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Guests / অতিথি সংখ্যা
                  </label>
                  <select
                    value={guestCount}
                    onChange={(e) => setGuestCount(Number(e.target.value))}
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                    }`}
                  >
                    <option value={0}>0 (Only me)</option>
                    <option value={1}>1 Guest</option>
                    <option value={2}>2 Guests</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Message / বিশেষ কোনো মতামত
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="রিইউনিয়ন কমিটি বা বন্ধুদের উদ্দেশ্যে কোনো বার্তা..."
                  className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                    isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
                  }`}
                />
              </div>

              {/* Promo Code Input: Secret entry */}
              <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                    <Ticket className="w-3.5 h-3.5 text-amber-400" />
                    <span>প্রমো কোড (Promo Code)</span>
                    <span className="text-[10px] text-slate-500 font-normal">(ঐচ্ছিক)</span>
                  </label>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={promoCode}
                    onChange={(e) => {
                      setPromoCode(e.target.value);
                      if (e.target.value.trim().toUpperCase() === 'DCMS-23') {
                        setPromoApplied(true);
                        setPromoError('');
                      } else {
                        setPromoApplied(false);
                      }
                    }}
                    placeholder="প্রমো কোড থাকলে লিখুন..."
                    className={`flex-1 px-3.5 py-2 rounded-xl text-xs uppercase font-mono tracking-wider border focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                      promoApplied
                        ? 'border-emerald-500 bg-emerald-950/20 text-emerald-300'
                        : isLightMode
                        ? 'bg-white border-slate-300 text-slate-900'
                        : 'bg-slate-950 border-slate-700 text-white'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={handleApplyPromo}
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 cursor-pointer shadow transition-transform active:scale-95"
                  >
                    Apply
                  </button>
                </div>
                {promoApplied && (
                  <p className="text-[11px] font-bold text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    <span>প্রমো কোড কার্যকর হয়েছে! বিশেষ VIP ব্যাচমেট সুবিধা অন্তর্ভুক্ত।</span>
                  </p>
                )}
                {promoError && (
                  <p className="text-[11px] text-rose-400">
                    {promoError}
                  </p>
                )}
              </div>

              <button
                type="submit"
                className="btn-gold w-full py-3 text-sm font-bold shadow-lg shadow-amber-400/20 cursor-pointer"
              >
                Complete Registration (রেজিস্ট্রেশন নিশ্চিত করুন)
              </button>
            </form>
          )}
        </div>

        {/* Recent Registrations Sidebar */}
        <div className={`lg:col-span-5 rounded-3xl p-6 border shadow-xl ${
          isLightMode ? 'bg-white border-amber-200' : 'bg-slate-900/80 border-amber-500/20'
        }`}>
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-bold text-slate-100">
                Registered Batchmates ({registrations.length})
              </h3>
            </div>
            <span className="text-[11px] font-bold text-amber-400">DCMS Batch '23</span>
          </div>

          <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
            {registrations.map((reg) => (
              <div
                key={reg.id}
                className={`p-3 rounded-2xl border flex items-center justify-between gap-3 ${
                  isLightMode
                    ? 'bg-slate-50 border-slate-200'
                    : 'bg-slate-950/50 border-slate-800'
                }`}
              >
                <div className="min-w-0">
                  <h4 className="text-xs font-bold text-slate-200 truncate">{reg.name}</h4>
                  <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                    <span className="text-amber-400 font-semibold">{reg.group}</span>
                    <span>• T-Shirt: {reg.tshirtSize}</span>
                    {reg.guestCount > 0 && <span>• +{reg.guestCount} Guest</span>}
                  </div>
                </div>

                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex-shrink-0">
                  Confirmed
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
