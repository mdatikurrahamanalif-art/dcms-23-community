import React, { useState } from 'react';
import { X, Share2, Copy, Check, MessageCircle, Globe, ExternalLink, QrCode } from 'lucide-react';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  isLightMode: boolean;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose, isLightMode }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  // Use the canonical public shared URL or fallback to current origin
  const sharedUrl = 'https://ais-pre-ytbls4iqmo4cpnatoaint6-365886414821.asia-northeast1.run.app';
  const shareText = "আমাদের ধানবাড়ী কলেজিয়েট মডেল স্কুল ব্যাচ ২৩ (DCMS Batch '23) এর অফিসিয়াল ওয়েবসাইট তৈরি হয়েছে! এখানে সকল ব্যাচমেটের তালিকা, রক্তের গ্রুপ, ক্যাম্পাস স্মৃতি ও রিইউনিয়ন তথ্য রয়েছে। এখনই নিজের নাম যুক্ত করো:";

  const handleCopy = () => {
    navigator.clipboard.writeText(sharedUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "DCMS Batch '23 Website",
          text: shareText,
          url: sharedUrl,
        });
      } catch (e) {
        // user cancelled or share failed
      }
    } else {
      handleCopy();
    }
  };

  const handleWhatsApp = () => {
    const fullMessage = `${shareText}\n${sharedUrl}`;
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(fullMessage)}`, '_blank');
  };

  const handleFacebook = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(sharedUrl)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className={`relative w-full max-w-md rounded-3xl p-6 sm:p-7 border shadow-2xl overflow-hidden ${
        isLightMode ? 'bg-white border-amber-300 text-slate-800' : 'bg-slate-900 border-amber-500/40 text-slate-100'
      }`}>
        {/* Top Gold Trim */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-amber-400 via-amber-300 to-amber-600"></div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4 pt-1">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-600 text-slate-950 flex items-center justify-center shadow-lg shadow-amber-500/30">
            <Share2 className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold gradient-text">
              ওয়েবসাইট শেয়ার বা পাবলিক লিঙ্ক
            </h3>
            <p className="text-xs text-slate-400 font-['Hind_Siliguri']">
              বন্ধুদের সাথে শেয়ার করে সবাইকে যুক্ত হওয়ার আহ্বান জানান
            </p>
          </div>
        </div>

        {/* Public URL Box */}
        <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-amber-400/30 mb-4">
          <label className="block text-[11px] font-bold text-amber-400 mb-1.5 flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5" />
            <span>সরাসরি পাবলিক ও শেয়ারেবল লিঙ্ক (Public Live URL):</span>
          </label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={sharedUrl}
              className="w-full text-xs font-mono bg-slate-900 px-3 py-2 rounded-xl text-slate-200 border border-slate-800 select-all"
            />
            <button
              onClick={handleCopy}
              className="px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center gap-1 transition-colors cursor-pointer flex-shrink-0 shadow-md"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-900" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'কপি হয়েছে!' : 'কপি'}</span>
            </button>
          </div>
        </div>

        {/* Quick Social Share Buttons */}
        <div className="grid grid-cols-2 gap-2.5 mb-5">
          <button
            onClick={handleWhatsApp}
            className="p-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md"
          >
            <MessageCircle className="w-4 h-4" />
            <span>WhatsApp-এ শেয়ার</span>
          </button>

          <button
            onClick={handleFacebook}
            className="p-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md"
          >
            <Share2 className="w-4 h-4" />
            <span>Facebook-এ শেয়ার</span>
          </button>
        </div>

        {/* Mobile Device Share if available */}
        <button
          onClick={handleNativeShare}
          className="w-full py-2.5 rounded-2xl border border-amber-400/40 hover:bg-amber-400/10 text-amber-300 font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer mb-4"
        >
          <Share2 className="w-3.5 h-3.5" />
          <span>মোবাইল শেয়ার অপশন ওপেন করুন (Native Share)</span>
        </button>

        {/* Helpful Info Tip */}
        <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-slate-300 font-['Hind_Siliguri'] leading-relaxed">
          <span className="font-bold text-amber-400">💡 টিপস: </span>
          Google AI Studio এর একদম উপরে ডানপাশেও একটি <strong className="text-white">"Share"</strong> বাটন রয়েছে। এছাড়া ওপরের এই পাবলিক লিঙ্কটি যেকোনো ব্রাউজারে যেকেউ সরাসরি ওপেন করতে পারবে।
        </div>
      </div>
    </div>
  );
};
