import React from 'react';
import { Cake, Sparkles, ChevronRight, Gift } from 'lucide-react';
import { Batchmate } from '../types';

interface UpcomingBirthdaysProps {
  batchmates: Batchmate[];
  onTriggerModal: (batchmates: Batchmate[]) => void;
  isLightMode: boolean;
}

export const UpcomingBirthdays: React.FC<UpcomingBirthdaysProps> = ({
  batchmates,
  onTriggerModal,
  isLightMode,
}) => {
  const today = new Date();
  const currentMonth = today.getMonth() + 1;
  const currentDay = today.getDate();
  const todayStr = `${String(currentMonth).padStart(2, '0')}-${String(currentDay).padStart(2, '0')}`;

  // Find today's birthdays
  const todaysBirthdays = batchmates.filter((b) => b.birthday === todayStr);

  // Find upcoming birthdays in next 30 days
  const upcomingList = batchmates
    .map((b) => {
      if (!b.birthday) return null;
      const parts = b.birthday.split('-');
      if (parts.length !== 2) return null;
      const m = parseInt(parts[0], 10);
      const d = parseInt(parts[1], 10);

      const thisYearBirthday = new Date(today.getFullYear(), m - 1, d);
      let targetDate = thisYearBirthday;

      // If already passed this year, look at next year
      const todayZero = new Date(today.getFullYear(), today.getMonth(), today.getDate());
      if (targetDate.getTime() < todayZero.getTime()) {
        targetDate = new Date(today.getFullYear() + 1, m - 1, d);
      }

      const diffTime = targetDate.getTime() - todayZero.getTime();
      const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

      return {
        ...b,
        diffDays,
        targetDate,
      };
    })
    .filter((item): item is NonNullable<typeof item> => item !== null && item.diffDays >= 0 && item.diffDays <= 35)
    .sort((a, b) => a.diffDays - b.diffDays);

  if (upcomingList.length === 0) return null;

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6 mb-12 relative z-20">
      <div className={`p-4 sm:p-5 rounded-3xl border shadow-xl transition-all ${
        isLightMode
          ? 'bg-amber-50/90 border-amber-300 shadow-amber-900/5'
          : 'bg-slate-900/80 border-amber-500/30 shadow-amber-500/5 backdrop-blur-xl'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 shadow-md shadow-amber-400/20">
              <Cake className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-amber-400">Upcoming Birthdays</h3>
                <span className="text-[11px] font-medium text-slate-400 font-['Hind_Siliguri']">
                  (আসন্ন জন্মদিন)
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Never miss celebrating a batchmate's special day!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {todaysBirthdays.length > 0 ? (
              <button
                onClick={() => onTriggerModal(todaysBirthdays)}
                className="btn-gold px-3.5 py-1.5 text-xs font-bold flex items-center gap-1.5 animate-pulse cursor-pointer"
              >
                <Gift className="w-3.5 h-3.5" />
                <span>আজকের জন্মদিন দেখুন ({todaysBirthdays.length})</span>
              </button>
            ) : (
              <button
                onClick={() => onTriggerModal([upcomingList[0]])}
                className="px-3.5 py-1.5 rounded-full text-xs font-semibold border border-amber-400/40 text-amber-400 hover:bg-amber-400/10 transition-colors flex items-center gap-1 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Simulate Birthday Wish</span>
              </button>
            )}
          </div>
        </div>

        {/* Horizontal scroll cards */}
        <div className="flex items-center gap-3 overflow-x-auto no-scrollbar pb-2 pt-1">
          {upcomingList.slice(0, 8).map((b) => (
            <div
              key={b.id}
              onClick={() => onTriggerModal([b])}
              className={`flex-shrink-0 flex items-center gap-3 px-3.5 py-2.5 rounded-2xl border transition-all cursor-pointer group hover:scale-[1.02] ${
                b.diffDays === 0
                  ? 'bg-amber-500/20 border-amber-400 ring-2 ring-amber-400/40'
                  : isLightMode
                  ? 'bg-white border-amber-200 hover:border-amber-400'
                  : 'bg-slate-950/60 border-slate-800 hover:border-amber-500/50'
              }`}
            >
              <div className="relative">
                <div className="w-10 h-10 rounded-full overflow-hidden p-0.5 bg-gradient-to-tr from-amber-400 to-amber-600">
                  <img
                    src={b.photoUrl}
                    alt={b.name}
                    className="w-full h-full object-cover rounded-full"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(b.name)}&background=0f172a&color=fbbf24`;
                    }}
                  />
                </div>
                {b.diffDays === 0 && (
                  <span className="absolute -top-1 -right-1 text-xs">🎉</span>
                )}
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-200 group-hover:text-amber-400 transition-colors line-clamp-1">
                  {b.name}
                </h4>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className={`text-[10px] font-semibold ${
                    b.diffDays === 0
                      ? 'text-amber-300 font-bold'
                      : b.diffDays === 1
                      ? 'text-amber-400'
                      : 'text-slate-400'
                  }`}>
                    {b.diffDays === 0
                      ? '🎂 TODAY!'
                      : b.diffDays === 1
                      ? 'Tomorrow'
                      : `in ${b.diffDays} days`}
                  </span>
                  <span className="text-[10px] text-slate-500">• {b.group}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
