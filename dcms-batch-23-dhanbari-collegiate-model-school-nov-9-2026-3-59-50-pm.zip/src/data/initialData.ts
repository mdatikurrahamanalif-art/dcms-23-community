import { Batchmate, HallOfFameItem, Story, GalleryItem, ReunionRegistration } from '../types';

export const INITIAL_BATCHMATES: Batchmate[] = [];

export const INITIAL_HALL_OF_FAME: HallOfFameItem[] = [
  {
    id: 'hof-01',
    name: 'Tanvir Ahmed Shanto',
    category: 'Engineering',
    achievement: 'Secured Top Merit Position in BUET Admission Test & National Math Olympiad Finalist',
    photoUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80',
    institution: 'BUET (Computer Science & Engineering)',
    year: '2023-2024',
  },
  {
    id: 'hof-02',
    name: 'Nusrat Jahan Mim',
    category: 'Medical',
    achievement: 'Admitted into Dhaka Medical College with exceptional merit score in National Medical Entrance',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    institution: 'Dhaka Medical College (DMC)',
    year: '2023-2024',
  },
  {
    id: 'hof-03',
    name: 'Ariful Islam Joy',
    category: 'Public University',
    achievement: 'Top 50 Merit position in Dhaka University "C" Unit Admission Examination',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
    institution: 'University of Dhaka (Finance)',
    year: '2023-2024',
  },
  {
    id: 'hof-04',
    name: 'Afsana Rahman Sneha',
    category: 'Medical',
    achievement: 'Government Medical College Merit Achiever & SSC Golden GPA-5.00 in all subjects',
    photoUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80',
    institution: 'Rajshahi Medical College (RMC)',
    year: '2023-2024',
  },
  {
    id: 'hof-05',
    name: 'Shahriar Kabir Niloy',
    category: 'Engineering',
    achievement: 'CKRUET Combined Engineering Entrance Rank Holder & Robotics Enthusiast',
    photoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&auto=format&fit=crop&q=80',
    institution: 'KUET (Electrical & Electronic Engineering)',
    year: '2023-2024',
  },
  {
    id: 'hof-06',
    name: 'Farzana Akter Keya',
    category: 'Leadership',
    achievement: 'National Debate Championship Best Debater (Tangail District) & Dhaka University Admission',
    photoUrl: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&auto=format&fit=crop&q=80',
    institution: 'University of Dhaka (Department of English)',
    year: '2023-2024',
  }
];

export const INITIAL_STORIES: Story[] = [];

export const INITIAL_GALLERY: GalleryItem[] = [
  {
    id: 'gal-campus-01',
    url: '/assets/aistudio/IMG_c0994971-40ad-450c-85db-54079a561c7e_21b59f8d.jpg',
    caption: 'আমাদের প্রিয় ধনবাড়ী কলেজিয়েট মডেল স্কুল ৩ তলা মূল ভবন ও খেলার মাঠ',
    type: 'photo',
    eventName: 'Classroom & Campus Life',
    timestamp: Date.now() - 50000000,
  }
];

export const INITIAL_REUNION_REGISTRATIONS: ReunionRegistration[] = [
  {
    id: 'reg-01',
    name: 'Tanvir Ahmed Shanto',
    group: 'Science',
    phone: '01712-345678',
    email: 'tanvir.shanto23@gmail.com',
    address: 'Dhanbari, Tangail',
    tshirtSize: 'L',
    guestCount: 0,
    notes: 'সব বন্ধুদের সাথে দেখা করার অপেক্ষায় আছি!',
    timestamp: Date.now() - 8000000,
    confirmed: true,
  },
  {
    id: 'reg-02',
    name: 'Nusrat Jahan Mim',
    group: 'Science',
    phone: '01823-456789',
    email: 'nusrat.mim@gmail.com',
    address: 'Dhanbari, Tangail',
    tshirtSize: 'M',
    guestCount: 0,
    notes: 'অপেক্ষার প্রহর শেষ হোক দ্রুত।',
    timestamp: Date.now() - 6000000,
    confirmed: true,
  },
  {
    id: 'reg-03',
    name: 'Ariful Islam Joy',
    group: 'Commerce',
    phone: '01633-889900',
    email: 'arif.joy@gmail.com',
    address: 'Satrapur, Dhanbari',
    tshirtSize: 'XL',
    guestCount: 1,
    notes: 'রিইউনিয়ন জমবে চরম!',
    timestamp: Date.now() - 4000000,
    confirmed: true,
  }
];

export const INITIAL_REUNION_SETTINGS = {
  targetDate: '2026-12-25T10:00',
  displayDateText: 'December 25, 2026 • 10:00 AM onwards',
  venue: 'ধনবাড়ী নওয়াব প্যালেস ও স্কুল অডিটোরিয়াম',
  tagline: 'স্মৃতির টানে, প্রাণের মেলায়, আবার ফিরি প্রিয় প্রাঙ্গণে...',
};

