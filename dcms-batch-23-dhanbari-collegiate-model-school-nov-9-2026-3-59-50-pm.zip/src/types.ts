export type AcademicGroup = 'Science' | 'Commerce' | 'Humanities';

export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export interface Batchmate {
  id: string;
  name: string;
  nameBangla?: string;
  group: AcademicGroup;
  gender: 'Male' | 'Female';
  rollNumber?: string;
  dob?: string; // YYYY-MM-DD or DD/MM/YYYY
  birthday?: string; // MM-DD
  blood: BloodGroup | string;
  phone: string;
  whatsapp?: string;
  email?: string;
  address: string;
  facebook?: string;
  instagram?: string;
  bio?: string;
  photoUrl: string;
  currentStatus?: string; // e.g. "BUET (CSE)", "Dhaka Medical College", "Dhaka University"
  isRepresentative?: boolean;
  pin?: string; // 4-digit PIN for Member ID gate
  hidePhone?: boolean; // When true, only admin can view the phone number
}

export interface HallOfFameItem {
  id: string;
  name: string;
  category: 'Engineering' | 'Medical' | 'Public University' | 'Olympiad & Academic' | 'Sports & Cultural' | 'Leadership';
  achievement: string;
  photoUrl: string;
  institution?: string;
  year?: string;
}

export interface Story {
  id: string;
  title: string;
  author: string;
  authorGroup?: AcademicGroup;
  date: string;
  content: string;
  status: 'published' | 'pending';
  likes: number;
  photoUrl?: string;
  timestamp: number;
}

export interface GalleryItem {
  id: string;
  url: string;
  caption?: string;
  type: 'photo' | 'video';
  eventName: string;
  timestamp: number;
}

export interface ReunionRegistration {
  id: string;
  name: string;
  group: string;
  phone: string;
  email?: string;
  address: string;
  tshirtSize: 'S' | 'M' | 'L' | 'XL' | 'XXL';
  guestCount: number;
  notes?: string;
  timestamp: number;
  confirmed: boolean;
}

export interface ReunionSettings {
  targetDate: string; // e.g. "2026-12-25T10:00"
  displayDateText: string; // e.g. "December 25, 2026 • 10:00 AM onwards"
  venue: string; // e.g. "ধনবাড়ী নওয়াব প্যালেস ও স্কুল অডিটোরিয়াম"
  tagline: string;
}

